WITH Calculations AS (
    select 
 period_id [Quarter]
 ,'ACTUAL_STATEMENT' [Calculation Type]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,calc.contract_id [Deal ID]
,udkey_7_value [Income Group]
,udkey_4_descr [Customer]
,udkey_11_descr [Language]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Sale - ITD] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Return - ITD] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Gross Receipts - ITD] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Platform Fee - ITD]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Royalties - ITD]
,sum(case when [udkey_2_value]='Sale' AND udkey_3_value='Current' then alt_qty else 0 end) [Minutes Watched - Current]
from uv_deal_calc_result calc 

JOIN (
        SELECT contract_sid, contract_id, udf_value_id AS [Agreement Number]
        FROM uv_contract_udf  
        WHERE udf_name = 'Agreement_Integer' AND status_id <> 'PRIORREVISION'
        GROUP BY contract_sid, contract_id, udf_value_id
    ) an ON an.contract_id = calc.contract_id

Where calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
and udkey_4_descr<>'Unspecified'
AND [Agreement Number] LIKE '%P'
and period_id='202506'

group by 
 period_id
,calc.contract_id
,udkey_7_value
,udkey_4_descr
,udkey_11_descr),

Metadata AS (
        SELECT 
        c.contract_id AS [Contract ID],
        c.contract_description AS [Contract Name],
        licensee.[Corporate_Entity] AS [Licensee],
        licensor.[Licensor],
        c.contract_status_id AS [Contract Status],
        ms.[master_status] AS [Deal Management Status],
        an.[Agreement Number],
        ISNULL(cs.contract_start_date, '') AS [Deal Start Date],
        ISNULL(ce.contract_end_date, '') AS [Deal End Date],
        scope.[Scope start Date],
        scope.[Scope End date]
    FROM uv_contract c
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [master_status] FROM uv_contract_udf WHERE udf_name = 'masterstatus') ms ON ms.contract_sid = c.contract_sid
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [Agreement Number] FROM uv_contract_udf WHERE udf_name = 'Agreement_Integer') an ON an.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_start_date FROM uv_contract_udf WHERE udf_name = 'contract_term_start') cs ON cs.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_end_date FROM uv_contract_udf WHERE udf_name = 'contract_term_end') ce ON ce.contract_sid = c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Licensor] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Licensor') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensor on licensor.contract_sid=c.contract_sid
    LEFT JOIN (SELECT a.contract_id, MIN(start_actual_period_id) AS [Scope start Date], MAX(end_actual_period_id) AS [Scope End date] FROM uv_contract_rights a GROUP BY a.contract_id) scope ON c.contract_id = scope.contract_id
    WHERE c.contract_status_id NOT IN ('PRIORREVISION', 'MODEL')
    AND [Agreement Number] LIKE '%P'
    AND c.contract_description LIKE '%Crunchyroll KK%'
    --and c.contract_id in ('','')
)
SELECT 
[Quarter],
[Calculation Type],
[Report Generation Date],
[Deal ID],
[Agreement Number],
[Contract Name],
[Licensee],
[Income Group],
[Customer],
[Language],
[Sale - Current],
[Return - Current],
[Gross Receipts - Current],
[Platform fee - Current],
[Royalties - Current],
[Sale - ITD],
[Return - ITD],
[Gross Receipts - ITD],
[Platform Fee - ITD],
[Royalties - ITD],
[Minutes Watched - Current]

FROM Calculations

JOIN Metadata ON Calculations.[Deal ID] = Metadata.[Contract ID]
--where [deal id]='11080';
