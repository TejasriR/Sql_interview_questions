select 
 period_id [Quarter]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'ACTUAL_STATEMENT' [Calculation Type]
,calc.contract_id [Deal ID]
,udkey_1_value [Catalog ID]
,udkey_1_descr [Catalog Name]

,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
,format(sum(case when [udkey_2_value]='Reserves Taken' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken - Current] 
,format(sum(case when [udkey_2_value]='Reserves Released' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released - Current] 
,format(sum(case when [udkey_2_value]='Net Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts Stmt - Current]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]

--,format(sum(case when [udkey_2_value]='Historical Royalties Due' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Historical Royalties]

from uv_deal_calc_result calc 

where period_id='202403'
--and udkey_2_value not like '%Stmt'
and udkey_3_value ='CURRENT'
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'

--and calc.contract_id ='7289'
group by 
 period_id
,calc.contract_id
,udkey_1_value
,udkey_1_descr
order by 
calc.contract_id
,udkey_1_value
