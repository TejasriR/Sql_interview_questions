select 
 period_id [Period]
,cdata.[Contract ID] [Deal ID]
,cdata.[Contract Name] [Deal Name]
,cdata.[Agreement Number]
,[udkey_7_value] [Income Group]
,[udkey_1_value] [Catalog ID]
,udkey_1_descr [Catalog Name]
,[Episode Number]
--,[Parent Catalog ID]
,format(sum(case when [udkey_2_value]='Gross Receipts' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Gross Receipts] 
,format(sum(case when [udkey_2_value]='Platform Fee' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Platform Fee] 
,format(sum(case when [udkey_2_value]='Reserves Taken' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Royalties]
,format(sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Royalties Due]
,sum(case when [udkey_2_value]='Sale' AND udkey_3_value='Current' then alt_qty else 0 end) [Minutes Watched]
  from [uv_deal_calc_result] calc 
  join (select 
c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,c.contract_status_id [Contract Status]
,an.[Agreement Number]
from uv_contract c

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'



group BY
c.contract_id 
,c.contract_description 
,c.contract_status_id 
,an.[Agreement Number]

) cdata on cdata.[Contract ID]=calc.contract_id

join (SELECT [udkey_1_sid] [Catalog SID]
      ,[udkey_1_id] [Catalog ID]
      ,[udf_value] [Episode Number] from [uv_udkey_1_udf] 
      where [udf_name]='Episode_Number'
      group by
      [udkey_1_sid]
      ,[udkey_1_id]
      ,[udf_value]) cat on cat.[Catalog SID] = calc.udkey_1_sid

--join (SELECT cat.[udkey_1_sid] [Catalog SID]
--      ,[udkey_1_id] [Catalog ID]
--      ,[udf_value] [Episode Number]
--      ,[Parent Catalog ID]
--  FROM [uv_udkey_1_udf] cat
--  join (SELECT [udkey_1_sid]
--      ,[hierarchy_level_nbr]
--      ,[parent_udkey_1_sid] [Parent Catalog ID]
--        FROM[c_udkey_1_hierarchy]) parent_cat on parent_cat.[udkey_1_sid]=cat.[udkey_1_sid]
--  where [udf_name]='Episode_Number') cat_hierarchy on cat_hierarchy.[catalog SID]=calc.udkey_1_sid


  Where period_id='202403'
  and udkey_3_value='Current'
  and [udkey_1_value]<>'Unspecified'
  and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
  --and cdata.[Contract ID]='1027'
  group by 
   period_id
,cdata.[Contract ID] 
,cdata.[Contract Name] 
,cdata.[Contract Status]
,cdata.[Agreement Number]
,[udkey_1_value]
,[udkey_7_value]
,udkey_1_descr
,[Episode Number]
--,[Parent Catalog ID]

    