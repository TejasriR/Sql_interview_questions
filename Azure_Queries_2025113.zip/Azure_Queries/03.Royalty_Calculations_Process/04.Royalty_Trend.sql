
SELECT
datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,[Calculation Type]
,[Contract ID]
,[Agreement Number]
,[Contract Name]
,[Contract Status]
,Licensee
,[Scope start Date]
,[Scope End date]
,[Recoupment Group]
,[Royalty Beginning Balance]
,[Royalties Current Q12022]
,[Royalties Current Q22022]
,[Royalties Current Q32022]
,[Royalties Current Q42022]
,[Royalties ITD Q12022]
,[Royalties ITD Q22022]
,[Royalties ITD Q32022]
,[Royalties ITD Q42022]
,[Royalties Current Q12023]
,[Royalties Current Q22023]
,[Royalties Current Q32023]
,[Royalties Current Q42023]
,[Royalties ITD Q12023]
,[Royalties ITD Q22023]
,[Royalties ITD Q32023]
,[Royalties ITD Q42023]
,[Royalties Current Q12024]
,[Royalties Current Q22024]
,[Royalties Current Q32024]
,[Royalties Current Q42024]
,[Royalties ITD Q12024]
,[Royalties ITD Q22024]
,[Royalties ITD Q32024]
,[Royalties ITD Q42024]
,[Royalties Current Q12025]
,[Royalties Current Q22025]
,[Royalties ITD Q12025]
,[Royalties ITD Q22025]
,[Minimum Guarantee]
,[Production Costs]
,[P&A Costs]
,[Miscellaneous Costs]

from 
(select 


'ACTUAL_STATEMENT' [Calculation Type]
,calc.[contract_id] [Deal ID]
,[udkey_15_value] [Recoupment Group]
--,data_is_approved_flag [Calculations are approved?]

  
  ,format(case when count(distinct case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1=0 then 0 else sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)/(count(distinct case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1) end,'C','en-US') [Royalty Beginning Balance]
  
   --2022
      
  ,format(sum(case when [Period_id]='202203' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q12022]
  ,format(sum(case when [Period_id]='202206' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q22022]
  ,format(sum(case when [Period_id]='202209' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q32022]
  ,format(sum(case when [Period_id]='202212' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q42022]

  ,format(sum(case when [Period_id]='202203' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202203' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q12022]
  ,format(sum(case when [Period_id]='202206' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202206' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q22022]
  ,format(sum(case when [Period_id]='202209' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202209' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q32022]
  ,format(sum(case when [Period_id]='202212' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202212' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q42022]
  
    --2023

  ,format(sum(case when [Period_id]='202303' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q12023]
  ,format(sum(case when [Period_id]='202306' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q22023]
  ,format(sum(case when [Period_id]='202309' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q32023]
  ,format(sum(case when [Period_id]='202312' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q42023]

  ,format(sum(case when [Period_id]='202303' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202303' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q12023]
  ,format(sum(case when [Period_id]='202306' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202306' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q22023]
  ,format(sum(case when [Period_id]='202309' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202309' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q32023]
  ,format(sum(case when [Period_id]='202312' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202312' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q42023]
  
    --2024
  
  ,format(sum(case when [Period_id]='202403' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q12024]
  ,format(sum(case when [Period_id]='202406' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q22024]
  ,format(sum(case when [Period_id]='202409' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q32024]
  ,format(sum(case when [Period_id]='202412' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q42024]

  ,format(sum(case when [Period_id]='202403' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202403' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q12024]
  ,format(sum(case when [Period_id]='202406' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202406' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q22024]
  ,format(sum(case when [Period_id]='202409' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202409' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q32024]
  ,format(sum(case when [Period_id]='202412' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [Period_id]='202412' AND udkey_3_value='ITD' and [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [Royalties ITD Q42024]

    --2025

  ,format(sum(case when [Period_id]='202503' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q12025]
  ,format(sum(case when [Period_id]='202506' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q22025]
  --,format(sum(case when [Period_id]='202509' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q32025]
  --,format(sum(case when [Period_id]='202512' AND udkey_3_value='Current' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties Current Q42025]

  ,format(sum(case when [Period_id]='202503' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties ITD Q12025]
  ,format(sum(case when [Period_id]='202506' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties ITD Q22025]
  --,format(sum(case when [Period_id]='202509' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties ITD Q32025]
  --,format(sum(case when [Period_id]='202512' AND udkey_3_value='ITD' and [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties ITD Q42025]


  ,format(case when count(distinct case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1=0 then 0 else sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)/(count(distinct case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1) end,'C','en-US') [Minimum Guarantee]
  ,format(case when count(distinct case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1=0 then 0 else sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)/(count(distinct case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1) end,'C','en-US') [Production Costs]
  ,format(case when count(distinct case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1=0 then 0 else sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)/(count(distinct case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1) end,'C','en-US') [P&A Costs]
  ,format(case when count(distinct case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1=0 then 0 else sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)/(count(distinct case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' and amount<>0 then period_id else '' end)-1) end,'C','en-US') [Miscellaneous Costs]
  from [uv_deal_calc_result] calc 
  
  Where calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
  and [udkey_2_value] in ('Royalties - Stmt', 'Historical Royalties due','Minimum Guarantee','Production Costs - Stmt','Miscellaneous Costs - Paid','P&A Costs - Paid - Stmt')
  --and calc.contract_id='2158'

  group by 
  calc.[Contract_ID] 
,[udkey_15_value]

--,data_is_approved_flag

) Royalty_Trend

left join 

(select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,licensee.[Corporate_Entity] [Licensee]
,c.contract_status_id [Contract Status]

,an.[Agreement Number]

,[Scope start Date]
,[Scope End date]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]


from uv_contract c





 join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid


---licensee

left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid

--scope

left join (select 
a.contract_id [Deal ID],


min(case when [start_actual_period_id]='Inception' then '201001' else [start_actual_period_id] end) [Scope start Date],
max(case when [end_actual_period_id]='Inception' then '201001' else [end_actual_period_id] end ) [Scope End date]

from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
--and b.contract_id='3802'
group by a.contract_id) scope on c.contract_id=scope.[Deal ID]


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'

group BY
c.contract_id 
,c.contract_description 
,licensee.[Corporate_Entity]
,c.contract_status_id 
,an.[Agreement Number]
,[Scope start Date]
,[Scope End date]) c_data on c_data.[contract ID]=Royalty_Trend.[Deal ID]

group BY
[Calculation Type]
,[Contract ID]
,[Agreement Number]
,[Contract Name]
,[Contract Status]
,Licensee
,[Scope start Date]
,[Scope End date]
,[Recoupment Group]
,[Royalty Beginning Balance]
,[Royalties Current Q12022]
,[Royalties Current Q22022]
,[Royalties Current Q32022]
,[Royalties Current Q42022]
,[Royalties ITD Q12022]
,[Royalties ITD Q22022]
,[Royalties ITD Q32022]
,[Royalties ITD Q42022]
,[Royalties Current Q12023]
,[Royalties Current Q22023]
,[Royalties Current Q32023]
,[Royalties Current Q42023]
,[Royalties ITD Q12023]
,[Royalties ITD Q22023]
,[Royalties ITD Q32023]
,[Royalties ITD Q42023]
,[Royalties Current Q12024]
,[Royalties Current Q22024]
,[Royalties Current Q32024]
,[Royalties Current Q42024]
,[Royalties ITD Q12024]
,[Royalties ITD Q22024]
,[Royalties ITD Q32024]
,[Royalties ITD Q42024]
,[Royalties Current Q12025]
,[Royalties Current Q22025]
,[Royalties ITD Q12025]
,[Royalties ITD Q22025]
,[Minimum Guarantee]
,[Production Costs]
,[P&A Costs]
,[Miscellaneous Costs]