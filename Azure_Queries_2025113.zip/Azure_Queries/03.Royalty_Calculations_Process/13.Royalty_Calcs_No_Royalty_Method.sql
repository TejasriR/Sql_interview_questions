select
Contract_id [Deal ID]
--,udkey_1_value [Catalog]
,udkey_5_value [Territory]
,udkey_7_value [Income Group]
,Price_Point [SRP]
,user_rate [Royalty_Rate]
,[Balance_Type]
from [uv_deal_calc_result] calcs 
left join (SELECT beg_balances.contract_id [Deal ID],
c.[Agreement Number], beg_balances.contract_descr [Deal Name], udkey_2_descr [Balance_Type]

FROM [uv_adjustment_contract_dtl] beg_balances join (SELECT 
     [contract_id], [udf_name], [udf_value] [Agreement Number]
     from [uv_contract_udf] where udf_name = 'Agreement_integer') c on c.contract_id=beg_balances.contract_id
  
where udkey_2_descr = 'Non-Recoupable Flat Fee Adjustment'
group by beg_balances.contract_id, c.[Agreement Number],beg_balances.contract_descr,udkey_2_descr) ffd on ffd.[Deal ID]=calcs.contract_id

where udkey_2_value='Royalties'
and user_rate=0
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
--and udkey_7_value='DTC Videogram'
--and contract_id='2099' 

group BY
Contract_id 
--,udkey_1_value 
,udkey_5_value 
,udkey_7_value 
,Price_Point
,user_rate
,[Balance_Type]