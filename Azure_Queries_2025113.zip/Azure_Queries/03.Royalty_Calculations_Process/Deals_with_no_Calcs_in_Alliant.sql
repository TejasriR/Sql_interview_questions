
  SELECT 
  --adj.adjustment_sid
  --adj.item_sid [contract_sid]
  c.contract_id
  ,period_id
  ,[Agreement Number]
  ,udkey_15_descr
  ,format(sum(case when [adj_det].[udkey_2_id]='Minimum Guarantee' then amount else 0 end),'C','en-US') [MG]
  ,format(sum(case when [adj_det].[udkey_2_id]='Production Costs' then amount else 0 end),'C','en-US') [Production Costs]
  ,format(sum(case when [adj_det].[udkey_2_id]='Historical Royalties Due' then amount else 0 end),'C','en-US') [Historical Royalties Due]
  ,format(sum(case when [adj_det].[udkey_2_id]='P&A Costs - Paid' then amount else 0 end),'C','en-US') [P&A Costs]
  ,format(sum(case when [adj_det].[udkey_2_id]='Miscellaneous Costs - Paid' then amount else 0 end),'C','en-US') [Misc Costs]
  --,[Last Period to have a statement in alliant]

  FROM x_adjustment_hdr adj 
  join uv_contract c on adj.item_sid=c.contract_sid
  join uv_adjustment_contract_dtl adj_det on adj.adjustment_sid=adj_det.adjustment_sid
  left join (select adjustment_sid from [uv_contract_posted_period] group by adjustment_sid ) cp on adj_det.adjustment_sid=cp.adjustment_sid
  join x_adjustment_hdr xa on xa.adjustment_sid=adj_det.adjustment_sid
   
  join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) an on an.contract_sid=c.contract_sid

 left join (select [contract_id],max(period_id) [Last Period to have a statement in alliant] from uv_statement group by contract_id) last_period on c.contract_id=last_period.contract_id

  where c.contract_status_id<>'PRIORREVISION'
  --and adj_det.udkey_2_id='Minimum Guarantee'
  and [Last Period to have a statement in alliant] is null
  and xa.status_sid<>11
  --  and c.contract_id in ('8')
  group by 
    --adj.adjustment_sid
   -- adj.item_sid
  --adj_det.udkey_2_id
  c.contract_id
  ,[Agreement Number]
  ,period_id
  ,udkey_15_descr
  --,[Last Period to have a statement in alliant]
  order by   c.contract_id asc
