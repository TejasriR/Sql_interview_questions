select [Contract ID],  [Scope start Date], [Scope End date], [Contract Status] from (

Select contract_id [Contract_ID], Period_id [Period], '1' as [ID_1]  from uv_statement where period_id='202409' group by contract_id, Period_id)   s

Right JOIN (select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,licensee.[Corporate_Entity] [Licensee]
,licensor.[Licensor]
,c.contract_status_id [Contract Status]
,ms.[master_status] [Deal Management Status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') [Deal Start Date]
,ISNULL(ce.contract_end_date,'') [Deal End Date]
,[Scope start Date]
,[Scope End date]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'1' as [ID]


from uv_contract c




join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_start_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_start')) cs on cs.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_end_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_end')) ce on ce.contract_sid=c.contract_sid

---licensee

left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid

left join (select cpar.contract_sid, string_agg(company_name,'|') [Licensor] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Licensor') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensor on licensor.contract_sid=c.contract_sid

left join (select 
a.contract_id [Deal ID],


min([start_actual_period_id]) [Scope start Date],
max([end_actual_period_id]) [Scope End date]

from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
--where b.contract_id='5712'
group by a.contract_id) scope on c.contract_id=scope.[Deal ID]


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'

group BY
c.contract_id 
,c.contract_description 
,licensee.[Corporate_Entity]
,licensor.[Licensor]
,c.contract_status_id 
,ms.[master_status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') 
,ISNULL(ce.contract_end_date,'') 
,[Scope start Date]
,[Scope End date]) Metadata on s.contract_id=Metadata.[Contract ID]

where [Contract Status]='Active'
and [period] is null