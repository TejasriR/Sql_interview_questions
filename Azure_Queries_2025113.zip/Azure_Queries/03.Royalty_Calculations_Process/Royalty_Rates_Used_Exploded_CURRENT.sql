select 
 period_id [Quarter]
,calc.contract_id [Deal ID]
,udkey_7_value [Income Group]
--,udkey_6_value [Format]
--,udkey_5_value [Territory]
--,udkey_1_value [Catalog]
,Format(User_rate,'P') [Royalty Rate Used]
from uv_deal_calc_result calc 
where period_id ='202406' 
and udkey_2_value ='Royalties'
and udkey_3_value ='CURRENT'
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'

--and contract_id='1027'
group by 
 period_id
,calc.contract_id
,udkey_7_value
,Format(User_rate,'P')
--,udkey_6_value
--,udkey_5_value
--,udkey_1_value
order by 
calc.contract_id
,udkey_7_value