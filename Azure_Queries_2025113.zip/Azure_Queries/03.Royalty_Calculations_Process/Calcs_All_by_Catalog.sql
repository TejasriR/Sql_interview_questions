WITH Calculations AS (
    SELECT 
        period_id AS [Period],
        calc.contract_id AS [Deal ID],
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE())) AS [Report Generation Date],
        'ACTUAL_STATEMENT' AS [Calculation Type],
        udkey_7_value AS [Income Group],
        --udkey_5_descr AS [Territory],
        --udkey_4_descr AS [Customer],
        udkey_1_value AS [Catalog ID],
        udkey_1_Descr AS [Catalog Name],
        data_is_approved_flag AS [Calculations are approved?],
        --FORMAT(SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Sale - Current],
        --FORMAT(SUM(CASE WHEN udkey_2_value='Return' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Return - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Gross Receipts' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Gross Receipts - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Platform Fee' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Platform Fee - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties with Escalation Applied' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties with Escalation - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties Due' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties Due - Current],
        --FORMAT(SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Sale - ITD],
        --FORMAT(SUM(CASE WHEN udkey_2_value='Return' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Return - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Gross Receipts' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Gross Receipts - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Platform Fee' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Platform Fee - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties with Escalation Applied' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties with Escalation - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties Due' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties Due - ITD],
        SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='Current' THEN alt_qty ELSE 0 END) AS [Minutes Watched - Current]
    FROM uv_deal_calc_result calc
    WHERE period_id = '202409'
    AND calculation_name = 'C_MAIN_PARTICIP_STANDALONE_STATEMENT'
    AND udkey_4_descr <> 'Unspecified'

    GROUP BY 
    period_id,
    calc.contract_id,
    udkey_7_value, 
    --udkey_5_descr, 
    --udkey_4_descr, 
    udkey_1_value, 
    udkey_1_Descr, 
    data_is_approved_flag
),
L4_to_L3 AS (
    SELECT 
        a.udkey_1_id AS [RL Catalog ID],
        b.udkey1_description AS [RL Catalog Name Description],
        d.udkey_1_id AS [RL Season_Movie_OVA ID],
        d.udkey1_description AS [RL Season_Movie_OVA Description]
    FROM uv_udkey_1_udf a
    JOIN uv_udkey_1 b ON a.udkey_1_sid = b.udkey_1_sid
    LEFT JOIN c_udkey_1_hierarchy sea ON sea.udkey_1_sid = a.udkey_1_sid
    LEFT JOIN uv_udkey_1 d ON sea.parent_udkey_1_sid = d.udkey_1_sid
    WHERE udf_name = 'entity_template' AND a.udf_value = 'episode'
    UNION ALL
    SELECT 
        a.udkey_1_id AS [RL Catalog ID],
        b.udkey1_description AS [RL Catalog Name Description],
        a.udkey_1_id AS [RL Season_Movie_OVA ID],
        b.udkey1_description AS [RL Season_Movie_OVA Description]
    FROM uv_udkey_1_udf a
    JOIN uv_udkey_1 b ON a.udkey_1_sid = b.udkey_1_sid
    WHERE udf_name = 'entity_template' AND a.udf_value IN ('Movie', 'OVA', 'Season', 'Music')
),
Metadata AS (
        SELECT 
        c.contract_id AS [Contract ID],
        c.contract_description AS [Contract Name],
        licensee.[Corporate_Entity] AS [Licensee],
        licensor.[Licensor],
        c.contract_status_id AS [Contract Status],
        ms.[master_status] AS [Deal Management Status],
        an.[Agreement Number],
        ISNULL(cs.contract_start_date, '') AS [Deal Start Date],
        ISNULL(ce.contract_end_date, '') AS [Deal End Date],
        scope.[Scope start Date],
        scope.[Scope End date]
    FROM uv_contract c
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [master_status] FROM uv_contract_udf WHERE udf_name = 'masterstatus') ms ON ms.contract_sid = c.contract_sid
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [Agreement Number] FROM uv_contract_udf WHERE udf_name = 'Agreement_Integer') an ON an.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_start_date FROM uv_contract_udf WHERE udf_name = 'contract_term_start') cs ON cs.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_end_date FROM uv_contract_udf WHERE udf_name = 'contract_term_end') ce ON ce.contract_sid = c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Licensor] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Licensor') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensor on licensor.contract_sid=c.contract_sid
    LEFT JOIN (SELECT a.contract_id, MIN(start_actual_period_id) AS [Scope start Date], MAX(end_actual_period_id) AS [Scope End date] FROM uv_contract_rights a GROUP BY a.contract_id) scope ON c.contract_id = scope.contract_id
    WHERE c.contract_status_id NOT IN ('PRIORREVISION', 'MODEL')
    --AND [Corporate_Entity] LIKE '%SA'
    --AND [Licensor] LIKE '%Toei'
    --AND [Contract ID] in ('7141','9899')

)
SELECT 
isnull([Period],'No Calculations') [Period], 
[Contract ID],
[Agreement Number],
[Contract Name],
[Contract Status],
[Deal Management Status],
[Licensee],
[Licensor],
[Deal Start Date],
[Deal End Date],
[Scope start Date],
[Scope End date],
[Report Generation Date],
[Calculation Type],
[Income Group],
--[Territory],
--[Customer],
[Catalog ID],
[RL Catalog Name Description],
[RL Season_Movie_OVA ID],
[RL Season_Movie_OVA Description],
[Calculations are approved?],
--[Sale - Current],
--[Return - Current],
[Gross Receipts - Current],
[Platform Fee - Current],
[Royalties - Current],
[Royalties with Escalation - Current],
[Royalties Due - Current],
--[Sale - ITD],
--[Return - ITD],
[Gross Receipts - ITD],
[Platform Fee - ITD],
[Royalties - ITD],
[Royalties with Escalation - ITD]
[Royalties Due - ITD],
[Minutes Watched - Current]

FROM Calculations
JOIN L4_to_L3 ON L4_to_L3.[RL Catalog ID] = Calculations.[Catalog ID]
JOIN Metadata ON Calculations.[Deal ID] = Metadata.[Contract ID];