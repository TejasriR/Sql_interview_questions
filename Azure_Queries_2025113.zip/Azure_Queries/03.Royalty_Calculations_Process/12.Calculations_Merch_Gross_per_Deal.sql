select

period_id
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'ACTUAL_STATEMENT' [Calculation Type]
,calc.contract_id [Deal ID]
,uvc.contract_description [Deal Name]
,[Agreement Number]
,[Contract Status]
,[udkey_4_descr] [Customer]
,[udkey_7_descr] [Income Group]
  ,format(Sum(amount),'C','en-US') [Gross Receipts] 
 
  
  from [uv_deal_calc_result] calc 
  join (SELECT 
      [contract_id], [udf_name],[status_id] [Contract Status], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' and status_id<>'PRIORREVISION'  group by [contract_id],status_id, [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id



  join (select contract_id,contract_description from [uv_contract] where contract_status_id<>'PRIORREVISION' group by contract_id, contract_description) uvc on c.contract_id=uvc.contract_id
  where udkey_3_value='Current'
  and [udkey_4_descr]<>'Unspecified'
  and [udkey_2_value]='Gross Receipts'
  --and period_id='202406'
  and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
  and [udkey_7_descr] in ('Self-Manufactured Other Goods','Physical Merchandise','Mobile Games', 'Digital Virtual Goods') 
  and [Contract Status]<>'PRIORREVISION' and [Contract Status]<>'MODEL'
  --and calc.[contract_id]='1940'
  group by 
   period_id
  ,calc.contract_id
  ,uvc.contract_description
  ,[Agreement Number]
  ,[Contract Status]
  ,[udkey_4_descr] 
  ,[udkey_7_descr]