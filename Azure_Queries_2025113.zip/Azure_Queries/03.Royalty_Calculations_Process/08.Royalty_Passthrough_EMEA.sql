WITH Calculations AS (
    SELECT 
        period_id AS [Period],
        calc.contract_id AS [Deal ID],
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), DAY(GETDATE())) AS [Report Generation Date],
        'ACTUAL_STATEMENT' AS [Calculation Type],
        udkey_7_value AS [Income Group],
        udkey_5_descr AS [Territory],
        udkey_4_descr AS [Customer],
        data_is_approved_flag AS [Calculations are approved?],
        FORMAT(SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Sale - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Return' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Return - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Gross Receipts' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Gross Receipts - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Platform Fee' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Platform Fee - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties' AND udkey_3_value='CURRENT' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties - Current],
        FORMAT(SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Sale - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Return' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Return - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Gross Receipts' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Gross Receipts - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Platform Fee' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Platform Fee - ITD],
        FORMAT(SUM(CASE WHEN udkey_2_value='Royalties' AND udkey_3_value='ITD' THEN amount ELSE 0 END), 'C', 'en-US') AS [Royalties - ITD],
        SUM(CASE WHEN udkey_2_value='Sale' AND udkey_3_value='Current' THEN alt_qty ELSE 0 END) AS [Minutes Watched - Current]
    FROM uv_deal_calc_result calc
    JOIN (
        SELECT contract_sid, contract_id, udf_value_id AS [Agreement Number]
        FROM uv_contract_udf  
        WHERE udf_name = 'Agreement_Integer' AND status_id <> 'PRIORREVISION'
        GROUP BY contract_sid, contract_id, udf_value_id
    ) an ON an.contract_id = calc.contract_id
    WHERE period_id = '202409'
    AND calculation_name = 'C_MAIN_PARTICIP_STANDALONE_STATEMENT'
    AND udkey_4_descr <> 'Unspecified'
    AND [Agreement Number] LIKE '%P'
    GROUP BY period_id, calc.contract_id, udkey_7_value, udkey_5_descr, udkey_4_descr, data_is_approved_flag
),

Metadata AS (
        SELECT 
        c.contract_id AS [Contract ID],
        c.contract_description AS [Contract Name],
        licensee.[Corporate_Entity] AS [Licensee],
        licensor.[Licensor],
        c.contract_status_id AS [Contract Status],
        ms.[master_status] AS [Deal Management Status],
        an.[Agreement Number],
        ISNULL(cs.contract_start_date, '') AS [Deal Start Date],
        ISNULL(ce.contract_end_date, '') AS [Deal End Date],
        scope.[Scope start Date],
        scope.[Scope End date]
    FROM uv_contract c
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [master_status] FROM uv_contract_udf WHERE udf_name = 'masterstatus') ms ON ms.contract_sid = c.contract_sid
    JOIN (SELECT contract_sid, contract_id, udf_value_id AS [Agreement Number] FROM uv_contract_udf WHERE udf_name = 'Agreement_Integer') an ON an.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_start_date FROM uv_contract_udf WHERE udf_name = 'contract_term_start') cs ON cs.contract_sid = c.contract_sid
    LEFT JOIN (SELECT contract_sid, contract_id, udf_value_id AS contract_end_date FROM uv_contract_udf WHERE udf_name = 'contract_term_end') ce ON ce.contract_sid = c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid
    left join (select cpar.contract_sid, string_agg(company_name,'|') [Licensor] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
    where (contact_type_descr='Licensor') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensor on licensor.contract_sid=c.contract_sid
    LEFT JOIN (SELECT a.contract_id, MIN(start_actual_period_id) AS [Scope start Date], MAX(end_actual_period_id) AS [Scope End date] FROM uv_contract_rights a GROUP BY a.contract_id) scope ON c.contract_id = scope.contract_id
    WHERE c.contract_status_id NOT IN ('PRIORREVISION', 'MODEL')
    AND [Agreement Number] LIKE '%P'
    AND ([Corporate_Entity] LIKE '%SA' OR [Corporate_Entity] LIKE '%SAS%')
    AND [Corporate_Entity] NOT LIKE 'Wakanim%'
)
SELECT 
isnull([Period],'No Calculations') [Period], 
[Contract ID],
[Agreement Number],
[Contract Name],
[Contract Status],
[Deal Management Status],
[Licensee],
[Deal Start Date],
[Deal End Date],
[Scope start Date],
[Scope End date],
[Report Generation Date],
[Calculation Type],
[Income Group],
[Territory],
[Customer],
[Calculations are approved?],
[Sale - Current],
[Return - Current],
[Gross Receipts - Current],
[Platform Fee - Current],
[Royalties - Current],
[Sale - ITD],
[Return - ITD],
[Gross Receipts - ITD],
[Platform Fee - ITD],
[Royalties - ITD],
[Minutes Watched - Current]

FROM Calculations
JOIN Metadata ON Calculations.[Deal ID] = Metadata.[Contract ID];