select [contract_id]
,'ACTUAL_STATEMENT' [Calculation Type]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,udkey_1_value [Catalog]
, udkey_5_value [Territory]
, udkey_7_value [Income Group]
,udkey_6_value [Format]
,udkey_4_value [Customer ID]
,cont.formatted_name [Customer Name]
, sum(amount) [Suspended Revenue] 
from [uv_deal_calc_result] calc  
join uv_contact cont on cont.contact_id=calc.udkey_4_value
where (udkey_2_value ='Suspended Sale' or udkey_2_value ='Suspended Return')
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'

--and contract_id ='2239'
--and udkey_1_value='2743'
group by [contract_id], udkey_1_value, udkey_5_value, udkey_7_value,udkey_4_value,cont.formatted_name,udkey_6_value