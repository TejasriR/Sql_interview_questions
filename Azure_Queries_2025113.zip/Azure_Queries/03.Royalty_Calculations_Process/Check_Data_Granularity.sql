select 
period_id [Period]
,calc.contract_id [Deal ID]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'ACTUAL_STATEMENT' [Calculation Type]
,[udkey_15_value] [Recoupment Group]
,data_is_approved_flag [Calculations are approved?]
,[udkey_7_value] [Income Group]
,[udkey_5_value] [Territory]
,[user_comment] [Summarized Income Group]
,[alt_user_comment] [Summarized Territory]
,format(sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Sale] 
,format(sum(case when [udkey_2_value]='Return - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Return] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Gross Receipts] 
,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Platform Fee]
,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Reserves Taken] 
,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Reserves Released] 
,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Net Receipts]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Royalties]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [LTD Royalty Prior Quarter]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD_Royalties]
,format(sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Minimum Guarantee]
,format(sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Expenses] --Miscellaneous Costs - Paid
,format(sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [P&A_Costs]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due'  AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Deal_Balance]
,format(sum(case when [udkey_2_value]='Final Guarantee Balance' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Guarantee Balance]
,format(sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Previously Paid]
,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Royalties Due]
,format(sum(case when [udkey_2_value]='AGR Fee' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [AGR Fee]
,format(sum(case when [udkey_2_value]='Music Sync Fee - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Music Sync Fee]
,sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='ITD' then alt_qty else 0 end) [Minutes Watched]
,case when (sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end))<0 then 'Unrecouped' else 'Recouped' end [Recoupment_Flag]
    
from [uv_deal_calc_result] calc 
Where period_id between '202406' and '202406'
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
and calc.[Contract_ID] in ('6524','9','7141')

group by 
period_id
,calc.contract_id
,[udkey_15_value] 
,data_is_approved_flag
,[udkey_7_value] 
,[udkey_5_value]
,[user_comment]
,[alt_user_comment]

HAVING 

sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Return - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Platform Fee - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due'  AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Final Guarantee Balance' AND udkey_3_value='ITD' then amount else 0 end)+
sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)+
sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)+
sum(case when [udkey_2_value]='AGR Fee' AND udkey_3_value='Current' then amount else 0 end)+
sum(case when [udkey_2_value]='Music Sync Fee - Stmt' AND udkey_3_value='Current' then amount else 0 end)+
sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='ITD' then alt_qty else 0 end) <>0