select 
contract_id
--,case when actual_period_id<=202312 then '2023_Q4' else left(actual_period_id,4)+'_Q'+cast(datepart(q,DATEFROMPARTS(left(actual_period_id,4),cast(right(actual_period_id,2) as int),1)) as varchar) end [Actual Quarter]
,period_id [Reporting Period]
,actual_period_id
--,udkey_15_value
,udkey_2_value [Account]
,udkey_1_value [catalog_id]
,udkey_1_descr [catalog]
,udkey_10_value [bundle product ID]
,udkey_10_Descr [bundle product Name]
,udkey_5_value [Territory]
,udkey_4_value [Customer ID]
,udkey_4_descr [Custome Name] 
,udkey_7_value [income group]
,sum(amount) [Revenue attached]
from  uv_deal_calc_result
where calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
and actual_period_id<>'Unspecified'
and actual_period_id<>'END OF TIME'
and actual_period_id<>'BEG OF TIME'
and actual_period_id<>'Inception'
and period_id='202506'
and udkey_3_value='Current'
and udkey_2_value in ('sale','return')
and contract_id ='7578'
--and udkey_1_value in ('336261','336262','336265','336268','336271','336274','336277','336280','336283')
--and (udkey_7_value = '1P Electronic Sell Thru Off-Channel' or udkey_7_value = '1P Transactional Video on Demand Off-Channel')


group by 
contract_id
--,case when actual_period_id<=202312 then '2023_Q4' else left(actual_period_id,4)+'_Q'+cast(datepart(q,DATEFROMPARTS(left(actual_period_id,4),cast(right(actual_period_id,2) as int),1)) as varchar) end
,period_id
,actual_period_id
--,udkey_15_value
,udkey_1_value
,udkey_1_descr
,udkey_10_value
,udkey_4_value
,udkey_4_descr
,udkey_5_value
,udkey_7_value 
,udkey_10_Descr
,udkey_2_value