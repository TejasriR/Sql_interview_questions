SELECT 
      [date_inserted] [Rundate for Season Level Report]
  FROM [cru_error_categorization_season]
  group by [date_inserted]

  SELECT 
      [date_inserted] [Rundate for Episode Level Report]
  FROM [cru_error_categorization_episode]
  group by [date_inserted]