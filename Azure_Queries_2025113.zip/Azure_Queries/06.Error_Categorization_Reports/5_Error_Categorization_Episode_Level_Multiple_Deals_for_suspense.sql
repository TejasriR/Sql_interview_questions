select 
[Deal ID],
Mdeals.[UDF_Name],
Mdeals.[Seq_Nbr],
[Start_Period],
[End_Period],
[Catalogue_ID],
[Income_Group],
Territory,
UDF_Value,
[Contract_ID],
Local_Currency,
Mdeals.Rate_Period,
Local_Amount,
cast(case when [FX rate] is null then '1' else [FX rate] end as real) FX_Rate,
Local_Amount*cast(case when [FX rate] is null then '1' else [FX rate] end as real) [Amount_USD],
Run_Date


from 

(select 
--string_split(contract_id,'|') [Deal ID]
'' [Deal ID]
,'TransactionSuspended' [UDF_Name]
,'' [Seq_Nbr]
,'' [Start_Period]
,datefromparts(left([actual_period],4),right([actual_period],2),1) [End_Period]
,catalogue_id [Catalogue_ID]
,income_group_descr [Income_Group]
,territory_descr [Territory]
,'Yes' [UDF_Value]
,contract_id [Contract_ID]
,local_currency_descr [Local_Currency]
,amount [Local_Amount]
,actual_period+'_'+local_currency_descr [Rate_Period]
,[date_inserted] [Run_Date]
FROM dbo.cru_error_categorization_episode
where [unique]=1
and status_message = 'Multiple Deals'
--and [contract_id] not in ('2241|5713',
--'2241|5714',
--'2241|5715',
--'2241|5718',
--'2241|5719',
--'2241|5720',
--'2917|4692',
--'4710|9640',
--'2239|5712',
--'10376|5052',
--'6909|9153',
--'6909|9154',
--'5710|8793')
) Mdeals


left join (

SELECT
      from_currency.[udkey_17_id] [From currency]
      ,curr.udkey17_description [Currency_Description]
      ,[udkey_18_value] [To currency]
      ,[value] [FX rate]
      ,[udf_name]
      ,[seq_nbr]
      ,[sort_order_nbr]
      ,[start_actual_period_id]
      ,[end_actual_period_id]
      ,[start_actual_period_id]+'_'+curr.udkey17_description [Rate_Period]

  FROM [uv_udkey_17_udf_lookup] from_currency
  join uv_udkey_17 curr on curr.udkey_17_id=from_currency.udkey_17_id
  where [udkey_18_value]='USD') FX 
  on FX.[Rate_Period]=Mdeals.Rate_Period

--group by [Deal ID],Mdeals.[UDF_Name],Mdeals.[Seq_Nbr],[Start_Period],[End_Period],[Catalogue_ID],[Income_Group],Territory,UDF_Value,[Contract_ID],Local_Currency,Mdeals.Rate_Period,Local_Amount,cast(case when [FX rate] is null then '1' else [FX rate] end as real)