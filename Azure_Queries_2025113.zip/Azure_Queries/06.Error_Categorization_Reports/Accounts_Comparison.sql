select 
 period_id [Quarter]
,calc.contract_id [Deal ID]
--,udkey_7_value [Income Group]
--,udkey_5_value [Territory]
--,udkey_4_descr [Customer]
,udkey_15_value [Recoupment Group]
,format(sum(case when [udkey_2_value]='Sale - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale Stmt - Current] 
,format(sum(case when [udkey_2_value]='Return - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return Stmt - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts Stmt - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee Stmt - Current]
,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken Stmt - Current] 
,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released Stmt - Current] 
,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts Stmt - Current]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties Stmt - Current]

--,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
--,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
--,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
--,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
--,format(sum(case when [udkey_2_value]='Reserves Taken' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken - Current] 
--,format(sum(case when [udkey_2_value]='Reserves Released' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released - Current] 
--,format(sum(case when [udkey_2_value]='Net Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts - Current]
--,format(sum(case when [udkey_2_value]='Royalties with Escalation Applied' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties Escalation Applied - Current]
--,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
--,format(sum(case when [udkey_2_value]='Royalties Applied to Minimum Guarantee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties Applied to Minimum Guarantee - Current]

--,format(sum(case when [udkey_2_value]='Historical Royalties Due' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Historical Royalties]

,format(sum(case when [udkey_2_value]='Sale - Accr' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale Accr - Current] 
--,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' and calculation_name='C_MAIN_PARTICIP_STANDALONE_ACCRUAL' then amount else 0 end),'C','en-US') [Sale Accrual - current]
,format(sum(case when [udkey_2_value]='Return - Accr' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return Accr - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Accr' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts Accr - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee - Accr' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee Accr - Current]
,format(sum(case when [udkey_2_value]='Reserves Taken - Accr' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken Accr - Current] 
,format(sum(case when [udkey_2_value]='Reserves Released - Accr' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released Accr - Current] 
,format(sum(case when [udkey_2_value]='Net Receipts - Accr' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts Accr - Current]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' and calculation_name='C_MAIN_PARTICIP_STANDALONE_ACCRUAL' then amount else 0 end),'C','en-US') [Royalties Accr - Current]

from uv_deal_calc_result calc 

where period_id='202403'
--and udkey_2_value not like '%Stmt'
and udkey_3_value ='CURRENT'
--and calculation_name='C_MAIN_PARTICIP_STANDALONE_ACCRUAL'

and calc.contract_id ='1001'
group by 
 period_id
,calc.contract_id
--,udkey_4_descr
--,udkey_7_value
--,udkey_5_value
,udkey_15_value

order by 
calc.contract_id
--,udkey_7_value
