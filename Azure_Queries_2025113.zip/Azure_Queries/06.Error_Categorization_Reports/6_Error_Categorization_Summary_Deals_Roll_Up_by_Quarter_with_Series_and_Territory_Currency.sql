SELECT 

[Subsidiary], [Catalog ID], [Catalog Name],[RL Series ID],[RL Series Description], [Income Group],[Territory], [Quarter], [Error],[Currency], Sum([Total_Revenue]) [Total Revenue],Sum([Total_Revenue_USD]) [Total_Revenue_USD],[Run Date]

from (

SELECT 
subsidiary [Subsidiary],
actual_period [Actual Period],
actual_period+'_'+local_currency_descr [Rate_Period],
catalogue_id [Catalog ID], 
catalogue_descr [Catalog Name],
income_group_descr [Income Group],
territory_descr [Territory],
date_inserted [Run Date],
case when actual_period<=202312 then '2023_Q4' else left(actual_period,4)+'_Q'+cast(datepart(q,DATEFROMPARTS(left(actual_period,4),cast(right(actual_period,2) as int),1)) as varchar) end [Quarter],
string_agg(status_message,'|') [Error],
string_agg(contract_id,'|') [List of deals],
string_agg(agreement_number,'|') [List of agreement numbers],
local_currency_descr [Currency],
cast(case when [FX rate] IS NULL then '1' else [FX rate] end as real) [FX_Rate],
sum(transaction_count) [number of transactions],
amount [Total_Revenue],
amount*cast(case when [FX rate] IS NULL then '1' else [FX rate] end as real) [Total_Revenue_USD]
FROM dbo.cru_error_categorization_season season 
left join (

SELECT
      from_currency.[udkey_17_id] [From currency]
      ,curr.udkey17_description [Currency_Description]
      ,[udkey_18_value] [To currency]
      ,[value] [FX rate]
      ,[udf_name]
      ,[seq_nbr]
      ,[sort_order_nbr]
      ,[start_actual_period_id]
      ,[end_actual_period_id]
      ,[start_actual_period_id]+'_'+curr.udkey17_description [Rate_Period]

  FROM [uv_udkey_17_udf_lookup] from_currency
  join uv_udkey_17 curr on curr.udkey_17_id=from_currency.udkey_17_id
  where [udkey_18_value]='USD') FX 
  on FX.[Rate_Period]=season.actual_period+'_'+local_currency_descr


Where catalogue_descr<>'FUNIMATIONNOW'
--and status_message <> 'No Deal'
--and status_message <> 'Multiple Deals'
--and [unique]=1
--and actual_period<=202403
--and catalogue_id='3757'
--and local_currency_descr<>'United States Dollar'
group by 
subsidiary,
actual_period,
catalogue_id, 
catalogue_descr,
income_group_descr,
territory_descr,
date_inserted,
case when actual_period<=202312 then '2023_Q4' else left(actual_period,4)+'_Q'+cast(datepart(q,DATEFROMPARTS(left(actual_period,4),cast(right(actual_period,2) as int),1)) as varchar) end,
local_currency_descr,
--transaction_count, 
cast(case when [FX rate] IS NULL then '1' else [FX rate] end as real),
amount,
amount*cast(case when [FX rate] IS NULL then '1' else [FX rate] end as real)

) Deals_Roll_Up

left join 

( select a.udkey_1_sid, a.udkey_1_id [RL Catalog ID], ser.parent_udkey_1_sid, b.[udkey_1_id] [RL Series ID],b.[udkey1_description] [RL Series Description] from [uv_udkey_1] a 
left join [c_udkey_1_hierarchy] ser on a.udkey_1_sid=ser.[udkey_1_sid]
left join [uv_udkey_1] b on b.udkey_1_sid=ser.[parent_udkey_1_sid]

 group by a.udkey_1_sid, a.udkey_1_id, ser.parent_udkey_1_sid, b.[udkey_1_id],b.[udkey1_description])  hierarchy on hierarchy.[RL Catalog ID]=[Deals_Roll_Up].[Catalog ID]

--where [Quarter]='2023_Q4'
--where [Catalog ID]='2768'
--WHERE CURRENCY<>'United States Dollar'

group BY

[Subsidiary], [Catalog ID], [Catalog Name],[RL Series ID],[RL Series Description], [Income Group],[Territory], [Quarter],[Currency], [Error], [Run Date]
