select 

udkey_7_value [Income Group]

,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,case when sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)=0 then 0 else sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)/sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end) end [Avg fallback conversion Rate]

from uv_deal_calc_result calc 
where udkey_3_value ='CURRENT'

and udkey_7_value<>'Unspecified'
--and udkey_7_value='Mobile Games'
 


--and calc.contract_id ='7289'
group by 
udkey_7_value
order by 
udkey_7_value