SELECT *
FROM (
    SELECT 
        d.[Subsidiary],
        h.[RL Series ID],
        h.[RL Series Description],
        d.[Quarter],
        SUM(d.[Total Revenue]) AS Total_Revenue
    FROM (
        SELECT 
            subsidiary AS [Subsidiary],
            actual_period,
            catalogue_id AS [Catalog ID], 
            catalogue_descr AS [Catalog Name],
            income_group_descr AS [Income Group],
            territory_descr,
            date_inserted AS [Run Date],
            CASE 
                WHEN actual_period <= 202312 THEN '2023_Q4' 
                ELSE LEFT(actual_period, 4) + '_Q' + CAST(DATEPART(Q, DATEFROMPARTS(LEFT(actual_period, 4), CAST(RIGHT(actual_period, 2) AS INT), 1)) AS VARCHAR) 
            END AS [Quarter],
            STRING_AGG(status_message, '|') AS [Error],
            STRING_AGG(contract_id, '|') AS [List of deals],
            STRING_AGG(agreement_number, '|') AS [List of agreement numbers],
            transaction_count AS [number of transactions], 
            amount AS [Total Revenue]
        FROM dbo.cru_error_categorization_season season 
        WHERE catalogue_descr <> 'FUNIMATIONNOW'
        and status_message<>'Multiple Deals'
        GROUP BY 
            subsidiary,
            actual_period,
            catalogue_id, 
            catalogue_descr,
            income_group_descr,
            territory_descr,
            date_inserted,
            transaction_count, 
            amount
    ) d
    LEFT JOIN (
        SELECT 
            a.udkey_1_sid, 
            a.udkey_1_id AS [RL Catalog ID], 
            ser.parent_udkey_1_sid, 
            b.[udkey_1_id] AS [RL Series ID],
            b.[udkey1_description] AS [RL Series Description] 
        FROM [uv_udkey_1] a 
        LEFT JOIN [c_udkey_1_hierarchy] ser ON a.udkey_1_sid = ser.[udkey_1_sid]
        LEFT JOIN [uv_udkey_1] b ON b.udkey_1_sid = ser.[parent_udkey_1_sid]
        GROUP BY a.udkey_1_sid, a.udkey_1_id, ser.parent_udkey_1_sid, b.[udkey_1_id], b.[udkey1_description]
    ) h ON h.[RL Catalog ID] = d.[Catalog ID]
    GROUP BY d.Subsidiary,h.[RL Series ID], h.[RL Series Description], d.[Quarter]
) src
PIVOT (
    SUM(Total_Revenue)
    FOR Quarter IN ([2023_Q4], [2024_Q1], [2024_Q2], [2024_Q3], [2024_Q4])
) pvt
ORDER BY [RL Series ID];