select 
[udkey_5_value]+ '_' + [udkey_7_value] [Unique_ID]

 --,period_id [Quarter]
--,actual_period_id [Actual Period]
--,calc.contract_id [Deal ID]
,udkey_7_value [Income Group]
,udkey_5_value [Territory]
--,format(sum(case when [udkey_2_value]='Sale - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
--,format(sum(case when [udkey_2_value]='Return - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
--,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
--,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken - Current] 
--,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released - Current] 
--,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts Stmt - Current]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties Due - Current]
,case when sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)=0 then 0 else sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)/sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end) end [Avg conversion Rate]

--,format(sum(case when [udkey_2_value]='Historical Royalties Due' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Historical Royalties]

from uv_deal_calc_result calc 
where udkey_3_value ='CURRENT'
--and period_id='202403'
--and udkey_2_value not like '%Stmt'
and udkey_7_value<>'Unspecified'
 


--and calc.contract_id ='7289'
group by 
 --period_id
 --,actual_period_id
--,calc.contract_id
udkey_7_value
,udkey_5_value
,[udkey_5_value]+ '_' + [udkey_7_value]
having case when sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)=0 then 0 else sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)/sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end) end >0 and case when sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)=0 then 0 else sum(case when [udkey_2_value]='Royalties - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end)/sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end) end <=1
order by 
--calc.contract_id
udkey_7_value