SELECT 
      [unique_identity]
      ,BP.[udkey_10_id] [Bundle Product]
      ,BP.[descr]  [Bundle Product Description]
      ,BOM_HDR.[effective_from_date]
      ,BOM_HDR.[effective_to_date]
      ,[Netsuite Internal ID]
      ,[Old Netsuite Internal ID]
      ,[UPC_CODE]
      ,[Non Royalty]    
      ,datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) [Last Updated Date],
      datefromparts(year(GETDATE()),month(GETDATE()),day(GETDATE())) [Extract Date]
        FROM [c_udkey_10] BP 
        join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name] 
      ,[udf_value_id] [Non Royalty]

  FROM [uv_udkey_10_udf]
  where [udf_name] = 'non_royalty') NR on BP.[udkey_10_id]=NR.[udkey_10_id]
  join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name] 
      ,[udf_value_id] [Netsuite Internal ID]
  FROM [uv_udkey_10_udf]
  where [udf_name] = 'netsuite_internal_id') NS_ID on BP.[udkey_10_id]=NS_ID.[udkey_10_id]
  join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name] 
      ,[udf_value_id] [Old Netsuite Internal ID]
  FROM [uv_udkey_10_udf]
  where [udf_name] = 'old_netsuite_internal_id') ONS_ID on BP.[udkey_10_id]=ONS_ID.[udkey_10_id]
  join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name] 
      ,[udf_value_id] [UPC_CODE]
  FROM [uv_udkey_10_udf]
  where [udf_name] = 'upc_code') upc on BP.[udkey_10_id]=upc.[udkey_10_id]

  left join (select        
   udkey_10_sid,
  [effective_from_date],
  [effective_to_date] from [c_udkey_10_bom_hdr]) BOM_HDR on BP.[udkey_10_sid]=BOM_HDR.[udkey_10_sid]
        --where [udkey_10_id]= '194594014502'