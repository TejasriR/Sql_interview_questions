SELECT [period_id]
      ,[actual_period_id]
      ,[calculation_name]
      ,[udkey_10_value] [Bundle Product]
      ,[udkey_10_descr] [Bundle Product Description]
      ,[Udkey_1_value] [Catalog ID]
      ,[Udkey_1_descr] [Catalog Name]
      ,[udkey_7_value] [Income Group]
      --,[udkey_2_value] [Account]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end [Revenue_Path]
    
      ,format(sum([amount]),'C','en-US') [Total Amount]
      ,sum([qty]) [Total_Units]
      
      
  FROM [uv_deal_calc_result]
  where [calculation_sid]='1545'
  --and [udkey_10_value]='FN-01560'
  --and [udkey_1_value]='6310'

  group by 
  [period_id]
      ,[actual_period_id]
      ,[calculation_name]
      ,[actual_period_id]
      ,[udkey_10_value]
      ,[udkey_10_descr]
      --,[udkey_2_value]
      ,[Udkey_1_value]
      ,[Udkey_1_descr]
      ,[udkey_7_value] 
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end

SELECT [period_id]
      ,[calculation_name]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end [Revenue_Path]
    
      ,format(sum([amount]),'C','en-US') [Total Amount]
      ,sum([qty]) [Total_Units]
      
      
  FROM [uv_deal_calc_result]
  where [calculation_sid]='1545'
  --and [udkey_2_value]<>'Allocation Unspecified'


  group by 
  [period_id]
      ,[calculation_name]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end
        order by period_id


      SELECT [period_id]
      ,[calculation_name]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end [Revenue_Path]
      ,[udkey_7_value] [Income Group]
    
      ,format(sum([amount]),'C','en-US') [Total Amount]
      ,sum([qty]) [Total_Units]
      
      
  FROM [uv_deal_calc_result]
  where [calculation_sid]='1545'
  --and [udkey_2_value]<>'Allocation Unspecified'

  group by 
  [period_id]
      ,[calculation_name]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end
      ,[udkey_7_value]
    order BY period_id