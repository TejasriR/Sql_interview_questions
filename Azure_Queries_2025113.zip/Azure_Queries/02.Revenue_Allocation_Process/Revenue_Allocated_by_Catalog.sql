Select [Reporting Period],[Actual Period],[calculation_name],[RL Season_Movie_OVA ID],[RL Season_Movie_OVA Description],[RL Series ID],[RL Series Description],sum( [Total Amount]) [Revenue],sum( [Total_Units]) [Units] from (

SELECT [period_id] [Reporting Period]
      ,[actual_period_id] [Actual Period]
      ,[calculation_name]
      ,[Udkey_1_value] [Catalog ID]
      ,[Udkey_1_descr] [Catalog Name]
      --,[udkey_2_value] [Account]
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end [Revenue_Path]
      ,cast([period_id] as int)-cast([actual_period_id] as int) [Diff]
      ,sum([amount]) [Total Amount]
      ,sum([qty]) [Total_Units]
      
      
  FROM [uv_deal_calc_result]
  where [calculation_sid]='1545'
  and [udkey_2_value]<>'Allocation Unspecified'
  and actual_period_id<>'Unspecified'
  and actual_period_id<>'BEG OF TIME'
  and actual_period_id<>'END OF TIME'
   and actual_period_id<>'Inception'
     and period_id<>'Unspecified'
  and period_id<>'BEG OF TIME'
  and period_id<>'END OF TIME'
   and period_id<>'Inception'
  --and [udkey_10_value]='FN-01560'
  --and [udkey_1_value]='6310'

  group by 
  [period_id]
      ,[actual_period_id]
      ,[calculation_name]
      ,[actual_period_id]
      ,[Udkey_1_value]
      ,[Udkey_1_descr]
      ,cast([period_id] as int)-cast([actual_period_id] as int)
      ,case when [udkey_2_value]='Allocation Unspecified' then 'Unallocated_Revenue' else 'Allocated_Revenue' end
      having cast([period_id] as int)-cast([actual_period_id] as int)<3) RevAlloc

      join (Select [RL Catalog ID], [RL Season_Movie_OVA ID],[RL Season_Movie_OVA Description],[RL Series ID],[RL Series Description] from (
SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,'' [Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,ser.[parent_udkey_1_sid]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      --,br.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on ser.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on br.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA' or a.[udf_value]='Season' or a.[udf_value]='Music' or a.[udf_value]='Game')

  UNION all 

  SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,[Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,sea.[parent_udkey_1_sid]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      --,ser.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  join (select udkey_1_sid,udf_value [Episode Number] from uv_udkey_1_udf where udf_name='episode_number') ep_number on a.[udkey_1_sid]=ep_number.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode' ) hierarchy) h on h.[RL catalog ID]=RevAlloc.[catalog ID]

  where RevAlloc.[Catalog ID]='2760'


  group by [Reporting Period],[Actual Period],[calculation_name],[RL Season_Movie_OVA ID],[RL Season_Movie_OVA Description],[RL Series ID],[RL Series Description]

