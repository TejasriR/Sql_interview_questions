SELECT c.[udkey_10_id] [Bundle Product]
      ,c.[udf_value_id] [non_royalty]
      ,b.[descr] [Bundle Product Description]
      ,BOM.[parent_seq_nbr]
      ,BOM.[seq_nbr]
      ,BOM.[sort_order_nbr]
      ,catalogs.[udkey_1_id] [Catalog ID]
      ,catalogs.[udkey1_description] [Catalog Name]
      ,catalogs.[udf_value] [Catalog Template]
      ,BOM.[allocation_pct] [Allocation Percentage]
      ,BOM.[modified_datetime] [Last Updated]
  FROM [c_udkey_10_bom_dtl] BOM
  right join [c_udkey_10] b on BOM.[udkey_10_sid]=b.[udkey_10_sid]
  right join  (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name]
      ,[udf_value_id]
  FROM [uv_udkey_10_udf]
  where [udf_name] = 'non_royalty') c
  on b.[udkey_10_sid]=c.[udkey_10_sid]
  left join        (SELECT  a.[udkey_1_sid]
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalogs on BOM.[component_udkey_1_sid]=catalogs.udkey_1_sid 
  
  --where catalogs.[udkey_1_id]='6348'   ---by catalog
  --where c.[udkey_10_id]='FN-01560'  ---by bundle product


  --where c.[udf_value_id] = 'No'  
  --and  datefromparts(year(b.[modified_datetime]),month(b.[modified_datetime]),day(b.[modified_datetime])) >'2024-05-01'
  --and BOM.[seq_nbr] is null
  --and c.[udf_value_id] = 'Yes'  and BOM.[seq_nbr] is not null
  