SELECT a.[xref_3_descr] [API_Batch_ID],
       datefromparts(year(a.actual_period_sid_segment),month(a.actual_period_sid_segment),day(a.actual_period_sid_segment)) [Period],
       h.[RL Season_Movie_OVA ID],
       h.[RL Season_Movie_OVA Description],
       h.[RL Series ID],
       h.[RL Series Description],
       --a.[udkey_10_sid_segment] [Bundle_Product],
       --a.[udkey_7_sid_segment] [Income_Group],
       --a.[udkey_5_sid_segment] [Territory],
       --b.[company_name] [Customer_Name],
       datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date],
       getdate() [extract date],
       format(Sum(amount),'C','en-US') [Total_Amount],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  join (  Select [RL Catalog ID], [RL Season_Movie_OVA ID],[RL Season_Movie_OVA Description],[RL Series ID],[RL Series Description] from (
SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,'' [Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,ser.[parent_udkey_1_sid]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      --,br.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on ser.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on br.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA' or a.[udf_value]='Season' or a.[udf_value]='Music' or a.[udf_value]='Game')

  UNION all 

  SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,[Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,sea.[parent_udkey_1_sid]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      --,ser.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  join (select udkey_1_sid,udf_value [Episode Number] from uv_udkey_1_udf where udf_name='episode_number') ep_number on a.[udkey_1_sid]=ep_number.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode' ) hierarchy

  --where  [RL Season_Movie_OVA ID]='324919'
) h on h.[RL Catalog ID]=a.[udkey_1_sid_segment]

  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2022-03-20' and '2025-01-15' 
  --and a.[xref_3_descr] like '%SVOD%'
  --and a.[udkey_1_sid_segment] in ()
  

  group by 
  datefromparts(year(a.actual_period_sid_segment),month(a.actual_period_sid_segment),day(a.actual_period_sid_segment)),
  [xref_3_descr], 
  h.[RL Season_Movie_OVA ID],
  h.[RL Season_Movie_OVA Description],
  h.[RL Series ID],h.[RL Series Description],
  --a.[udkey_7_sid_segment],
  datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]


