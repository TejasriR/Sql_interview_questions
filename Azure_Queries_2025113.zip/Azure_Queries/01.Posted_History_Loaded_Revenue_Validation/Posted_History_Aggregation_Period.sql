SELECT a.[xref_3_descr] [API_Batch_ID], p.period_id,
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end [How_Imported],
       
       --datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date],
       getdate() [extract date],
        format(Sum(amount),'C','en-US') [Total_Amount],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a join [x_period] p on a.period_sid=p.period_sid


  

  group by [xref_3_descr],
  p.period_id,
  case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end 
  --,datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]


  