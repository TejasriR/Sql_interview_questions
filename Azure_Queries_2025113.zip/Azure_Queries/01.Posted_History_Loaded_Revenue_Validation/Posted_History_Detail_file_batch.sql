SELECT 
       [xref_3_descr] [API Batch ID]
      ,[file_download_nbr]
      ,[udkey_1_sid_segment] [Catalog ID]
      ,[udkey_10_sid_segment] [Bundle Product]
      ,[udkey_5_sid_segment] [Territory]
      ,[udkey_7_sid_segment] [Income Group]
      ,[amount]
      ,[qty] [Units]
      ,[user_comment] [Description]
  FROM [cru_master].[dbo].[x_posted_history]
  where [file_download_nbr]=36 