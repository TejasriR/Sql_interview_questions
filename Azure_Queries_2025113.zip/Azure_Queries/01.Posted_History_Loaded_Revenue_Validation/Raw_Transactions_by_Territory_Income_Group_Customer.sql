SELECT  
       [xref_3_descr] [API Batch ID]
      ,[udkey_5_sid_segment] [Territory]
      ,[udkey_4_sid_segment] [Customer]
      ,[udkey_7_sid_segment] [Income Group]
      ,datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) [Loaded Date]
      ,sum([alt_qty]) [Seconds watched]
      ,sum([amount]) [Gross Revenue]
      ,count([xref_3_descr]) Num_Records

  FROM [x_posted_history]
  where datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) >'2024-08-20'
  --and ([xref_3_descr] like '%CR_AVOD%' or [xref_3_descr] like '%CR_SVOD%') 
  group by
  [xref_3_descr], [udkey_5_sid_segment],[udkey_4_sid_segment],[udkey_7_sid_segment], datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime]))
  order by sum([amount]) desc
