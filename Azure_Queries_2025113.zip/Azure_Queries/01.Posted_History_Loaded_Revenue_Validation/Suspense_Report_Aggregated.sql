select
b.import_file_name [Import File Name],
a.file_download_nbr [Import File Number],
datefromparts(year(a.suspense_date),month(a.suspense_date),day(a.suspense_date)) [Suspense Date],
a.xref_3_descr [API Batch ID],
sum(a.amount) [Amount],
sum(a.qty) [Units],
sum(a.alt_qty) [Minutes_Watched],
count(a.unique_identity) [Number_of_Records],
getdate() [Extract Date]
from x_posted_history_suspense a
join x_import_file b
on a.import_file_sid = b.import_file_sid
group by 
b.import_file_name,
a.file_download_nbr,
datefromparts(year(a.suspense_date),month(a.suspense_date),day(a.suspense_date)),
a.xref_3_descr