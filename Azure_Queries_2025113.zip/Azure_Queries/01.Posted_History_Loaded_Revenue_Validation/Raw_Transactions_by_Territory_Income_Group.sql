SELECT  
      [udkey_5_sid_segment] [Territory],
      [udkey_7_sid_segment] [Income Group]
      
      
      ,sum([amount]) [Gross Revenue]
      ,count(udkey_5_sid_segment) [Number of Records]


  FROM [x_posted_history]
  --where datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) >'2024-06-05'
  group by   
      [udkey_5_sid_segment],
      [udkey_7_sid_segment]
