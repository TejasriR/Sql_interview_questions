SELECT
     
       a.xref_3_descr [API_BATCH_ID],
       a.period_sid_segment,
       a.[udkey_10_sid_segment] [Bundle Product],
        d.[descr] [Bundle Product Description],
        datefromparts(year(d.[modified_datetime]),month(d.[modified_datetime]),day(d.[modified_datetime])) [Bundle Product Created Date],
        c.[udf_value_id] [non_royalty],
        catalogs.[udkey_1_id] [Catalog ID],
        catalogs.[udkey1_description] [Catalog Name],
        catalogs.[udf_value] [Catalog Template],
        allocation_pct [Allocation PCT],
        case when catalogs.[udkey_1_id] is null then 'Revenue_wont_be_Allocated' else 'Revenue_will_be_Allocated' end [Revenue_Path],
        format(sum(case when catalogs.[udkey_1_id] is null then amount else allocation_pct*amount/100 end),'C','en-US') [Total_Amount_Revenue],
        count(a.xref_3_descr) [Number of Records]
        
      
  FROM x_posted_history a
       left join [c_udkey_10_bom_dtl] b on b.[udkey_10_sid]=a.[udkey_10_sid]
       left join [c_udkey_10] d on a.[udkey_10_sid]=d.[udkey_10_sid]
       left join (SELECT  a.[udkey_1_sid]
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalogs on b.[component_udkey_1_sid]=catalogs.udkey_1_sid
       left join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name]
      ,[udf_value_id]
  FROM [uv_udkey_10_udf] 
  where [udf_name] = 'non_royalty') c on a.[udkey_10_sid]=c.[udkey_10_sid]

  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-04-20'
  and a.[udkey_10_sid_segment]<>'unspecified'
  and a.[udkey_10_sid_segment] <>'0'
  --and a.[udkey_10_sid_segment] = '4580416946810'
  --and c.[udf_value_id]='no'
  --and b.allocation_pct is null
  
group By

    a.xref_3_descr,
    a.period_sid_segment,
    a.[udkey_10_sid_segment] ,
    d.[descr] ,
    datefromparts(year(d.[modified_datetime]),month(d.[modified_datetime]),day(d.[modified_datetime])) ,
    c.[udf_value_id] ,
    catalogs.[udkey_1_id],
    catalogs.[udkey1_description] ,
    catalogs.[udf_value] ,
    allocation_pct,
    case when catalogs.[udkey_1_id] is null then 'Revenue_wont_be_Allocated' else 'Revenue_will_be_Allocated' end 

  order by a.xref_3_descr

  

  SELECT
     
        case when catalogs.[udkey_1_id] is null then 'Revenue_wont_be_Allocated' else 'Revenue_will_be_Allocated' end [Revenue_Path],
        format(sum(case when catalogs.[udkey_1_id] is null then amount else allocation_pct*amount/100 end),'C','en-US') [Total_Amount_Revenue],
        count(a.xref_3_descr) [Number of Records]
      
  FROM x_posted_history a
       left join [c_udkey_10_bom_dtl] b on b.[udkey_10_sid]=a.[udkey_10_sid]
       left join [c_udkey_10] d on a.[udkey_10_sid]=d.[udkey_10_sid]
       left join (SELECT  a.[udkey_1_sid]
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalogs on b.[component_udkey_1_sid]=catalogs.udkey_1_sid
       left join (SELECT  [udkey_10_sid]
      ,[udkey_10_id]
      ,[udf_name]
      ,[udf_value_id]
  FROM [uv_udkey_10_udf] 
  where [udf_name] = 'non_royalty') c on a.[udkey_10_sid]=c.[udkey_10_sid]

  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-04-20'
  and a.[udkey_10_sid_segment]<>'unspecified'
  and a.[udkey_10_sid_segment] <>'0'

group by 
case when catalogs.[udkey_1_id] is null then 'Revenue_wont_be_Allocated' else 'Revenue_will_be_Allocated' end