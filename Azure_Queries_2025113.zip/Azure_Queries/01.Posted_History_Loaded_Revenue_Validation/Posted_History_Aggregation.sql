SELECT a.[xref_3_descr] [API_Batch_ID],
--[file_download_nbr],
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end [How_Imported],
       --a.[udkey_5_sid_segment] [Territory],
       a.[udkey_7_sid_segment] [Income_Group],
       a.actual_period_sid_segment,
       a.[udkey_1_sid_segment],
     
       --b.[company_name] [Customer_Name],
       --datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date],
       getdate() [extract date],
        format(Sum(amount),'C','en-US') [Total_Amount],
        sum(a.[qty]) [Units],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
       left join [uv_contact] b
  on b.[contact_id]=a.[udkey_4_sid_segment]
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) <'2024-12-01' 
  --and a.[xref_3_descr] ='Ecommerce_QTR_0331_2024'
  and a.[udkey_7_sid_segment] like '%simulcast'
  --and a.[udkey_1_sid_segment]<>'Funimationnow'
  

  group by 
  --[udkey_5_sid_segment]
  a.[udkey_7_sid_segment]
  ,a.[udkey_1_sid_segment]
  ,[xref_3_descr]
  ,a.actual_period_sid_segment
  --,a.[udkey_5_sid_segment]
  --[company_name],
  --[file_download_nbr]
  ,case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end 
  --datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]