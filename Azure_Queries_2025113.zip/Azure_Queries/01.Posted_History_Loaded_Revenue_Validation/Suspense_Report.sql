select
b.import_file_name [Import File Name],
a.file_download_nbr [Import File Number],
a.suspense_date [Suspense Date],
a.xref_1_descr [MW Transaction ID],
a.unique_identity [Alliant transaction ID],
a.udkey_2_sid_segment [Account],
a.udkey_2_sid [Account ID],
a.udkey_5_sid_segment [Territory],
a.udkey_5_sid [Territory ID],
a.udkey_6_sid_segment [Format],
a.udkey_6_sid [Format ID],
a.udkey_7_sid_segment [Income Group],
a.udkey_7_sid [Income Group ID],
a.user_comment [receipt name],
a.actual_period_sid_segment [Transaction Date],
a.udkey_1_sid_segment [Catalogue],
a.udkey_1_sid [Catalogue ID],
a.suspense_date [Import Date],
a.udkey_10_sid_segment [Bundle Product],
a.udkey_10_sid [Bundle Product ID],
a.xref_3_descr [API Batch ID],
a.amount [Amount],
a.udkey_17_sid_segment [Currency],
a.udkey_17_sid [Currency ID],
a.qty [Units],
getdate() [Extract Date]
from x_posted_history_suspense a
join x_import_file b
on a.import_file_sid = b.import_file_sid
--where datefromparts(year(a.[suspense_date]),month(a.[suspense_date]),day(a.[suspense_date])) >'2024-05-02'

