SELECT  
       [xref_3_descr] [API Batch ID]
      ,[udkey_4_sid_segment] [Customer]
      ,[udkey_7_sid_segment] [Income Group]
      --,sum([alt_qty]) [Seconds watched]
      ,sum([amount]) [Gross Revenue]

  FROM [x_posted_history]
  where datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) >'2024-05-20'
  --and ([xref_3_descr] like '%CR_AVOD%' or [xref_3_descr] like '%CR_SVOD%') 
  and [udkey_10_sid_segment]='SEA2899001-51_113' ---bundle product

  group by
  [xref_3_descr], [udkey_4_sid_segment], [udkey_7_sid_segment]
  order by sum([amount]) desc