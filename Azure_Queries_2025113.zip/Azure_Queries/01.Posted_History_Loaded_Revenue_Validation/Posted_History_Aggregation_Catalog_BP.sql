SELECT a.[xref_3_descr] [API_Batch_ID],[file_download_nbr],
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end [How_Imported],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_10_sid_segment] [Bundle_Product],
       a.[udkey_7_sid_segment] [Income_Group],
       b.[company_name] [Customer_Name],
       datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date],
       getdate() [extract date],
       format(Sum(amount),'C','en-US') [Total_Amount],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
       left join [uv_contact] b
  on b.[contact_id]=a.[udkey_4_sid_segment]
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-05-20' 
  and a.[xref_3_descr] like '%SVOD%'
  

  group by [udkey_1_sid_segment],a.[udkey_7_sid_segment],a.[udkey_10_sid_segment],[xref_3_descr],[company_name],[file_download_nbr],
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end, datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]