select
xref_3_descr [API_BATCH_ID],
udkey_10_sid_segment [Bundle Product],
'' [Bundle Prodduct Description],
'' [Netsuite internal id],
case when left([udkey_10_sid_segment],3)='SEA' then 'No'  else  '' END [Non Royalty],
case when ISNUMERIC([udkey_10_sid_segment])=1 then [udkey_10_sid_segment]  else  ''  END [UPC Code],
'' [Subsidiary],
datefromparts(year(GETDATE()),month(GETDATE()),day(GETDATE())) [Extract Date]

from x_posted_history_suspense
where udkey_10_sid is null
--and udkey_10_sid_segment='703558839930'
group by xref_3_descr,udkey_10_sid_segment


