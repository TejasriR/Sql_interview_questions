SELECT a.[xref_3_descr] [API_Batch_ID],[file_download_nbr],
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end [How_Imported],
       a.[udkey_10_sid_segment] [Bundle_Product],
       case when (a.[udkey_1_sid_segment] like 'FUNIM%' ) then 'FUNIMATIONNOW' else (
       case when (a.[udkey_10_sid_segment] = 'unspecified' or a.[udkey_10_sid_segment] = '0') then 'At_Catalog_Level' else 'At_Bundle_Product_Level' end) end  [Gross_Revenue_Level]
       
       ,datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date],
       getdate() [extract date],
        FORMAT(Sum(amount),'C', 'en-us') [Total_Amount],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a

  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))between '2025-10-10' and '2025-10-10'
  --and a.[udkey_10_sid_segment]<>'unspecified'
  --and a.[udkey_10_sid_segment] <>'0'
    and [file_download_nbr] = 215

  group by 
  a.[udkey_10_sid_segment],
case when (a.[udkey_1_sid_segment] like 'FUNIM%' ) then 'FUNIMATIONNOW' else (
       case when (a.[udkey_10_sid_segment] = 'unspecified' or a.[udkey_10_sid_segment] = '0') then 'At_Catalog_Level' else 'At_Bundle_Product_Level' end) end,
  [xref_3_descr],
  [file_download_nbr],
case when ([import_file_sid]=177) then 'Manually' else 'Via_API' end, datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]


  SELECT 
              case when (a.[udkey_1_sid_segment] like 'FUNIM%' ) then 'FUNIMATIONNOW' else (
       case when (a.[udkey_10_sid_segment] = 'unspecified' or a.[udkey_10_sid_segment] = '0') then 'At_Catalog_Level' else 'At_Bundle_Product_Level' end) end  [Gross_Revenue_Level],
    
        FORMAT(Sum(amount),'C', 'en-us') [Total_Amount],
        Sum(alt_qty) [Total_Minutes_Watched],
        count(row_identity) [Number_of_Records]

  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-03-01' 
  and file_download_nbr=1
  group by 
         case when (a.[udkey_1_sid_segment] like 'FUNIM%') then 'FUNIMATIONNOW' else (
       case when (a.[udkey_10_sid_segment] = 'unspecified' or a.[udkey_10_sid_segment] = '0') then 'At_Catalog_Level' else 'At_Bundle_Product_Level' end) end