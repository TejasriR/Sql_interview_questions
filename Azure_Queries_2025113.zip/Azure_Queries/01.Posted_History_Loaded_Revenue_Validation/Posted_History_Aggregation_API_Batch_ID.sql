SELECT 
a.[xref_3_descr] [API_Batch_ID]
,[file_download_nbr]
,import_file_name
,datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Loaded Date]
,getdate() [extract date]
,format(Sum(amount),'G','en-US') [Total_Amount]
,format(Sum(round(amount,2)),'G','en-US') [Total_Amount_Rounded]
,Sum(alt_qty) [Total_Minutes_Watched]
,count(row_identity) [Number_of_Records]
      
  FROM uv_posted_history a
       left join [uv_contact] b
  on b.[contact_id]=a.[udkey_4_sid_segment]
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2025-10-10' and '2025-10-20'


  group by 
  [xref_3_descr]
  ,[file_download_nbr]
  , import_file_name
  ,datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime]))
  order by [xref_3_descr]


  