
SELECT [Contract SID], [Contract ID], [Catalog ID], [Catalog Name], [Catalog Template], [number of episodes] from

(---- deal with rights at catalog level

SELECT contract_sid [Contract SID]
,contract_id [Contract ID]
,udkey_1_value [Catalog ID]
,udkey_1_descr [Catalog Name]
,template.template [Catalog Template]
,(case when template.template<>'Season' then 1 else count(distinct h.[child catalog]) end) [number of episodes]
  FROM [uv_contract_rights] udk1
  left join (select udkey_1_sid, udkey_1_id, udf_value [Template] from [uv_udkey_1_udf] where udf_name='entity_template') template on template.udkey_1_id=udk1.udkey_1_value
  
  left join (select udkey_1_sid [child catalog],hierarchy_level_nbr, parent_udkey_1_sid from c_udkey_1_hierarchy) h on h.parent_udkey_1_sid=udk1.udkey_1_sid
  where udkey_1_value is not null
  --and contract_id='75'
  group by contract_sid,contract_id, udkey_1_value,udkey_1_descr,template.template) catalog_level
  --where catalog_level.[Contract ID]='7592'

Union SELECT [Contract SID], [Contract ID], [Catalog ID], [Catalog Name], [Catalog Template], [number of episodes] from 

(---- deal with rights at catalog list level

SELECT udk1.contract_sid [Contract SID]
,udk1.contract_id [Contract ID]
,udkl1.dtl_udkey1_id [Catalog ID]
,udkl1.dtl_udkey1_description [Catalog Name]
,template.template [Catalog Template]
,(case when template.template<>'Season' then 1 else count(distinct h.[child catalog]) end) [number of episodes]
  FROM [uv_contract_rights] udk1 
  join [uv_udkey_1_lists] udkl1 on udkl1.udkey_1_group_sid=udk1.udkey_1_group_sid
  
  left join (select udkey_1_sid, udkey_1_id, udf_value [Template] from [uv_udkey_1_udf] where udf_name='entity_template') template on template.udkey_1_id=udkl1.dtl_udkey1_id

  left join (select udkey_1_sid [child catalog],hierarchy_level_nbr, parent_udkey_1_sid from c_udkey_1_hierarchy) h on h.parent_udkey_1_sid=udkl1.dtl_udkey_1_sid
   

  where udk1.udkey_1_group_sid is not null
  --and contract_id='75'
  group by udk1.contract_sid,udk1.contract_id, udk1.udkey_1_group_sid,udkl1.dtl_udkey1_id ,udkl1.dtl_udkey1_description,template.template
   ) Catalog_List_Level

--where Catalog_List_Level.[Contract ID]='7592' 
   order by [Contract ID]