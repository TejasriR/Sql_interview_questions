SELECT
a.[contract_id] [Contract_ID]
,cont.contract_description [Contract Name]
,cont.[contract_status_id]
,[Udf_name]
,[Seq_nbr]
,[sort_order_nbr]
,[udkey_7_value] [Income group]
,[price_point_range]
,user_contact_id [Contact ID]
,[formatted_name] Participant
,[Value] [Split]



  FROM [uv_contract_udf_lookup] a left join [c_contact] c on c.contact_id=a.user_contact_id
  left join [uv_contract] cont on cont.contract_sid=a.contract_sid

  
  
  where udf_name='ParticipantShareSplit'
  and [contract_status_id] in ('COMPLETE','INSETUP','ACTIVE','APPROVED','INREVISION')
  and [formatted_name] is null
  --and cont.contract_id='3276'

  group BY
  a.[contract_id] 
  ,cont.contract_description
,cont.[contract_status_id]
,[Udf_name]
,[Seq_nbr]
,[sort_order_nbr]
,[udkey_7_value] 
,[price_point_range]
,user_contact_id
,[formatted_name]
,[Value]