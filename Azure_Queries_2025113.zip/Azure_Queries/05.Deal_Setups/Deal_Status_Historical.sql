

Select  [Deal ID],[Deal Name],[Selected Date],STRING_AGG([revision number],'-->') [Revision], string_agg([Deal Calculation Status Historical],'-->') [Deal Calculation Status Historical]

from

(SELECT

[Deal ID],
[Deal Name],
[Selected Date],
[revision number],
--[Deal Revision Creation Date],
--[Deal Revision Approved Date],
--[Deal Next Revision creation Date],


Case when (([Selected Date] >= C_Audit.[Deal Revision Approved Date] and [Selected Date] <= C_Audit.[Deal Next Revision creation Date]) or ([selected date] >= C_Audit.[Deal Revision approved Date] and c_audit.[Deal Next Revision creation Date] is null)) then 'Active' 

else 

case when ([Selected Date] >= C_Audit.[Deal Revision Creation Date] and [Selected Date]<=C_Audit.[Deal Revision Approved Date] or ([selected date] >= C_Audit.[Deal Revision Creation Date] and c_audit.[Deal Revision Approved Date] is null)) then 'Not Active' else 'xx' end end [Deal Calculation Status Historical]
 
from 
 (SELECT 

  c.contract_id [Deal ID]
  ,c.revision_nbr [Revision Number]
  ,c.contract_description [Deal Name]
  ,c.contract_id+'-'+cast(c.revision_nbr as varchar) [Contract and Revision]
   ,c.contract_id+'-'+cast(c.revision_nbr +1 as varchar) [Contract and Next Revision]

  ,datefromparts(year(c.revision_eff_date),month(c.revision_eff_date),day(c.revision_eff_date)) [Deal Revision Creation Date]
  ,datefromparts(year(c.approved_datetime),month(c.approved_datetime),day(c.approved_datetime)) [Deal Revision Approved Date]
     ,c2.[Deal Revision Creation Date] [Deal Next Revision creation Date]
  ,[Latest Revision Date] 
  ,[Latest Deal Activation Date] 
  ,c.contract_status_id
  ,1 [ID]


  from uv_contract c 
  join (select contract_id [Deal_ID],max(datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date))) [Latest Revision Date], max(datefromparts(year(approved_datetime),month(approved_datetime),day(approved_datetime))) [Latest Deal Activation Date] from uv_contract group by contract_id) cm on cm.deal_id=c.contract_id  
  
  --where datefromparts(year(c.revision_eff_date),month(c.revision_eff_date),day(c.revision_eff_date))<'2025-02-15'
  left join (select 
  
  contract_id,
  revision_nbr,
  contract_id+'-'+cast(revision_nbr as varchar) [Contract with Revision],
  datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date)) [Deal Revision Creation Date]
  ,approved_datetime [Deal Revision Approved Date]
  
  
    from uv_contract) c2 on c2.[Contract with Revision]=c.contract_id+'-'+cast(c.revision_nbr +1 as varchar)

  group BY

    c.contract_id 
  ,c.revision_nbr 
  ,c.contract_description
   ,c.contract_id+'-'+cast(c.revision_nbr as varchar)
  ,datefromparts(year(c.revision_eff_date),month(c.revision_eff_date),day(c.revision_eff_date)) 
  ,c.approved_datetime 
  ,[Latest Revision Date] 
  ,[Latest Deal Activation Date] 
 ,c2.[Deal Revision Creation Date]
,c.contract_status_id ) C_Audit

 join (Select 
'2024-11-20' [Selected Date], 1 [ID] ) s_date on s_date.ID=c_audit.ID

--where [Deal ID]='10348'
group by 

[Deal ID],
[Deal Name],
[Selected Date],
[revision number],
--[Deal Revision Creation Date],
--[Deal Revision Approved Date],
--[Deal Next Revision creation Date],


case when (([Selected Date] >= C_Audit.[Deal Revision Approved Date] and [Selected Date] <= C_Audit.[Deal Next Revision creation Date]) or ([selected date] >= C_Audit.[Deal Revision approved Date] and c_audit.[Deal Next Revision creation Date] is null)) then 'Active' 

else 

case when ([Selected Date] >= C_Audit.[Deal Revision Creation Date] and [Selected Date]<=C_Audit.[Deal Revision Approved Date] or ([selected date] >= C_Audit.[Deal Revision Creation Date] and c_audit.[Deal Revision Approved Date] is null)) then 'Not Active' else 'xx' end end



 having 

case when (([Selected Date] >= C_Audit.[Deal Revision Approved Date] and [Selected Date] <= C_Audit.[Deal Next Revision creation Date]) or ([selected date] >= C_Audit.[Deal Revision approved Date] and c_audit.[Deal Next Revision creation Date] is null)) then 'Active' 

else 

case when ([Selected Date] >= C_Audit.[Deal Revision Creation Date] and [Selected Date]<=C_Audit.[Deal Revision Approved Date] or ([selected date] >= C_Audit.[Deal Revision Creation Date] and c_audit.[Deal Revision Approved Date] is null)) then 'Not Active' else 'xx' end end <>'xx') Query


group BY [Deal ID],[Selected Date],[Deal Name]

 order by [Deal ID]