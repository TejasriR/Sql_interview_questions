      select [contract_status_id] [Deal_Status], count(contract_id) [Number of Deals]
      from [uv_contract]
      where [contract_status_id] in ('COMPLETE','INSETUP','ACTIVE','APPROVED','INREVISION')
      group by [contract_status_id]



SELECT a.contract_id,[Agreement Number],[enumerated_id] [Master Status],[Contract Start Date],[Contract End Date], [Deal_Status],[Deal_Management_Status_Notes],[Statement Due Days],[Statement Start Date],[Accrual Start Date]  from 
(Select
      [contract_id], [udf_name], [udf_value] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) a 
      join (select [contract_id], [udf_name], [udf_value] [Deal_Management_Status_Notes]
      from [uv_contract_udf] 
      where [udf_name] in ('DealManagementStatusNotes')) b on a.contract_id=b.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Statement Due Days]
      from [uv_contract_udf] 
      where [udf_name] in ('StatementDueDays')) d on a.contract_id=d.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Statement Start Date]
      from [uv_contract_udf] 
      where [udf_name] in ('StatementStartDate')) e on a.contract_id=e.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Accrual Start Date]
      from [uv_contract_udf] 
      where [udf_name] in ('AccrualStartDate')) f on a.contract_id=f.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] 
      where [udf_name] in ('agreement_Integer')) g on a.contract_id=g.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Contract Start Date]
      from [uv_contract_udf] 
      where [udf_name] in ('contract_term_start')) h on a.contract_id=h.contract_id
      join (select [contract_id], [udf_name], [udf_value] [Contract End Date]
      from [uv_contract_udf] 
      where [udf_name] in ('contract_term_end')) i on a.contract_id=i.contract_id
      left join [uv_datatype_enumerated_value] c on c.[enumerated_sid]=a.[Master_Status]
      where deal_status in ('COMPLETE','INSETUP','ACTIVE','APPROVED','INREVISION')
      --where a.[contract_id]='9527'
      group by a.contract_id,[Agreement Number],[enumerated_id] , [Deal_Status],[Contract Start Date],[Contract End Date],[Statement Due Days],[Deal_Management_Status_Notes],[Statement Start Date],[Accrual Start Date]




Select
      c.[enumerated_id] [Master_Status],count(contract_id) [Number of Deals]
      from [uv_contract_udf] a  left join [uv_datatype_enumerated_value] c on c.[enumerated_sid]=a.udf_value
      where [udf_name] in ('masterstatus')
      and status_id in ('COMPLETE','INSETUP','ACTIVE','APPROVED')
      group by c.[enumerated_id]
      order by c.[enumerated_id] asc