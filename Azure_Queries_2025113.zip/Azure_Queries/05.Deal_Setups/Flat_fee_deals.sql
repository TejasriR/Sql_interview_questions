SELECT beg_balances.contract_id [Deal ID],
c.[Agreement Number], beg_balances.contract_descr [Deal Name], udkey_2_descr [Balance_Type]

FROM [uv_adjustment_contract_dtl] beg_balances join (SELECT 
     [contract_id], [udf_name], [udf_value] [Agreement Number]
     from [uv_contract_udf] where udf_name = 'Agreement_integer') c on c.contract_id=beg_balances.contract_id
  
where udkey_2_descr = 'Non-Recoupable Flat Fee Adjustment'
group by beg_balances.contract_id, c.[Agreement Number],beg_balances.contract_descr,udkey_2_descr