SELECT 
uv.contract_id,uv.contract_status_id [Contract_Status], [Udf_name], [Seq_nbr], [Account],[income group],[Income_Group_List], [Deduction_Basis]

from [uv_contract] uv left join (SELECT
[contract_sid]
,[contract_id]
,[Udf_name]
,[Seq_nbr]
,[udkey_2_value] [Account]
,[udkey_7_value] [Income Group]
,[udkey_7_group_descr] [Income_Group_List]
,udf_value_id [Deduction_Basis]



  FROM [uv_contract_udf_lookup] where udf_name='DeductionCalculationBehavior') c on c.[contract_sid]=uv.contract_sid
  where uv.contract_status_id<>'PRIORREVISION'
  --and c.[contract_id]='10061'
  order by uv.contract_id
