SELECT 
xc.contract_id, [Udf_name], [Seq_nbr],[sort_order_nbr], [Account], [Deduction_Basis]

from [x_contract] xc left join (SELECT
[contract_id]
,[Udf_name]
,[Seq_nbr]
,[sort_order_nbr]
,[udkey_2_value] [Account]
,udf_value_id [Deduction_Basis]



  FROM [uv_contract_udf_lookup] where udf_name='DeductionBasisRM') c on c.[contract_id]=xc.contract_id
  order by xc.contract_id
  
  
