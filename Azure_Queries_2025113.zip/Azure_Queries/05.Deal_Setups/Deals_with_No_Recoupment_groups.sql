SELECT 
      [x_contract].[contract_id]
    , rec_group.[udf_name]
     
  FROM [cru_master].[dbo].[x_contract]
left join (SELECT [contract_sid]
      ,[contract_id]
      ,[udf_sid]
      ,[udf_name]

  FROM [cru_master].[dbo].[uv_contract_udf_lookup]

  
  where udf_name='Recoupmentgroup') rec_group on rec_group.[contract_id]=x_contract.[contract_id]
  where udf_name is null

  group by       [x_contract].[contract_id], rec_group.[udf_name]
  