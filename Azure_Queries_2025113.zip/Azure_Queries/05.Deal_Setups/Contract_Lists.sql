SELECT 
    [contract_list_sid]
      ,[contract_list_description]
      ,[contract_list_modified_by_user_name]
      ,[contract_id] 
      ,[contract_list_detail_modified_by_user_name]
      ,[contract_list_detail_modified_datetime]
     
  FROM [dbo].[uv_contract_lists]
  where [contract_list_description] = 'O_and_O_Alignment_priority2_deals_to_Approve'
  --and [contract_id] ='5758'