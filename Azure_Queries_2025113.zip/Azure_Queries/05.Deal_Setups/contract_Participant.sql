SELECT contract_id
      ,c.contact_id
      ,c.company_name
      ,ctype.contact_type_id
  FROM [cru_master].[dbo].[v_contract_participant] cp 
  join [x_contract] ct on ct.contract_sid=cp.contract_sid
  join [c_contact] c on c.contact_sid=cp.contact_sid
  join [c_contact_type] ctype on c.contact_type_sid=ctype.contact_type_sid
