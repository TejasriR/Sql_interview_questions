SELECT a.[contract_id] [Deal ID]
,b.[Agreement Number]
,b.status_id [Contract Status]
,a.[Udf_name] [Table_Name]
,a.start_actual_period_id
,a.end_actual_period_id
,a.[Seq_nbr]
,a.[sort_order_nbr]
,a.[udkey_1_value] [Catalog ID]
,a.[udkey_1_group_descr] [Catalog_List]
,a.[udkey_7_value] [Income group]
,a.[udkey_7_group_descr] [Income_Group_List]
,case when (a.[udkey_5_value] is null) then 'All' else a.[udkey_5_value] end [Territory]
,a.[udkey_6_value] [Format]
,a.[price_point_range]
,a.[Value] [Royalty Rate]
,a.modified_by_user_id

  FROM [uv_contract_udf_lookup] a join (SELECT 
      [contract_id],[contract_sid], [udf_name],[status_id], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') b on a.contract_sid=b.contract_sid
 
  where a.udf_name='EscalationRoyaltyRates'
  and b.status_id<>'PRIORREVISION'
  --and a.contract_id='1006'
 