select 
a.contract_id [Deal ID],
d.contract_status_id [contract status], 
seq_nbr [Sequence Number],
sort_order_nbr [Sort Order], 
a.start_actual_period_id [Start], 
a.end_actual_period_id [End],
a.udkey_6_value [Format],
a.udkey_4_group_descr [Customer_List_Name],
a.udkey_7_value [Income Group],
a.udkey_7_group_descr [Income_Group_List_Name], 
a.udkey_5_value [Territory], 
a.udkey_5_group_descr [Territory_List_Name], 
--a.udkey_11_Value [Language], 
a.udkey_1_value [Catalog ID], 
a.udkey_1_descr [Catalog Name], 
a.udkey_1_group_descr [Catalog List],
a.modified_datetime [Last Updated],
a.modified_by_user_name [Last Updated By],
datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
from
uv_contract_rights a
join (select contract_sid, ctr.contract_id, contract_status_id, latest_revision, revision_nbr, case when latest_revision=revision_nbr then 'Yes' else 'No' end [Current_Revision] from uv_contract ctr join  

(select contract_id,max(revision_nbr) [latest_revision] from uv_contract group by contract_id) max on max.contract_id=ctr.contract_id

) 
d on d.contract_sid = a.contract_sid
where Current_Revision='Yes'
--where b.active_revision_flag = 'Y'
--and contract_status_id<>'PRIORREVISION'
--and a.contract_id = '5712' 
--and a.udkey_6_value is not null
--and a.udkey_4_group_descr is not null
--and a.udkey_4_value is not null
--and a.modified_by_user_name like '%Crunchyroll'