
  SELECT 
  --adj.adjustment_sid
  --adj.item_sid [contract_sid]
  c.contract_id
  ,period_id
  ,actual_period_id
  ,[Agreement Number]
  ,adj_det.udkey_2_id [Account]
  ,udkey_15_descr [Recoupment Group]
  ,sum(adj_det.amount) [amount]

  FROM x_adjustment_hdr adj 
  join uv_contract c on adj.item_sid=c.contract_sid
  join uv_adjustment_contract_dtl adj_det on adj.adjustment_sid=adj_det.adjustment_sid
  left join (select adjustment_sid from [uv_contract_posted_period] group by adjustment_sid ) cp on adj_det.adjustment_sid=cp.adjustment_sid
  join x_adjustment_hdr xa on xa.adjustment_sid=adj_det.adjustment_sid
   
  join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) an on an.contract_sid=c.contract_sid

  where c.contract_status_id<>'PRIORREVISION'
  --and adj_det.udkey_2_id='Minimum Guarantee'
  and xa.status_sid<>11
    --and c.contract_id in ('9115')
  group by 
    --adj.adjustment_sid
   -- adj.item_sid
  adj_det.udkey_2_id
  ,c.contract_id
  ,[Agreement Number]
  ,period_id
  ,udkey_15_descr
  ,actual_period_id

