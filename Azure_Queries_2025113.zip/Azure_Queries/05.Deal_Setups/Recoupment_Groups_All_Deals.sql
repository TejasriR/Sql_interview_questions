SELECT a.[contract_id] [Deal ID]
,b.[Agreement Number]
,[Anaplan ID]
,b.status_id
,a.[Udf_name] [Table_Name]
,a.[Seq_nbr]
,a.[udkey_7_value] [Income group]
,a.[udkey_1_value] [Catalog ID]
,Catalogs.[Descr] [Catalog Name]
,case when (a.[udkey_5_value] is null) then 'All' else a.[udkey_5_value] end [Territory]
,a.[udf_Value_id] [Recoupment_Group]

  FROM [uv_contract_udf_lookup] a 
  join (SELECT 
      [contract_id],contract_sid, [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') b on a.contract_sid=b.contract_sid
  join (SELECT 
      [contract_id],contract_sid, [udf_name], [udf_value] [Anaplan ID]
      from [uv_contract_udf] where udf_name = 'Anaplan_ID') c on c.[contract_sid]=a.[contract_sid]

  left join [c_udkey_1] Catalogs on Catalogs.[udkey_1_id]=a.[udkey_1_value]
    
    
  where a.udf_name = 'RecoupmentGroup'
  and [status_id] in ('COMPLETE','INSETUP','ACTIVE','APPROVED','INREVISION')
  --and a.contract_id='3228'

--Tables

--AccountNameStmt
--EscalationRateNotes
--ReserveRate
--DeductionPercentOfGrossNotes
--RoyaltyRateNotes
--CapBehavior
--DeductionPercentOfGross
--OrderOfDeductions
--ParticipantShareSplit
--DeductionBasisRM
--ReserveNotes
--DeductionPercentOfRoyaltiesNotes
--RoyaltyRatePercentOfNetReceipts
--DeductionCalculationBehavior
--RecoupmentGroup
--EscalationRoyaltyRates
--OffTheTop
--DeductionPercentOfRoyalties
--SuspendedAccounts