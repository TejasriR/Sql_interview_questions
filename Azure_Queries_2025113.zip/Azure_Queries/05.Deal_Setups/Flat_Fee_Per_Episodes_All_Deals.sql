SELECT a.[contract_id] [Deal ID]
,b.[Agreement Number]
,a.[Udf_name] [Table_Name]
,a.[Seq_nbr]
,a.[udkey_7_value] [Income group]
,a.[udkey_1_value] [Catalog ID]
,Catalogs.[Descr] [Catalog Name]
,case when (a.[udkey_5_value] is null) then 'All' else a.[udkey_5_value] end [Territory]
,a.[Value] [Reserve Rate]

  FROM [uv_contract_udf_lookup] a 
  join (SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') b on a.contract_id=b.contract_id
  left join [c_udkey_1] Catalogs on Catalogs.[udkey_1_id]=a.[udkey_1_value]
    
    
  where a.udf_name = 'RoyaltyRateFlatAmountPerEpisode'
  --and a.contract_id='1007'

--Tables

--AccountNameStmt
--EscalationRateNotes
--ReserveRate
--DeductionPercentOfGrossNotes
--RoyaltyRateNotes
--CapBehavior
--DeductionPercentOfGross
--OrderOfDeductions
--ParticipantShareSplit
--DeductionBasisRM
--ReserveNotes
--DeductionPercentOfRoyaltiesNotes
--RoyaltyRatePercentOfNetReceipts
--DeductionCalculationBehavior
--RecoupmentGroup
--EscalationRoyaltyRates
--OffTheTop
--DeductionPercentOfRoyalties
--SuspendedAccounts
--RoyaltyRateFlatAmountPerEpisode