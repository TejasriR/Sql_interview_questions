SELECT [udkey7_list_description] [List Name]
      ,[modified_by_user_name]
      ,[modified_datetime]
      ,[dtl_udkey7_description] [Income Group Contained]

  FROM [uv_udkey_7_lists]

--filter on list name

  --where udkey7_list_description='3PL Advertising Video on Demand|3PL Electronic Sell Thru|3PL Subscription Video on Demand|3PL Transactional Video on Demand|Blu-ray|Blu-ray+Digital|DTC Advertising Video on Demand|DTC Subscription Video on Demand|DVD|DVD+Digital'