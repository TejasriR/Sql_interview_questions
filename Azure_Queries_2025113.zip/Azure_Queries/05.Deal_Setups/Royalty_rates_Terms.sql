select
b.contract_id,
a.contract_description [Contract Description],
  b.Sort_order_nbr [Sort Order Number],
  Coalesce (b.start_Actual_Period_id, 'Min') [Start Period],
  Coalesce (b.end_actual_period_id, 'Max') [End Period],
  Coalesce (b.udkey_1_value, 'All') [Catalogue Description],
  Coalesce (b.udkey_1_group_descr, 'All') [Catalogue List],
  Coalesce (b.udkey_7_value,'All') [Income Group Description],
  Coalesce (b.udkey_7_group_descr, 'All') [Income Group List],
  Coalesce (b.udkey_5_value,'All') [Territory Description],
  Coalesce (b.udkey_5_group_descr,'All')[Territory List],
  Coalesce (b.udkey_6_value,'All') [Format Description],
  Coalesce (b.udkey_6_group_descr,'All')[Format List],
  Coalesce (b.udkey_4_value,'All') [Customer Description],
  Coalesce (b.udkey_4_group_descr,'All')[Customer List],
  Coalesce (b.price_point_range,'All')[SRP Range],
  b.udf_name [UDF Name],
  b.value [Value]
  
from
 uv_contract_udf_lookup b
 join uv_contract a
 on a.contract_sid = b.contract_sid
 where b.udf_name = 'RoyaltyRatePercentOfNetReceipts' 
 and a.original_contract_sid = a.contract_sid
 
 Order by contract_id ASC