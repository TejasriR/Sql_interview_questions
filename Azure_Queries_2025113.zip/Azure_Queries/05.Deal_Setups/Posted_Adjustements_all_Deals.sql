SELECT [contract_id]
      ,[udkey_2_value] [Account]
      ,[udkey_15_value] [Recoupment Group]
      ,[amount]
      ,modified_datetime [Last Updated]
  FROM [cru_master].[dbo].[uv_contract_posted_period]
   where udkey_2_value='Minimum Guarantee'
  --where contract_id='2649'


------ contract value per deal

  SELECT cp.contract_sid [contract_sid],cp.[contract_id],c.active_revision_flag,sum([amount]) [contract value]
  FROM [uv_contract_posted_period] cp join uv_contract c on c.contract_sid=cp.contract_sid
  where udkey_2_value='Minimum Guarantee'
  --and c.active_revision_flag='Y'
  and c.contract_status_id<>'PRIORREVISION'
  group by cp.contract_sid, cp.contract_id,c.active_revision_flag