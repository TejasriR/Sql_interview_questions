SELECT 
      [contract_id]
      ,R.[udkey_5_group_sid]
      ,[udkey_5_group_descr]
      ,[dtl_udkey5_id]
  FROM [uv_contract_rights] R join [uv_udkey_5_lists] List on list.[udkey_5_group_sid]=R.[udkey_5_group_sid]
  where [contract_id]='7417'

 group by 
 [contract_id]
      ,R.[udkey_5_group_sid]
      ,[udkey_5_group_descr]
      ,[dtl_udkey5_id]

  order by [contract_id]