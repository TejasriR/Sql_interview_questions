SELECT [seq_nbr]
      ,b.[contract_id] [Deal ID]
      ,[Agreement Number]
      ,[Anaplan ID]
      ,accounts.[udkey_2_id] [Account]
      ,X.[udkey_15_id] [Recoupment Group]
      ,[amount]
      ,[alt_user_comment]
      ,adj.[comment]
      ,adj.[modified_datetime]
    FROM [x_adjustment_contract_dtl] Adj 
    join [c_udkey_2] accounts on adj.[udkey_2_sid]=accounts.[udkey_2_sid]
    join [c_udkey_15] X on adj.[udkey_15_sid]=X.[udkey_15_sid]
    join (SELECT 
      [contract_sid], [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') b on b.[contract_sid]=adj.[contract_sid]
    join (SELECT 
      [contract_sid], [contract_id], [udf_name], [udf_value] [Anaplan ID]
      from [uv_contract_udf] where udf_name = 'Anaplan_ID') c on c.[contract_sid]=adj.[contract_sid]
  --where contract_id='4299'