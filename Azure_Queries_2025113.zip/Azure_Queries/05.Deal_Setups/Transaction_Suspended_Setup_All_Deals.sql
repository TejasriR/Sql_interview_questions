select 
c.Contract_ID [Deal ID]
,[Udf_Name]
,seq_nbr
,'' [Start_Period]
,datefromparts(left([end_actual_period_id],4),right([end_actual_period_id],2),'1') [End_Period]
,udkey_1_value [Catalog ID]
,udkey_7_value [Income Group]
,udkey_5_value [Territory]
,udf_value_id [UDF_Value]
--,contract_status_id
from [uv_contract_udf_lookup] c_udf 
join [uv_contract] c on c.contract_sid=c_udf.contract_sid 

where udf_name='TransactionSuspended'
and [contract_status_id] in ('COMPLETE','INSETUP','ACTIVE','APPROVED','INREVISION')
--and c.active_revision_flag='Y'
--and c.contract_id='5712'


