SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,a.[udf_value] [RL Catalog Template]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA')