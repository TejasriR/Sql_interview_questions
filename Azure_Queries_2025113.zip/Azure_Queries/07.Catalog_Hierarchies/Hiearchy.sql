select
a.udkey_1_sid,
a.hierarchy_level_nbr,
a.parent_udkey_1_sid,
b.udkey_1_id,
d.udkey_1_id as parent_RL_id,
c.udf_value
from
c_udkey_1_hierarchy a
join c_udkey_1 b
on a.udkey_1_sid = b.udkey_1_sid
join uv_udkey_1_udf c
on a.udkey_1_sid = c.udkey_1_sid
left join c_udkey_1 d
on a.parent_udkey_1_sid = d.udkey_1_sid
where udf_name = 'entity_template'