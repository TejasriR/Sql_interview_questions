SELECT  a.[udkey_1_sid]
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value] [Catalog Template]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template'