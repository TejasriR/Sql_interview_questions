Select [RL Catalog ID] from (
SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,'' [Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,ser.[parent_udkey_1_sid]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      --,br.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on ser.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on br.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA' or a.[udf_value]='Season' or a.[udf_value]='Music' or a.[udf_value]='Game')

  UNION all 

  SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,[Episode Number]
      ,a.[udf_value] [RL Catalog Template]
      --,sea.[parent_udkey_1_sid]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      --,ser.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  join (select udkey_1_sid,udf_value [Episode Number] from uv_udkey_1_udf where udf_name='episode_number') ep_number on a.[udkey_1_sid]=ep_number.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode' ) query

  where  [RL Season_Movie_OVA ID]='336261'
