select 
 period_id [Period]
,contract_id
--,[udkey_2_value]
--,udkey_3_value
--,sum(amount) total
,format(sum(case when [udkey_2_value]='Cutover Reserves Balance' AND udkey_3_value='ITD' then amount else 0 end),'G','en-US') [initial reserve balance] 
,format(sum(case when [udkey_2_value]='Reserves Taken' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Reserves Taken]
,format(sum(case when [udkey_2_value]='Reserves Released' AND udkey_3_value='Current' then amount else 0 end),'G','en-US') [Reserves Released]
,format(sum(case when [udkey_2_value]='Final Reserve Balance' AND udkey_3_value='ITD' then -amount else 0 end),'G','en-US') [Final reserve balance] 
from uv_deal_calc_result
where period_id='202403'
  --and udkey_3_value='Current'
  and [udkey_1_value]<>'Unspecified'
  --and contract_id='6767'

  group by period_id, contract_id
  --[udkey_2_value],udkey_3_value
