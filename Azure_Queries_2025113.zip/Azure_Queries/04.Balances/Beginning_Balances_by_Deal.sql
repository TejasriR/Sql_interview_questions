
SELECT beg_balances.contract_id [Deal ID],
c.[Agreement Number],
actual_period_id [Period],
seq_nbr [Sequence],
beg_balances.contract_descr [Deal Name],
udkey_2_descr [Balance_Type],
[actual_period_descr],
other_period_descr,
s.[descr] [Adjustemt_Status],
usr1.formatted_name [ Created by],
usr2.formatted_name [ Posted by],
usr3.formatted_name [ Cleared by],
[udkey_7_id] [Income Group],
[udkey_15_id] [Recoupment Group],
[price_point] [SRP],
[amount], 
beg_balances.[modified_datetime] [ Last Updated]
  FROM [uv_adjustment_contract_dtl] beg_balances join (SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') c on c.contract_id=beg_balances.contract_id
  join [x_adjustment_hdr] adj on adj.adjustment_sid=beg_balances.adjustment_sid
  join c_status s on adj.status_sid=s.status_sid
  join [x_user] usr1 on usr1.user_sid=adj.created_by_user_sid
  left join [x_user] usr2 on usr2.user_sid=adj.posted_by_user_sid
  left join [x_user] usr3 on usr3.user_sid=adj.cleared_by_user_sid
  --where datefromparts(year([modified_datetime]),month([modified_datetime]),day([modified_datetime])) >'2024-06-07' 

  --where c.contract_id='6576'

group by 
beg_balances.contract_id,
c.[Agreement Number],
actual_period_id,
seq_nbr,
beg_balances.contract_descr ,
udkey_2_descr,
[actual_period_descr],
other_period_descr,
s.[descr] ,
usr1.formatted_name,
usr2.formatted_name,
usr3.formatted_name,
[udkey_7_id] ,
[udkey_15_id] ,
[price_point] ,
[amount], 
beg_balances.[modified_datetime]  

