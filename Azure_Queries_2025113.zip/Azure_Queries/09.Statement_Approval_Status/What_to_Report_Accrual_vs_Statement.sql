SELECT 
    [Contract ID]+'_'+[Quarter] [Contract_ID_Quarter],
    [Contract ID],
    [Contract Name],
    --[Calculation Status],
    [Quarter],
    ISNULL([Accrual], 0) AS [Has_Accrual_Calc],
    ISNULL([Statement], 0) AS [Has_Actuals_Statement_Calc],
    case when ISNULL([Statement], 0)=1 then 'Report Actuals/Statement' else 'Report Accruals' end [What_to_Report]
FROM (
    SELECT      
        [contract_sid] AS [Contract SID],
        [contract_id] AS [Contract ID],
        [contract_description] AS [Contract Name],
        [period_id] AS [Quarter],
        --[status_description] AS [Calculation Status],
        [deal_description] AS [Calculation Type]
    FROM [cru_master].[dbo].[uv_deal_calc_msg]
    where [contract_id] not like '%Revenue%'
    and [status_description] in ('Complete','Approved')
    --and contract_id='10705'
) AS SourceTable
PIVOT (
    COUNT([contract sid])
    FOR [Calculation Type] IN ([Accrual], [Statement])
) AS PivotTable

--where (case when ISNULL([Statement], 0)=1 then 'Report Actuals/Statement' else 'Report Accruals' end)='Report Accruals'