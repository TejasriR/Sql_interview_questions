select period_id
,udkey_3_value [CURRENT_OR_ITD]
, calc.contract_id
, xc.contract_description
, [Agreement Number]
,format(sum(case when [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties]
,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' then amount else 0 end),'C','en-US') [Royalties Due]
, data_is_approved_flag [Calculations are Approved?]
from uv_deal_calc_result calc

join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' AND status_id <>'PRIORREVISION' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id
join (select contract_id, contract_description from uv_contract where contract_status_id<>'PRIORREVISION' group by contract_id, contract_description ) xc on xc.contract_id=calc.contract_id

where udkey_3_value='CURRENT' 
and period_id='202406'
--and contract_id='2239'
group by  period_id,udkey_3_value , calc.contract_id, xc.contract_description, [Agreement Number], data_is_approved_flag 

