SELECT 
      uvs.[contract_id] [Rightsline Deal ID]
      ,an.[Agreement Number] 
      ,uvctr.contract_description [Deal Name]
      ,uvctr.contract_status_id [Contract Status]
      ,[Deal Management Status]
      ,[period_id] [Quarter]
      ,licensee.company_name [Licensee]
      ,string_agg([participant_formatted_name],'|') [Licensor]
      ,[Scope start Date]
      ,[Scope End Date]
      ,[status_id] [Calculations Status]
      ,datefromparts(year(uvs.start_datetime),month(uvs.start_datetime),day(uvs.start_datetime))  [Calculation Run Date]
      ,datediff(second, uvs.start_datetime,uvs.end_datetime) [Calculation Run Time (Seconds)]
      ,isnull([Statement Approved By],'') [Calculation and Statement Approved By]
      ,isnull([Statement Approved Date],'') [Calculation and Statement Approved Date]
      ,case when [status_id]='APPROVED' then 1 else 0 end [Calc Approval flag]
      ,isnull(lu.[Last UNAPPROVED Quarter],'Approvals are up to date for this deal') [Last UNAPPROVED Quarter]
      ,isnull(la.[Last APPROVED Quarter],'No Approval has been made for this deal') [Last APPROVED Quarter]
      ,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]

  FROM [uv_statement] uvs 
  join uv_contact uvc on uvs.participant_contact_sid=uvc.contact_sid
  join uv_contract uvctr on uvctr.contract_sid=uvs.contract_sid


  join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=uvs.contract_sid 



join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Deal Management Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus') and status_id<>'PRIORREVISION') ms on ms.contract_sid=uvs.contract_sid

left join (select cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr ) licensee on licensee.contract_sid=uvs.contract_sid

left join (select 
a.contract_id [Deal ID],


min([start_actual_period_id]) [Scope start Date],
max([end_actual_period_id]) [Scope End date]

from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
--and b.contract_id='5758'
group by a.contract_id) scope on uvs.contract_id=scope.[Deal ID]


---approvals

left join (SELECT  [statement_sid]
,approved_by_user_sid
,formatted_name [Statement Approved By]
,datefromparts(year([approved_datetime]),month([approved_datetime]),day(approved_datetime)) [Statement Approved Date]
  FROM [x_statement_job_queue_hist] a 
  join x_approval app on app.[approval_sid]=a.approval_sid
  join x_user u on u.user_sid=app.approved_by_user_sid ) approvals  on approvals.statement_sid=uvs.statement_sid

-----latest unapproved quarter

left join (

  SELECT 
      max([period_id]) [Last UNAPPROVED Quarter]
      ,contract_id [Deal ID]
      from uv_statement
      where [status_id]<>'APPROVED'
      
      group by contract_id
) lu on lu.[Deal ID]=uvs.contract_id

--last approved quarter

left join (

  SELECT 
      max([period_id]) [Last APPROVED Quarter]
      ,contract_id [Deal ID]
      from uv_statement
      where [status_id]='APPROVED'
      --and  contract_id='11090'
      group by contract_id
) la on la.[Deal ID]=uvs.contract_id

  where uvc.contact_type_id in ('Licensor','Licensee')
  and uvctr.contract_status_id<>'PRIORREVISION'
  --and datefromparts(year(uvs.start_datetime),month(uvs.start_datetime),day(uvs.start_datetime)) >'2025-08-06'
  --and isnull([Statement Approved Date],'')>'2025-08-01'
  --and uvs.[contract_id]='12043'
  group BY

      uvs.[contract_id] 
      ,an.[Agreement Number] 
      ,uvctr.contract_description 
      ,uvctr.contract_status_id
      ,[Deal Management Status]
      ,[period_id] 
      ,licensee.company_name 
      ,[Scope start Date]
      ,[Scope End Date]
      ,[status_id] 
      ,datefromparts(year(uvs.start_datetime),month(uvs.start_datetime),day(uvs.start_datetime))
      ,datediff(second, uvs.start_datetime,uvs.end_datetime) 
      ,isnull([Statement Approved By],'')
      ,isnull([Statement Approved Date],'')
      ,isnull(lu.[Last UNAPPROVED Quarter],'Approvals are up to date for this deal') 
      ,isnull(la.[Last APPROVED Quarter],'No Approval has been made for this deal')
      ,case when [status_id]='APPROVED' then 1 else 0 end


--select [contract_id],max(period_id) [Last Period to have a statement] from uv_statement group by contract_id

  SELECT 
      [period_id] [Quarter]
      ,[status_id] [Calculations Status]
      ,count(distinct statement_sid) [number of statements]
  FROM [uv_statement] uvs 

  group BY     [period_id], [status_id] 
  order by period_id desc

