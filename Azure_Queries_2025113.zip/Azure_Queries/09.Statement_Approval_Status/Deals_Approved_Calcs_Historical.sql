Select [Rightsline Deal ID],[Agreement Number],[Deal Name],[Licensee],[Licensor],[Selected Date],

case when [Earliest Statement Approval date]>[Selected Date] then 'No' else 'Yes' end [Had approved Calcs as of selected date]

from 

(SELECT 
      uvs.[contract_id] [Rightsline Deal ID]
      ,an.[Agreement Number] 
      ,uvctr.contract_description [Deal Name]
      ,string_agg(licensee.company_name,'|') [Licensee]
      ,string_agg([participant_formatted_name],'|') [Licensor]
      ,min([Statement Approved Date]) [Earliest Statement Approval date]
      ,[status_id] [Calculations Status]
      ,1 [ID]

  FROM [uv_statement] uvs 
  join uv_contact uvc on uvs.participant_contact_sid=uvc.contact_sid
  join uv_contract uvctr on uvctr.contract_sid=uvs.contract_sid


  join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=uvs.contract_sid 


left join (select cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr ) licensee on licensee.contract_sid=uvs.contract_sid



---approvals

left join (SELECT  [statement_sid]
,approved_by_user_sid
,formatted_name [Statement Approved By]
,datefromparts(year([approved_datetime]),month([approved_datetime]),day(approved_datetime)) [Statement Approved Date]
  FROM [x_statement_job_queue_hist] a 
  join x_approval app on app.[approval_sid]=a.approval_sid
  join x_user u on u.user_sid=app.approved_by_user_sid ) approvals  on approvals.statement_sid=uvs.statement_sid

  where uvc.contact_type_id='Licensor'
  and uvctr.contract_status_id<>'PRIORREVISION'
  and [status_id]='APPROVED'
  --and [Statement Approved Date]<='2025-01-01'
  group BY

      uvs.[contract_id] 
      ,an.[Agreement Number] 
      ,uvctr.contract_description 
      ,[status_id]) statement_approvals 

       join (Select 
'2024-11-20' [Selected Date], 1 [ID] ) s_date on s_date.ID=statement_approvals.ID

group by 

[Rightsline Deal ID],[Agreement Number],[Deal Name],[Licensee],[Licensor],[Selected Date],

case when [Earliest Statement Approval date]>[Selected Date] then 'No' else 'Yes' end