SELECT contract_id, actual_period, 
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_episode
where [unique]=1
and status_message = 'Multiple Deals'
group by contract_id,actual_period
order by sum(amount) desc