
  SELECT CAST(a.[udkey_1_sid_segment] as int) [Catalog ID], CASE WHEN a.[xref_3_descr] like '%CR_SVOD%'THEN 'SVOD' Else 'AVOD' end [Type],

        sum(Amount) [Total_Amount]
      
  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-05-20' 
  and (a.[xref_3_descr] like '%CR_AVOD%' or a.[xref_3_descr] like '%CR_SVOD%')
  --and a.[udkey_1_sid_segment]='17'
  

  group by CAST(a.[udkey_1_sid_segment] as int), CASE WHEN a.[xref_3_descr] like '%CR_SVOD%'THEN 'SVOD' Else 'AVOD' end
  ORDER BY CAST(a.[udkey_1_sid_segment] as int)