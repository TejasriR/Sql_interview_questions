select [period_id],[contract_id],data_is_approved_flag,sum(amount) [Royalties_Accrued_in_Period] 
from uv_deal_calc_result 
where calculation_name='C_MAIN_PARTICIP_STANDALONE_ACCRUAL' 
and [udkey_2_value]='Royalties' and udkey_3_value='Current'
group by [period_id],[contract_id],data_is_approved_flag