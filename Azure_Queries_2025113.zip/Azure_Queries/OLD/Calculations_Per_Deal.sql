SELECT 
      calcs.[contract_id]
      ,[Agreement Number]
      ,cont.[contract_description]
      ,[period_id]
      ,[calculation_sid]
      ,[calculation_name]
      ,[udkey_2_value] [Account]
--      ,[udkey_5_value] [Territory]
      ,[udkey_7_value] [Income_Group]
      ,[price_point] [SRP]
      ,Sum([amount]) [Total_Amount]
  FROM [uv_deal_calc_result] Calcs
  join ( SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') a
  on a.[contract_id]=calcs.[contract_id]
  join uv_contract cont on cont.[contract_id]=calcs.[contract_id]

  where deal_id='STATEMENT'
  and [udkey_3_value]='CURRENT'
  and period_id='202403'
  --and calcs.[contract_id]='1007'

  group BY 
     calcs.[contract_id]
     ,[Agreement Number]
     ,cont.[contract_description]
      ,[period_id]
      ,[calculation_sid]
      ,[calculation_name]
      ,[udkey_2_value] 
      --,[udkey_5_value] 
      ,[udkey_7_value] 
      ,[price_point]
      order by
      [Agreement Number]