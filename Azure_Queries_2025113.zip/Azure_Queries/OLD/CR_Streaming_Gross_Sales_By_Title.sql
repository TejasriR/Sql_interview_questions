SELECT
episodic_gross_sales.[API_Batch_ID] [API_Batch_ID],
episodic_gross_sales.[Income Group] [Income Group],
episodic_hiearchy.[RL Season_Movie_OVA ID] [RL Season_Movie_OVA ID],
episodic_hiearchy.[RL Season_Movie_OVA Description] [RL Season_Movie_OVA Description],
episodic_hiearchy.[RL Series ID] [RL Series ID],
episodic_hiearchy.[RL Series Description] [RL Series Description],
episodic_hiearchy.[RL Brand ID] [RL Brand ID],
left(episodic_hiearchy.[RL Brand Description],LEN(episodic_hiearchy.[RL Brand Description])-len(episodic_hiearchy.[RL Brand ID])) [RL Brand Description],
sum(episodic_gross_sales.[Total_Amount]) [Gross Sales]


from (SELECT  left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_7_sid_segment] [Income Group],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2024-02-02' and '2024-05-10'  and (a.[xref_3_descr] like '%CR_SVOD%' or a.[xref_3_descr] like'%CR_AVOD%') 
  

  group by [udkey_1_sid_segment],a.[udkey_7_sid_segment],left(a.[xref_3_descr],20)
  ) episodic_gross_sales
  join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udf_value] [RL Catalog Template]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode') episodic_hiearchy

  on episodic_hiearchy.[RL Catalog ID]=episodic_gross_sales.[Catalog ID]

--where episodic_hiearchy.[RL Brand Description] like '%solo leveling%'


  group by episodic_gross_sales.[API_Batch_ID],
  episodic_gross_sales.[Income Group],
  episodic_hiearchy.[RL Season_Movie_OVA ID],
  episodic_hiearchy.[RL Season_Movie_OVA Description],
  episodic_hiearchy.[RL Series ID],
  episodic_hiearchy.[RL Series Description],
  episodic_hiearchy.[RL Brand ID],
  episodic_hiearchy.[RL Brand Description]

  

UNION

SELECT
non_episodic_gross_sales.[API_Batch_ID] [API_Batch_ID],
non_episodic_gross_sales.[Income Group] [Income Group],
non_episodic_hiearchy.[RL Season_Movie_OVA ID] [RL Season_Movie_OVA ID],
non_episodic_hiearchy.[RL Season_Movie_OVA Description] [RL Season_Movie_OVA Description],
non_episodic_hiearchy.[RL Series ID] [RL Series ID],
non_episodic_hiearchy.[RL Series Description] [RL Series Description],
non_episodic_hiearchy.[RL Brand ID] [RL Brand ID],
left(non_episodic_hiearchy.[RL Brand Description],LEN(non_episodic_hiearchy.[RL Brand Description])-len(non_episodic_hiearchy.[RL Brand ID])) [RL Brand Description],
sum(non_episodic_gross_sales.[Total_Amount]) [Gross Sales]


from (SELECT  left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_7_sid_segment] [Income Group],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2024-02-02' and '2024-05-10'  and (a.[xref_3_descr] like '%CR_SVOD%' or a.[xref_3_descr] like'%CR_AVOD%') 
  

  group by [udkey_1_sid_segment],a.[udkey_7_sid_segment],left(a.[xref_3_descr],20)
  ) non_episodic_gross_sales
  
  join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,a.[udf_value] [RL Catalog Template]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA')) non_episodic_hiearchy

  on non_episodic_hiearchy.[RL Season_Movie_OVA ID]=non_episodic_gross_sales.[Catalog ID]



  
  group by [API_Batch_ID],
  [Income Group], 
  [RL Season_Movie_OVA ID],
 [RL Season_Movie_OVA Description],
 [RL Series ID],
[RL Series Description],
[RL Brand ID],
[RL Brand Description]

