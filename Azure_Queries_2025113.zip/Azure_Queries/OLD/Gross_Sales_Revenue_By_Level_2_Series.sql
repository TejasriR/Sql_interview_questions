SELECT 
Revenue1.[API_Batch_ID] [API_Batch_ID],
Revenue1.[Catalog Template] [Catalog Template],
Revenue1.[Income Group] [Income Group],
ep_level_hiearchy.[RL Series ID] [RL Series ID],
ep_level_hiearchy.[RL Series Description] [RL Series Description],
ep_level_hiearchy.[RL Brand ID] [RL Brand ID],
ep_level_hiearchy.[RL Brand Description] [RL Brand Description],
sum(Revenue1.[Total_Amount]) [Total Amount],
sum(Revenue1.[Number_of_Records]) [Number of Records] 

from 

( SELECT  left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_7_sid_segment] [Income Group],
       catalog_list.udf_value [Catalog Template],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  join (SELECT  a.[udkey_1_sid]     --Nesting this forst query to get the catalog template which will inform at which level the revenue is coming in
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalog_list -- end of first query
  on catalog_list.udkey_1_id=a.[udkey_1_sid_segment]

   --where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2024-02-02' and '2024-05-10'


  group by [udkey_1_sid_segment],[udkey_7_sid_segment],left(a.[xref_3_descr],20),catalog_list.udf_value

   ) Revenue1
  
  join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udf_value] [RL Catalog Template]
      ,sea.[parent_udkey_1_sid] [Parent1]
      ,d.udkey_1_id [RL Season ID]
      ,d.udkey1_description [RL Season Description]
      ,ser.[parent_udkey_1_sid] [Parent2]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode' ) ep_level_hiearchy
  on Revenue1.[Catalog ID]=ep_level_hiearchy.[RL Catalog ID]


Group by 
[API_Batch_ID],
[Catalog Template],
[Income Group],
[RL Series ID],
[RL Series Description],
[RL Brand ID],
[RL Brand Description]

UNION

SELECT 

Revenue2.[API_Batch_ID] [API_Batch_ID],
Revenue2.[Catalog Template] [Catalog Template],
Revenue2.[Income Group] [Income Group],
sea_mov_ova_level_hiearchy.[RL Series ID] [RL Series ID],
sea_mov_ova_level_hiearchy.[RL Series Description] [RL Series Description],
sea_mov_ova_level_hiearchy.[RL Brand ID] [RL Brand ID],
sea_mov_ova_level_hiearchy.[RL Brand Description] [RL Brand Description],
sum(Revenue2.[Total_Amount]) [Total Amount],
sum(Revenue2.[Number_of_Records]) [Number of Records] 

from

(SELECT left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_7_sid_segment] [Income Group],
       catalog_list.udf_value [Catalog Template],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  join (SELECT  a.[udkey_1_sid]     --Nesting this forst query to get the catalog template which will inform at which level the revenue is coming in
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) [Date Loaded]
      ,[udf_value]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalog_list -- end of first query
  on catalog_list.udkey_1_id=a.[udkey_1_sid_segment]

 
  --where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) between '2024-02-02' and '2024-05-10'


  group by [udkey_1_sid_segment],[udkey_7_sid_segment],left(a.[xref_3_descr],20),catalog_list.udf_value
   ) Revenue2 
  
  join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udkey_1_id] [RL Season ID]
      ,b.[udkey1_description] [RL Season Description]
      ,a.[udf_value] [RL Catalog Template]
      ,ser.[parent_udkey_1_sid] [Parent1]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      ,br.[parent_udkey_1_sid] [Parent2]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on ser.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] br on br.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on br.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA' or a.[udf_value]='Season' or a.[udf_value]='Music')) sea_mov_ova_level_hiearchy
  
  on Revenue2.[Catalog ID]=sea_mov_ova_level_hiearchy.[RL Catalog ID]

  group by 
  [API_Batch_ID],
  [Catalog Template],
  [Income Group],
  [RL Series ID],
  [RL Series Description],
  [RL Brand ID],
  [RL Brand Description]