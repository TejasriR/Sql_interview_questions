SELECT
gross_sales.[API_Batch_ID],
episodic_hiearchy.[RL Season_Movie_OVA ID],
episodic_hiearchy.[RL Season_Movie_OVA Description],
episodic_hiearchy.[RL Series ID],
episodic_hiearchy.[RL Series Description],
episodic_hiearchy.[RL Brand ID],
episodic_hiearchy.[RL Brand Description],
sum(gross_sales.[Total_Amount]) [Gross Sales]


from (SELECT  left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-05-02' and a.[xref_3_descr] like '%VOD%'
  

  group by [udkey_1_sid_segment],left(a.[xref_3_descr],20)
  ) gross_sales
  join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udf_value] [RL Catalog Template]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [cru_dev].[dbo].[uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode') episodic_hiearchy

  on episodic_hiearchy.[RL Catalog ID]=gross_sales.[Catalog ID]


  
  group by gross_sales.[API_Batch_ID], 
  episodic_hiearchy.[RL Season_Movie_OVA ID],
  episodic_hiearchy.[RL Season_Movie_OVA Description],
  episodic_hiearchy.[RL Series ID],
  episodic_hiearchy.[RL Series Description],
  episodic_hiearchy.[RL Brand ID],
  episodic_hiearchy.[RL Brand Description]

