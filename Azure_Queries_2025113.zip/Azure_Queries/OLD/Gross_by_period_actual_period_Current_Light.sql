Select 
[Deal ID],
[Deal Name],
[Agreement Number],
[Deal Status],
[Report Generation Date],
[Calculation Type],
[Current or ITD],
[Reporting Period],
[Actual Period],
[Calculations are Approved?],
[Gross Receipts],
[Platform Fee],
[Reserves Taken],
[Reserves Released],
[Net Receipts],
[Royalties],
[Royalties Due]
from 

(select calc.contract_id [Deal ID]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'ACTUAL_STATEMENT' [Calculation Type]
,udkey_3_value [Current or ITD]
,period_id [Reporting Period]
,actual_period_id [Actual Period]
,data_is_approved_flag [Calculations are Approved?]
--,udkey_7_value [Income Group]
,format(sum(case when [udkey_2_value]='Gross Receipts' then amount else 0 end),'C','en-US') [Gross Receipts]
,format(sum(case when [udkey_2_value]='Platform Fee' then amount else 0 end),'C','en-US') [Platform Fee]
,format(sum(case when [udkey_2_value]='Reserves Taken' then amount else 0 end),'C','en-US') [Reserves Taken] 
,format(sum(case when [udkey_2_value]='Reserves Released' then amount else 0 end),'C','en-US') [Reserves Released] 
,format(sum(case when [udkey_2_value]='Net Receipts' then amount else 0 end),'C','en-US') [Net Receipts]
,format(sum(case when [udkey_2_value]='Royalties' then amount else 0 end),'C','en-US') [Royalties] 
,format(sum(case when [udkey_2_value]='Royalties Due' then amount else 0 end),'C','en-US') [Royalties Due] 

from [uv_deal_calc_result] calc 
where udkey_3_value='Current'

and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
--and  c.contract_id='1940' 
group by calc.contract_id
,udkey_3_value
, period_id
, actual_period_id
,data_is_approved_flag
--,udkey_7_value

) Calculations

join (

SELECT 
uvcu.[contract_id] [Deal_ID],contract_description [Deal Name],Status_id [Deal Status], [udf_value] [Agreement Number]
from [uv_contract_udf] uvcu 
join (select contract_id, contract_description from uv_contract uvc where contract_status_id<>'PRIORREVISION' group by contract_id, contract_description) cont on cont.contract_id=uvcu.contract_id

where uvcu.udf_name = 'Agreement_integer' and uvcu.status_id<> 'PRIORREVISION'

group by 
uvcu.[contract_id],
contract_description,
status_id,
[udf_value]

) metadata on Calculations.[Deal ID]=metadata.[Deal_ID]

group BY
[Deal ID],
[Deal Name],
[Agreement Number],
[Deal Status],
[Report Generation Date],
[Calculation Type],
[Current or ITD],
[Reporting Period],
[Actual Period],
[Calculations are Approved?],
[Gross Receipts],
[Platform Fee],
[Reserves Taken],
[Reserves Released],
[Net Receipts],
[Royalties],
[Royalties Due]