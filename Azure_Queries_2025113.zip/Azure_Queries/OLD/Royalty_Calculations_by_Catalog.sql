
select 
 period_id [Period]
 ,contract_id
 ,udkey_1_value [Catalog ID]
 ,[RL Catalog Name Description]
 ,[RL Catalog Template]
 ,[RL Season_Movie_OVA ID]
 ,[RL Season_Movie_OVA Description]
 ,[RL Series ID]
 ,[RL Series Description]
 ,udkey_7_value [Income_Group]


  ,format(sum(case when [udkey_2_value]='Sale' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Sale] 
  ,format(sum(case when [udkey_2_value]='Return' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Return] 
  ,format(sum(case when [udkey_2_value]='Gross Receipts' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Gross Receipts] 
  ,format(sum(case when [udkey_2_value]='Platform Fee' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Platform Fee]
  ,format(sum(case when [udkey_2_value]='Reserves Taken' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Royalties]
  ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
  ,format(sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD Royalty Prior Quarter]
  ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD_Royalties]
  ,format(sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Minimum Guarantee]
  ,format(sum(case when [udkey_2_value]='Production Costs' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Expenses] --Miscellaneous Costs - Paid
,format(sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [P&A_Costs]
  ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due'  AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Deal_Balance]
  ,format(sum(case when [udkey_2_value]='Final Guarantee Balance' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Guarantee Balance]
  ,format(sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Previously Paid]
  --,format(sum(case when [udkey_2_value]='Cutover Recoupable Adjustments Balance' then amount else 0 end),'C','en-US') [Cutover Recoupable Adjustments Balance]
  ,format(sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Royalties Due]
  ,sum(case when [udkey_2_value]='Sale' AND udkey_3_value='ITD' then alt_qty else 0 end) [Minutes Watched]

  from uv_deal_calc_result calc 

left join (SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udf_value] [RL Catalog Template]
      --,ser.[parent_udkey_1_sid]
      ,a.[udkey_1_id] [RL Season_Movie_OVA ID]
      ,b.[udkey1_description] [RL Season_Movie_OVA Description]
      ,d.udkey_1_id [RL Series ID]
      ,d.udkey1_description [RL Series Description]
      --,br.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Brand ID]
      ,e.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on ser.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on br.[parent_udkey_1_sid]=e.[udkey_1_sid]

  where [udf_name]='entity_template' and (a.[udf_value]='Movie' or a.[udf_value]='OVA' or a.[udf_value]='Season' or a.[udf_value]='Music' or a.[udf_value]='Book' or a.[udf_value]='Game')

  UNION all 

  SELECT  a.[udkey_1_sid] [Alliant ID]
      ,a.[udkey_1_id] [RL Catalog ID]
      ,b.[udkey1_description] [RL Catalog Name Description]
      ,a.[udf_value] [RL Catalog Template]
      --,sea.[parent_udkey_1_sid]
      ,d.udkey_1_id [RL Season_Movie_OVA ID]
      ,d.udkey1_description [RL Season_Movie_OVA Description]
      --,ser.[parent_udkey_1_sid]
      ,e.udkey_1_id [RL Series ID]
      ,e.udkey1_description [RL Series Description]
      ,f.udkey_1_id [RL Brand ID]
      ,f.udkey1_description [RL Brand Description]

  FROM [uv_udkey_1_udf] a
  join [uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] sea on sea.[udkey_1_sid]=a.[udkey_1_sid]
  left join [uv_udkey_1] d on sea.[parent_udkey_1_sid]=d.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] ser on ser.[udkey_1_sid]=d.[udkey_1_sid]
  left join [uv_udkey_1] e on ser.[parent_udkey_1_sid]=e.[udkey_1_sid]
  left join [c_udkey_1_hierarchy] br on br.[udkey_1_sid]=e.[udkey_1_sid]
  left join [uv_udkey_1] f on br.[parent_udkey_1_sid]=f.[udkey_1_sid]

  where [udf_name]='entity_template' and a.[udf_value]='episode') h on h.[RL Catalog ID]=calc.udkey_1_value


  where period_id='202406'
  and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
  --and [udkey_15_value]<>'Unspecified'
  --and cdata.[Contract ID]='936'

  group BY 
   period_id
   ,contract_id
   ,udkey_1_value
   ,[RL Catalog Name Description]
   ,[RL Catalog Template]
   ,[RL Season_Movie_OVA ID]
   ,[RL Season_Movie_OVA Description]
   ,[RL Series ID]
   ,[RL Series Description]
   ,udkey_7_value