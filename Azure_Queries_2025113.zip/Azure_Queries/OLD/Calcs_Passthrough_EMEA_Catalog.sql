select 
 period_id [Quarter]
 ,'ACTUAL_STATEMENT' [Calculation Type]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,calc.contract_id [Deal ID]
,[Agreement Number]
,uvc.contract_description [Deal name]
,xc.company_name [Licensee]
--,udkey_2_value [Account]
--,udkey_3_value [Timeline]
,udkey_7_value [Income Group]
,udkey_5_descr [Territory]
,udkey_4_descr [Customer]
,udkey_1_value [Catalog ID]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Sale - ITD] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Return - ITD] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Gross Receipts - ITD] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Platform Fee - ITD]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Royalties - ITD]
,sum(case when [udkey_2_value]='Sale' AND udkey_3_value='Current' then alt_qty else 0 end) [Minutes Watched - Current]
from uv_deal_calc_result calc 
join (select contract_id, contract_description from uv_contract where contract_status_id='ACTIVE' group by contract_id, contract_description) uvc on uvc.contract_id=calc.contract_id

join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' AND status_id ='ACTIVE' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id

right join (select cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr,uvc.contract_description [contract_descr] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr,uvc.contract_description) xc on c.contract_sid=xc.contract_sid
where period_id='202406'
and udkey_2_value not like '%Stmt'
and [Agreement Number] like '%P'
--and uvc.contract_description like '%Crunchyroll KK%'
and (xc.company_name like '%SA' or xc.company_name like '%SAS%')
and udkey_4_descr<>'Unspecified'
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
--and calc.contract_id='9528'
group by 
 period_id
,calc.contract_id
,[Agreement Number]
,uvc.contract_description
,xc.company_name
,udkey_7_value
,udkey_4_descr
,udkey_5_descr
,udkey_1_value 