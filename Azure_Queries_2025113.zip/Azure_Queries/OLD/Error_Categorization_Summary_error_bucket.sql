
-----summary

SELECT 
subsidiary,
'Missing Dimensions, Pending Renewal' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message <> 'No Deal'
and status_message <> 'Multiple Deals'

and [unique]=1
and actual_period<=202403
group by 
subsidiary

union all

SELECT 
subsidiary,
'No Deal' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message = 'No Deal'


and [unique]=1
and actual_period<=202403
group by 
subsidiary

union ALL

SELECT 
subsidiary,
'Multiple Deals' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message = 'Multiple Deals'


and [unique]=1
and actual_period<=202403
group by 
subsidiary

-----detail

SELECT 
subsidiary,
catalogue_descr,
contract_id [Deal ID],
agreement_number [Agreement Number],
income_group_descr,
'Missing Dimensions, Pending Renewal' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message <> 'No Deal'
and status_message <> 'Multiple Deals'

and [unique]=1
and actual_period<=202403
group by 
subsidiary,
catalogue_descr,
contract_id,
agreement_number,
income_group_descr

union all

SELECT 
subsidiary,
catalogue_descr,
contract_id [Deal ID],
agreement_number [Agreement Number],
income_group_descr,
'No Deal' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message = 'No Deal'


and [unique]=1
and actual_period<=202403
group by 
subsidiary,
catalogue_descr,
contract_id,
agreement_number,
income_group_descr

union ALL

SELECT 
subsidiary,
catalogue_descr,
contract_id [Deal ID],
agreement_number [Agreement Number],
income_group_descr,
'Multiple Deals' [Error_Category],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message = 'Multiple Deals'


and [unique]=1
and actual_period<=202403
group by 
subsidiary,
catalogue_descr,
contract_id,
agreement_number,
income_group_descr

