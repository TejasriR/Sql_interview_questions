select [contract_id], [period_id],[udkey_1_Value] [Catalog ID],[udkey_2_Value] [Account], [udkey_7_Value] [Income Group], [udkey_5_Value] [Territory],[udkey_6_Value] [Format], [Amount], [qty] [Units], [price_point] [SRP]
from [uv_deal_calc_result] where contract_id='453'
--and [udkey_2_value]='Gross Receipts'
and [udkey_3_value]='Current'

select [contract_id], [period_id],[udkey_2_value],sum([Amount])
from [uv_deal_calc_result] where contract_id='453'
--and [udkey_2_value]='Gross Receipts'
and [udkey_3_value]='Current'
group by [contract_id], [period_id],[udkey_2_value]




select * from [uv_deal_calc_result] where contract_id='1940' and [udkey_2_value]='Gross Receipts'and [udkey_3_value]='Current'