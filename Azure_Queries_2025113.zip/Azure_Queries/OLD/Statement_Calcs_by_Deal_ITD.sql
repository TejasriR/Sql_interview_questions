 select 
 period_id [Period]
-- , (cast([period_id] as int) - cast([actual_period_id] as int))  [test]
,calc.contract_id [Deal ID]
,xc.contract_descr [Deal Name]
,[udkey_15_value] [Recoupment Group]
,[Agreement Number]
,xc.formatted_name [Corporate Entity]
  ,format(sum(case when [udkey_2_value]='Sale - Stmt' then amount else 0 end),'C','en-US') [Sale] 
  ,format(sum(case when [udkey_2_value]='Return - Stmt' then amount else 0 end),'C','en-US') [Return] 
  ,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' then amount else 0 end),'C','en-US') [Gross Receipts] 
  ,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' then amount else 0 end),'C','en-US') [Platform Fee]
  ,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' then amount else 0 end),'C','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' then amount else 0 end),'C','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' then amount else 0 end),'C','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties]
  ,format(sum(case when [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [LTD Royalty Prior Quarter]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' then amount else 0 end),'C','en-US') [LTD_Royalties]
  ,format(sum(case when [udkey_2_value]='Historical Payment due' then amount else 0 end),'C','en-US') [Previously Paid]
  ,format(sum(case when [udkey_2_value]='Minimum Guarantee' then amount else 0 end),'C','en-US') [Minimum Guarantee]
  ,format(sum(case when [udkey_2_value]='Production Costs - Stmt' then amount else 0 end),'C','en-US') [Expenses]
  ,format(sum(case when [udkey_2_value]='Final Guarantee Balance' then amount else 0 end),'C','en-US') [Guarantee Balance]
  ,format(sum(case when [udkey_2_value]='Cutover Recoupable Adjustments Balance' then amount else 0 end),'C','en-US') [Cutover Recoupable Adjustments Balance]
  ,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' then amount else 0 end),'C','en-US') [Royalties Due]
  ,sum(case when [udkey_2_value]='Sale - Stmt' then alt_qty else 0 end) [Minutes Watched]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' then amount else 0 end)-sum(case when [udkey_2_value]='Historical Payment due' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' then amount else 0 end),'C','en-US') [Calculated Royalty Excess]
  ,case when sum(case when [udkey_2_value]='Cutover Recoupable Adjustments Balance' then amount else 0 end)<0 then 'Cutover Recoupable Adjustment Balance is Negative' else case when sum(case when [udkey_2_value]='Cutover Recoupable Adjustments Balance' then amount else 0 end)=0 then 'Cutover Recoupable Adjustment Balance is Zero' else '' end end [Cutover Flag]
  ,case when sum(case when [udkey_2_value]='Gross Receipts - Stmt' then amount else 0 end)=0 then 'No Revenue Activity' else case when sum(case when [udkey_2_value]='Royalties Due - Stmt' then amount else 0 end)<0 then 'Royalty Due is Negative' else '' end end [Check Negative Royalty Due]
  
  from [uv_deal_calc_result] calc 
  join (SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by [contract_id], [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id
  join (select contract_id, contract_descr,formatted_name  from [uv_contract_contact] group by contract_id,contract_descr,formatted_name) xc on c.contract_id=xc.contract_id
  where udkey_3_value='ITD'
  and period_id='202403'
  and calc.[contract_id] = '5677'
--  and actual_period_id<>'unspecified'
--  and actual_period_id<>'BEG OF TIME'
--  and actual_period_id<>'END OF TIME'
--  and actual_period_id<>'Inception'
  group by 
  Period_id 
  --,(cast([period_id] as int) - cast([actual_period_id] as int))
  ,calc.contract_id
  ,xc.contract_descr
  ,[Agreement Number]
  ,[udkey_15_value]
  ,xc.formatted_name
    