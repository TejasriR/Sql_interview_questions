SELECT  left(a.[xref_3_descr],20) [API_Batch_ID],
       a.[udkey_1_sid_segment] [Catalog ID],
       a.[udkey_7_sid_segment] [Income Group],
       catalog_list.udf_value [Catalog Template],
        Sum(amount) [Total_Amount],
        count(row_identity) [Number_of_Records]
      
  FROM x_posted_history a
  join (SELECT  a.[udkey_1_sid]
      ,a.[udkey_1_id]
      ,b.[udkey1_description]
      ,[udf_value]

  FROM [cru_dev].[dbo].[uv_udkey_1_udf] a
  join [cru_dev].[dbo].[uv_udkey_1] b on a.[udkey_1_sid]=b.[udkey_1_sid]
  where [udf_name]='entity_template') catalog_list
  on catalog_list.udkey_1_id=a.[udkey_1_sid_segment]

 

  group by [udkey_1_sid_segment],[udkey_7_sid_segment],left(a.[xref_3_descr],20),catalog_list.udf_value
  order by left(a.[xref_3_descr],20)