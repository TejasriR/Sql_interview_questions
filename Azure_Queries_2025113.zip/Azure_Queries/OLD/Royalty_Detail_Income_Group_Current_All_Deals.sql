WITH Calculations AS 

(select 
 period_id [Period]
 ,calc.contract_id [Deal ID]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,'ACTUAL_STATEMENT' [Calculation Type]
,[udkey_15_value] [Recoupment Group]
,data_is_approved_flag [Calculations are approved?]
,[udkey_7_value] [Income_Group]

  ,format(sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Sale] 
  ,format(sum(case when [udkey_2_value]='Return - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Return] 
  ,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts] 
  ,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee]
  ,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Royalties]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [LTD Royalty Prior Quarter]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD_Royalties]
  ,format(sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Minimum Guarantee - Escalation' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Minimum Guarantee]
  ,format(sum(case when [udkey_2_value]='Minimum Guarantee - Escalation' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Minimum Guarantee - Escalation]
  ,format(sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Expenses] --Miscellaneous Costs - Paid
,format(sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [P&A_Costs]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due'  AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee - Escalation' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Deal_Balance]
  ,format(sum(case when [udkey_2_value]='Final Guarantee Balance' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Guarantee Balance]
  ,format(sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Previously Paid]
  --,format(sum(case when [udkey_2_value]='Cutover Recoupable Adjustments Balance' then amount else 0 end),'C','en-US') [Cutover Recoupable Adjustments Balance]
  ,format(case when sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)<0 then 0 else sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end) end,'C','en-US') [Royalties Due]
  ,format(sum(case when [udkey_2_value]='AGR Fee' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [AGR Fee]
  ,format(sum(case when [udkey_2_value]='Music Sync Fee - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Music Sync Fee]
  ,sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='CURRENT' then alt_qty else 0 end) [Minutes Watched]
  --,case when (sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end))<0 then 'Unrecouped' else 'Recouped' end [Recoupment_Flag]
  
  from [uv_deal_calc_result] calc 

  

  Where period_id between '202406' and '202406'
  and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
  --and [udkey_15_value]<>'Unspecified'
  --and calc.[Contract_ID]='8465'
  --and actual_period_id<>'unspecified'
--  and actual_period_id<>'BEG OF TIME'
--  and actual_period_id<>'END OF TIME'
--  and actual_period_id<>'Inception'
  group by 
   period_id
   ,calc.contract_id
,[udkey_15_value] 
,data_is_approved_flag
,[udkey_7_value] 

HAVING 


  sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Return - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Platform Fee - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Reserves Taken - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Reserves Released - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='Current' then amount else 0 end)
  +sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)
  +sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)
  +sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
  +sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due'  AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)
  +sum(case when [udkey_2_value]='Final Guarantee Balance' AND udkey_3_value='ITD' then amount else 0 end)
  +sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)
  +sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)
  +sum(case when [udkey_2_value]='AGR Fee' AND udkey_3_value='Current' then amount else 0 end)
  +sum(case when [udkey_2_value]='Music Sync Fee - Stmt' AND udkey_3_value='Current' then amount else 0 end)
  +sum(case when [udkey_2_value]='Sale - Stmt' AND udkey_3_value='CURRENT' then alt_qty else 0 end) <>0

),

Metadata AS (select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,cc.contract_currency [Contract Currency]
,licensee.[Corporate_Entity] [Licensee]
,licensor.[Licensor] [Licensor]
,c.contract_status_id [Contract Status]
,ms.[master_status] [Deal Management Status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') [Deal Start Date]
,ISNULL(ce.contract_end_date,'') [Deal End Date]
,[Scope start Date]
,[Scope End date]


from uv_contract c




join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_start_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_start')) cs on cs.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_end_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_end')) ce on ce.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_currency], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('ContractCurrency')) cc on cc.contract_sid=c.contract_sid

---licensee

left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid

left join (select cpar.contract_sid, string_agg(company_name,'|') [Licensor] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Licensor') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensor on licensor.contract_sid=c.contract_sid

--scope

left join (select 
a.contract_id [Deal ID],


min(case when [start_actual_period_id]='Inception' then '201001' else [start_actual_period_id] end) [Scope start Date],
max(case when [end_actual_period_id]='Inception' then '201001' else [end_actual_period_id] end ) [Scope End date]

from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
--and b.contract_id='3802'
group by a.contract_id) scope on c.contract_id=scope.[Deal ID]


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'

group BY
c.contract_id 
,c.contract_description 
,cc.contract_currency 
,licensee.[Corporate_Entity]
,licensor.[Licensor]
,c.contract_status_id 
,ms.[master_status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') 
,ISNULL(ce.contract_end_date,'') 
,[Scope start Date]
,[Scope End date])
SELECT 
isnull([Period],'No Calculations') [Period], 
[Contract ID],
[Agreement Number],
[Contract Name],
[Contract Currency],
[Contract Status],
[Deal Management Status],
[Licensee],
[Licensor],
[Deal Start Date],
[Deal End Date],
[Scope start Date],
[Scope End date],
[Report Generation Date],
[Calculation Type],
[Recoupment Group],
[Income_Group],
[Calculations are approved?],
[Sale],
[Return],
[Gross Receipts],
[Platform Fee],
[Reserves Taken],
[Reserves Released],
[Net Receipts],
[Royalties],
[LTD Royalty Prior Quarter],
[LTD_Royalties],
[Minimum Guarantee],
[Minimum Guarantee - Escalation],
[Expenses],
[P&A_Costs],
[Deal_Balance],
[Guarantee Balance],
[Previously Paid],
[Royalties Due],
[AGR Fee],
[Music Sync Fee],
[Minutes Watched]

FROM Calculations
Right JOIN Metadata ON Calculations.[Deal ID] = Metadata.[Contract ID];