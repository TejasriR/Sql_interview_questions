SELECT
      calcs.[contract_id] [Deal ID]
      ,[Agreement Number]
      ,cont.[contract_description]
      ,[period_id]
      ,[calculation_name]
      --,[udkey_2_value] [Account]
--      ,[udkey_5_value] [Territory]
      ,[udkey_7_value] [Income_Group]
      --,string_agg((case when [udkey_15_value]='Unspecified' then '' else [udkey_15_value] end),char(13)) [Recoupment_Group]
      ,[price_point] [SRP]
      --,Sum(case when [udkey_2_value] = 'Sale' then [amount] else 0 end) [Sale]
      ,Sum(case when [udkey_2_value] = 'Sale - Stmt' then [amount] else 0 end) [Sale - Stmt]
      --,Sum(case when [udkey_2_value] = 'Return' then [amount] else 0 end) [Return]
      ,Sum(case when [udkey_2_value] = 'Return - Stmt' then [amount] else 0 end) [Return - Stmt]
      --,Sum(case when [udkey_2_value] = 'Gross Receipts' then [amount] else 0 end) [Gross Receipts]
      ,Sum(case when [udkey_2_value] = 'Gross Receipts - Stmt' then [amount] else 0 end) [Gross Receipts - Stmt]
      --,Sum(case when [udkey_2_value] = 'Platform Fee' then [amount] else 0 end) [Platform Fee]
      ,Sum(case when [udkey_2_value] = 'Platform Fee - Stmt' then [amount] else 0 end) [Platform Fee - Stmt]
      --,Sum(case when [udkey_2_value] = 'Gross Receipts Adjusted' then [amount] else 0 end) [Gross Receipts Adjusted]
      --,Sum(case when [udkey_2_value] = 'Reserves Taken' then [amount] else 0 end) [Reserves Taken]
      ,Sum(case when [udkey_2_value] = 'Reserves Taken - Stmt' then [amount] else 0 end) [Reserves Taken - Stmt]
      --,Sum(case when [udkey_2_value] = 'Reserves Released' then [amount] else 0 end) [Reserves Released]
      ,Sum(case when [udkey_2_value] = 'Reserves Released - Stmt' then [amount] else 0 end) [Reserves Released - Stmt]
      --,Sum(case when [udkey_2_value] = 'Net Receipts' then [amount] else 0 end) [Net Receipts]
      ,Sum(case when [udkey_2_value] = 'Net Receipts - Stmt' then [amount] else 0 end) [Net Receipts - Stmt]
      ,Sum(case when [udkey_2_value] = 'Royalties - stmt' then [amount] else 0 end) [Royalties - Stmt]
      ,Sum(case when [udkey_2_value] = 'Royalties Applied to Minimum Guarantee' then [amount] else 0 end) [Royalties Applied to Minimum Guarantee]
      ,Sum(case when [udkey_2_value] = 'Royalties Applied to P&A Costs - Paid' then [amount] else 0 end) [Royalties Applied to P&A Costs - Paid]
      ,Sum(case when [udkey_2_value] = 'Royalties Applied to Production Cost' then [amount] else 0 end) [Royalties Applied to Production Cost]
      ,Sum(case when [udkey_2_value] = 'Royalties Applied to Miscellaneous Cost' then [amount] else 0 end) [Royalties Applied to Miscellaneous Cost]
      --,Sum(case when [udkey_2_value] = 'Royalties Due' then [amount] else 0 end) [Royalties Due]
      ,Sum(case when [udkey_2_value] = 'Royalties Due - Stmt' then [amount] else 0 end) [Royalties Due - Stmt]
      --,Sum(case when [udkey_2_value] = 'Gross Receipts' then [qty] else 0 end) [Total_Gross_Units] --needs to be tied to gross receipt - stmt account
      --,round(sum(alt_qty),1) [Total_Minutes_Watched]

      
      --,case when Sum(case when [udkey_2_value] = 'Gross Receipts - stmt' then [amount] else 0 end) = 0 then 0 else 
      ---Sum(case when [udkey_2_value] = 'Platform Fee - stmt' then [amount] else 0 end)/(Sum(case when [udkey_2_value] = 'Gross Receipts - stmt' then [amount] else 0 end)) end [Platform Fee Check]
      
      --,case when Sum(case when [udkey_2_value] = 'Gross Receipts Adjusted' then [amount] else 0 end) = 0 then 0 else --need to have a Gross Receipts Adjusted - Stmt account to check this
      ---Sum(case when [udkey_2_value] = 'Reserves Taken' then [amount] else 0 end)/(Sum(case when [udkey_2_value] = 'Gross Receipts Adjusted' then [amount] else 0 end)) end [Reserve Rate Check]

      --,case when Sum(case when [udkey_2_value] = 'Net Receipts - stmt' then [amount] else 0 end) = 0 then 0 else
      --Sum(case when [udkey_2_value] = 'Royalties' then [amount] else 0 end)/(Sum(case when [udkey_2_value] = 'Net Receipts - stmt' then [amount] else 0 end)) end [Royalty Rate Check]
      

  FROM [uv_deal_calc_result] Calcs
  join ( SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer') a
  on a.[contract_id]=calcs.[contract_id]
  join uv_contract cont on cont.[contract_id]=calcs.[contract_id]

  where deal_id='STATEMENT'
  and [udkey_3_value]='CURRENT'
  and period_id='202403'
  and [udkey_7_value]<>'Unspecified'
  and [udkey_15_value]<>'Unspecified'
  and calcs.[contract_id]='1007'

  group BY 
     calcs.[contract_id]
     ,[Agreement Number]
     ,cont.[contract_description]
      ,[period_id]
      ,[calculation_name]
      --,[udkey_2_value] 
      --,[udkey_5_value] 
      ,[udkey_7_value]
      --,(case when [udkey_15_value]='Unspecified' then '' else [udkey_15_value] end)
      ,[price_point]
      --,[User_Rate]
      --,(case when [udkey_2_value] = 'Royalties - stmt' then [User_Rate] else 0 end)
      --,(case when [udkey_2_value] = 'Platform Fee - stmt' then [User_Rate] else 0 end)
      order by
      [Agreement Number]

      -- available accounts:

--24400 Accrued Royalties
--Final Payment Due
--Flat Fee
--Gross Receipts
--Gross Receipts - Stmt
--Gross Receipts Adjusted
--Minimum Guarantee
--Minimum Guarantee - Stmt
--Minimum Guarantee Payment
--Miscellaneous Cost Payment
--Miscellaneous Costs - Paid
--Miscellaneous Costs - Paid - Stmt
--Net Receipts
--Net Receipts - Stmt
--P&A Costs - Paid
--P&A Costs - Paid - Stmt
--P&A Costs - Paid Payment
--Participant Share
--Participant Share in Payment Currency
--Participant Share Less Withholding
--Platform Fee
--Platform Fee - Reporting Only
--Platform Fee - Stmt
--Platform Fee - Uncapped
--Production Cost Payment
--Production Costs
--Production Costs - Stmt
--Reserves Released
--Reserves Taken
--Reserves Taken - Stmt
--Return
--Return - Stmt
--Royalties
--Royalties - Stmt
--Royalties Applied to Minimum Guarantee
--Royalties Applied to Miscellaneous Cost
--Royalties Applied to P&A Costs - Paid
--Royalties Applied to Production Cost
--Royalties Available For Escalation
--Royalties Due
--Royalties Due - Stmt
--Royalties with Escalation Applied
--Sale
--Sale - Stmt
--Statement Info