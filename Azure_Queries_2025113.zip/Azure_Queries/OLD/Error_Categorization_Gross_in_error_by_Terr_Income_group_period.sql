SELECT 
      [territory_descr]+ '_' + [income_group_descr] [Unique_Pair]

      ,actual_period
      ,[territory_descr]
      ,[income_group_descr]
      ,sum([amount]) [gross receipts in error]
      
  FROM [cru_master].[dbo].[cru_error_categorization_episode]
  where [unique]=1
  and territory_descr<>'Unspecified'
  and income_group_descr<>'Unspecified'
  and catalogue_descr<>'FUNIMATIONNOW'
  group by 
  actual_period
  ,[territory_descr]
,[income_group_descr]
,[territory_descr]+ '_' + [income_group_descr]