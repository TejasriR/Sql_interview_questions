SELECT 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
contract_id,
agreement_number,
status_message [Error],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season
--where [unique]=1
where status_message = 'Pending Renewal'
and catalogue_descr<>'FUNIMATIONNOW'
and actual_period<=202403
group by 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
status_message,
contract_id,
agreement_number


SELECT 
subsidiary,
count(distinct catalogue_id) [number of titles with pending renewal]

FROM dbo.cru_error_categorization_season
--where [unique]=1
where status_message = 'Pending Renewal'
and catalogue_descr<>'FUNIMATIONNOW'
and actual_period<=202403
group by 
subsidiary