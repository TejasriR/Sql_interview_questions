SELECT contract_id, actual_period, 
--sum(transaction_count) [number of transactions], 
--format(sum(amount),'C','en-US') [Total_Revenue]
count( distinct status_message) [Number of errors]
FROM dbo.cru_error_categorization_episode
--where [unique]=1
where status_message <> 'No Deal'
group by contract_id,actual_period