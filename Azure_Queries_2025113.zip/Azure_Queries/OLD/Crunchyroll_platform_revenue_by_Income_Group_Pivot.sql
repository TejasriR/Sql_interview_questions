SELECT a.[udkey_7_sid_segment] [Income Group]
         ,sum(CASE WHEN left(a.[xref_3_descr],7)='CR_SVOD' THEN Amount Else 0 end) [Total_SVOD_Revenue]
        ,sum(CASE WHEN left(a.[xref_3_descr],7)='CR_AVOD' THEN Amount Else 0 end) [Total_AVOD_Revenue]
        
      
  FROM x_posted_history a
  where datefromparts(year(a.[modified_datetime]),month(a.[modified_datetime]),day(a.[modified_datetime])) >'2024-05-20' 
  and (a.[xref_3_descr] like '%CR_AVOD%' or a.[xref_3_descr] like '%CR_SVOD%')
    

  group by a.[udkey_7_sid_segment]
  order by sum(CASE WHEN left(a.[xref_3_descr],7)='CR_SVOD' THEN Amount Else 0 end) desc