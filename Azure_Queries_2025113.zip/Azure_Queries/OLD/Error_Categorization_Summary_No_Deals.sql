SELECT 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
status_message [Error],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season
where [unique]=1
and status_message = 'No Deal'
and catalogue_descr<>'FUNIMATIONNOW'
and actual_period<=202403
group by 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
status_message


SELECT 
subsidiary, 
count(distinct catalogue_id) [number of titles with no deal]

FROM dbo.cru_error_categorization_season
where [unique]=1
and status_message = 'No Deal'
and catalogue_descr<>'FUNIMATIONNOW'
and actual_period<=202403
group by 
subsidiary