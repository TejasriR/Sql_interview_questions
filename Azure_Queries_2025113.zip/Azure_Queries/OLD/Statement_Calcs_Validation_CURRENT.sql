 select 
 period_id [Period] 
,calc.contract_id [Deal ID]
,xc.contract_descr [Deal Name]
,[udkey_15_value] [Recoupment Group]
,[udkey_7_value] [Income Group]
,[Udkey_5_Value] [territory]
,ic_label.[udf_value] [Income Group Label]
,t_label.[udf_value] [Reporting Region]
,[Agreement Number]
--,[Deal Master Status]
,xc.formatted_name [Corporate Entity]
  ,format(sum(case when [udkey_2_value]='Sale - Stmt' then amount else 0 end),'C','en-US') [Sale] 
  ,format(sum(case when [udkey_2_value]='Return - Stmt' then amount else 0 end),'C','en-US') [Return] 
  ,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' then amount else 0 end),'C','en-US') [Gross Receipts] 
  ,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' then amount else 0 end),'C','en-US') [Platform Fee]
  ,format(sum(case when [udkey_2_value]='Reserves Taken - Stmt' then amount else 0 end),'C','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released - Stmt' then amount else 0 end),'C','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' then amount else 0 end),'C','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties - Stmt' then amount else 0 end),'C','en-US') [Royalties]
  ,format(sum(case when [udkey_2_value]='Minimum Guarantee' then amount else 0 end),'C','en-US') [Minimum Guarantee]
  ,format(sum(case when [udkey_2_value]='Production Costs - Stmt' then amount else 0 end),'C','en-US') [Expenses]
  --,format(sum(case when [udkey_2_value]='Final Guarantee Balance' then amount else 0 end),'C','en-US') [Guarantee Balance]
  ,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' then amount else 0 end),'C','en-US') [Royalties Due]
  ,sum(case when [udkey_2_value]='Sale - stmt' then alt_qty else 0 end) [Minutes Watched]  
  
  from [uv_deal_calc_result] calc 
  join (SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by [contract_id], [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id
   join (SELECT [udkey_5_sid]
      ,[udkey_5_id]
      ,[udf_sid]
      ,[udf_name]
      ,[udf_label_id]
      ,[udf_value]
      ,[udf_value_id]
     
  FROM [uv_udkey_5_udf]
  where udf_name='ReportingRegion') t_label on t_label.[udkey_5_sid]=calc.udkey_5_sid

     join (SELECT [udkey_7_sid]
      ,[udkey_7_id]
      ,[udf_sid]
      ,[udf_name]
      ,[udf_label_id]
      ,[udf_value]
      ,[udf_value_id]
     
  FROM [uv_udkey_7_udf]
  where udf_name='IncomeGroupStatementDisplay') ic_label on ic_label.[udkey_7_sid]=calc.udkey_7_sid

  --join (SELECT 
  --    [contract_id], [udf_name], [udf_value] [Deal Master Status]
  --    from [uv_contract_udf] where udf_name = 'MasterStatus' group by [contract_id], [udf_name], [udf_value] ) ms on ms.contract_id=calc.contract_id

  join (select contract_id, contract_descr,formatted_name  from [uv_contract_contact] group by contract_id,contract_descr,formatted_name) xc on c.contract_id=xc.contract_id
  where udkey_3_value='Current'
  and [udkey_15_value]<>'Unspecified'
  and period_id='202403'
  --and calc.[contract_id]='8729'
  group by 
  Period_id,
  calc.contract_id
  ,xc.contract_descr
  ,[Agreement Number]
  --,[Deal Master Status]
  ,[udkey_15_value]
  ,[udkey_5_value]
  ,t_label.[udf_value]
  ,ic_label.[udf_value]
  ,[udkey_7_value]
  ,xc.formatted_name
    