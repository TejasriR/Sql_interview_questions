select 
 period_id [Quarter]
 ,'ACTUAL_STATEMENT' [Calculation Type]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,calc.contract_id [Deal ID]
,[Agreement Number]
,uvc.contract_description [Deal name]
--,udkey_2_value [Account]
--,udkey_3_value [Timeline]
,udkey_7_value [Income Group]
,format(sum(case when [udkey_2_value]='Sale - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
,format(sum(case when [udkey_2_value]='Return - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Sale - Stmt' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Sale - ITD] 
,format(sum(case when [udkey_2_value]='Return - Stmt' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Return - ITD] 
,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Gross Receipts - ITD] 
,format(sum(case when [udkey_2_value]='Platform Fee - Stmt' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Platform Fee - ITD]
,format(sum(case when [udkey_2_value]='Royalties Due - Stmt' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Royalties - ITD]
from uv_deal_calc_result calc 
join (select contract_id, contract_description from uv_contract where contract_status_id='ACTIVE' group by contract_id, contract_description) uvc on uvc.contract_id=calc.contract_id

join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' AND status_id ='ACTIVE' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id

where period_id='202406'
and udkey_2_value like '%Stmt'
and [Agreement Number] like '%P'
and uvc.contract_description like '%Crunchyroll KK%'
and calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
--and calc.contract_id='9528'
group by 
 period_id
,calc.contract_id
,[Agreement Number]
,uvc.contract_description
,udkey_7_value