---------Detail


SELECT 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
status_message [Error],
contract_id,
[unique],
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message <> 'No Deal'
and status_message <> 'Multiple Deals'
--and [unique]=1
and actual_period<=202403
group by 
subsidiary, 
catalogue_id, 
catalogue_descr,
income_group_descr,
status_message,
contract_id,
[unique]


------by catalog

SELECT 
subsidiary, 
catalogue_id, 
catalogue_descr,
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message <> 'No Deal'
and status_message <> 'Multiple Deals'
and [unique]=1
and actual_period<=202403

group by 
subsidiary, 
catalogue_id, 
catalogue_descr


-----by subsidiary

SELECT 
subsidiary,
sum(transaction_count) [number of transactions], 
format(sum(amount),'C','en-US') [Total_Revenue]
FROM dbo.cru_error_categorization_season

Where catalogue_descr<>'FUNIMATIONNOW'
and status_message <> 'No Deal'
and status_message <> 'Multiple Deals'

and [unique]=1
and actual_period<=202403
group by 
subsidiary
