
Select  
[Quarter],
[Calculation Type],
[Report Generation Date],
[Deal ID],
[Agreement Number],
[Contract Name],
[Licensee],
[Income Group],
[Customer],
[Language],
[Sale - Current],
[Return - Current],
[Gross Receipts - Current],
[Platform fee - Current],
[Royalties - Current],
[Sale - ITD],
[Return - ITD],
[Gross Receipts - ITD],
[Platform Fee - ITD],
[Royalties - ITD],
[Minutes Watched - Current]

from

(select 
 period_id [Quarter]
 ,'ACTUAL_STATEMENT' [Calculation Type]
,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
,calc.contract_id [Deal ID]
,udkey_7_value [Income Group]
,udkey_4_descr [Customer]
,udkey_11_descr [Language]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Sale - Current] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Return - Current] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Gross Receipts - Current] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Platform Fee - Current]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
,format(sum(case when [udkey_2_value]='Sale' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Sale - ITD] 
,format(sum(case when [udkey_2_value]='Return' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Return - ITD] 
,format(sum(case when [udkey_2_value]='Gross Receipts' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Gross Receipts - ITD] 
,format(sum(case when [udkey_2_value]='Platform Fee' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Platform Fee - ITD]
,format(sum(case when [udkey_2_value]='Royalties' and [udkey_3_value]='ITD' then amount else 0 end),'C','en-US') [Royalties - ITD]
,sum(case when [udkey_2_value]='Sale' AND udkey_3_value='Current' then alt_qty else 0 end) [Minutes Watched - Current]
from uv_deal_calc_result calc 

Where calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
and udkey_4_descr<>'Unspecified'
and udkey_2_value not like '%Stmt'
and period_id='202409'

group by 
 period_id
,calc.contract_id
,udkey_7_value
,udkey_4_descr
,udkey_11_descr) Calculations


join (select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,licensee.[Corporate_Entity] [Licensee]
,c.contract_status_id [Contract Status]
,ms.[master_status] [Deal Management Status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') [Deal Start Date]
,ISNULL(ce.contract_end_date,'') [Deal End Date]


from uv_contract c




join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_start_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_start')) cs on cs.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_end_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_end')) ce on ce.contract_sid=c.contract_sid

---licensee

left join (select cpar.contract_sid, string_agg(company_name,'|') [Corporate_Entity] from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid ) licensee on licensee.contract_sid=c.contract_sid

where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'
and [Agreement Number] like '%P'
and c.contract_description like '%Crunchyroll KK%'

group BY
c.contract_id 
,c.contract_description 
,licensee.[Corporate_Entity]
,c.contract_status_id 
,ms.[master_status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') 
,ISNULL(ce.contract_end_date,'')

) Metadata on Calculations.[Deal ID]=[Metadata].[Contract ID]

group BY
[Quarter],
[Calculation Type],
[Report Generation Date],
[Deal ID],
[Agreement Number],
[Contract Name],
[Licensee],
[Income Group],
[Customer],
[Language],
[Sale - Current],
[Return - Current],
[Gross Receipts - Current],
[Platform fee - Current],
[Royalties - Current],
[Sale - ITD],
[Return - ITD],
[Gross Receipts - ITD],
[Platform Fee - ITD],
[Royalties - ITD],
[Minutes Watched - Current]





