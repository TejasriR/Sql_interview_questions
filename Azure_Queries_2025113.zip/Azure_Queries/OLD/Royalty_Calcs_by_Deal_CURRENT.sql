select 
 period_id [Period] 
,calc.contract_id [Deal ID]
,xc.contract_descr [Deal Name]
,[Agreement Number]
,xc.formatted_name [Corporate Entity]
  ,format(sum(case when [udkey_2_value]='Sale' then amount else 0 end),'C','en-US') [Sale] 
  ,format(sum(case when [udkey_2_value]='Return' then amount else 0 end),'C','en-US') [Return] 
  ,format(sum(case when [udkey_2_value]='Gross Receipts' then amount else 0 end),'C','en-US') [Gross Receipts] 
  ,format(sum(case when [udkey_2_value]='Platform Fee' then amount else 0 end),'C','en-US') [Platform Fee]
  ,format(sum(case when [udkey_2_value]='Reserves Taken' then amount else 0 end),'C','en-US') [Reserves Taken] 
  ,format(sum(case when [udkey_2_value]='Reserves Released' then amount else 0 end),'C','en-US') [Reserves Released] 
  ,format(sum(case when [udkey_2_value]='Net Receipts' then amount else 0 end),'C','en-US') [Net Receipts]
  ,format(sum(case when [udkey_2_value]='Royalties' then amount else 0 end),'C','en-US') [Royalties]
  ,format(sum(case when [udkey_2_value]='Royalties Due' then amount else 0 end),'C','en-US') [Royalties Due]
  ,sum(case when [udkey_2_value]='Sale' then alt_qty else 0 end) [Minutes Watched]  
  
  from [uv_deal_calc_result] calc 
  join (SELECT 
      [contract_id], [udf_name], [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by [contract_id], [udf_name], [udf_value] ) c on c.contract_id=calc.contract_id
  join (select contract_id, contract_descr,formatted_name  from [uv_contract_contact] group by contract_id,contract_descr,formatted_name) xc on c.contract_id=xc.contract_id
  where udkey_3_value='Current'
  and period_id='202403'
  --and calc.[contract_id]='6154'
  group by 
  Period_id,
  calc.contract_id
  ,xc.contract_descr
  ,[Agreement Number]
  ,xc.formatted_name