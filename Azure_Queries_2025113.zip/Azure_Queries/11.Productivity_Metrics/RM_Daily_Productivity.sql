SELECT 
As_of_Date [Day]
,left(As_of_Date,7) [Month] 
,isnull([Number of generated calcs],0) [Number of generated calcs]
,isnull([Number of Approvals],0) [Number of Approvals]

from (

SELECT CAST(DATEADD(day, value, '2024-07-15') AS DATE) AS As_of_Date
FROM GENERATE_SERIES(0, DATEDIFF(day, '2024-07-15', datefromparts(year(getdate()),month(getdate()),day(getdate()))))

) Day_List 
left join (SELECT 
datefromparts(year([approved_datetime]),month([approved_datetime]),day(approved_datetime)) [Statement Approved Date]

,count( [statement_sid]) [Number of Approvals]
  FROM [x_statement_job_queue_hist] a 
  join x_approval app on app.[approval_sid]=a.approval_sid
  join x_user u on u.user_sid=app.approved_by_user_sid

  group by datefromparts(year([approved_datetime]),month([approved_datetime]),day(approved_datetime))

  ) Approvals on Day_List.As_of_Date=Approvals.[Statement Approved Date]



  left join (select datefromparts(year([end_datetime]),month([end_datetime]),day(end_datetime)) [Generated Calc Date], count(statement_sid) [Number of generated calcs] from [uv_statement]
group by datefromparts(year([end_datetime]),month([end_datetime]),day(end_datetime))
) Generated_Calcs on Day_List.As_of_Date=Generated_Calcs.[Generated Calc Date]
order by As_of_Date

------ time to approve calcs by quarter

SELECT 

uvs.period_id [Quarter],
avg(round(datediff(d,datefromparts(year([end_datetime]),month([end_datetime]),day(end_datetime)) , datefromparts(year([approved_datetime]),month([approved_datetime]),day(approved_datetime))),2)) [Elapsed time between calcs and approvals (Days)],
count(distinct uvs.[statement_sid]) [Number of Approved Statements] 

  FROM [x_statement_job_queue_hist] a 
  join x_approval app on app.[approval_sid]=a.approval_sid
  join x_user u on u.user_sid=app.approved_by_user_sid
  right join (select statement_sid, status_id, period_id, end_datetime from uv_statement where [status_id]='Approved') uvs on uvs.statement_sid=a.statement_sid

  group by 

  uvs.period_id

  order by period_id