SELECT 
As_of_Date [Day]
,left(As_of_Date,7) [Month]
,isnull([Number of Created Deals],0) [Number of Created Deals]
,isnull([Number of Revisions],0) [Number of Revisions]
,isnull([number of completions],0) [Number of Completions]
,isnull([number of activations],0) [Number of Activations]

from (

SELECT CAST(DATEADD(day, value, '2024-02-01') AS DATE) AS As_of_Date
FROM GENERATE_SERIES(0, DATEDIFF(day, '2024-02-01', datefromparts(year(getdate()),month(getdate()),day(getdate()))))

) Day_List 

left join 

(
SELECT 
datefromparts(year(c_rev.revision_eff_date),month(c_rev.revision_eff_date),day(c_rev.revision_eff_date)) [Deal Revision Creation Date]
,count(c_rev.contract_id) [Number of Revisions]
from uv_contract c_rev
where revision_nbr>1
group by   
datefromparts(year(c_rev.revision_eff_date),month(c_rev.revision_eff_date),day(c_rev.revision_eff_date))
) Revisions on Revisions.[Deal Revision Creation Date]=Day_List.As_of_Date

left join 
(
SELECT 
datefromparts(year(c.approved_datetime),month(c.approved_datetime),day(c.approved_datetime)) [Deal Revision Approved Date]
,count(c.contract_id) [number of activations]
from uv_contract c
group by   
datefromparts(year(c.approved_datetime),month(c.approved_datetime),day(c.approved_datetime)) 
) Approvals on Approvals.[Deal Revision Approved Date]=Day_List.As_of_Date

left join 
(
SELECT 
datefromparts(year(cc.completed_datetime),month(cc.completed_datetime),day(cc.completed_datetime)) [Deal Completion Date]
,count(cc.contract_id) [number of completions]
from uv_contract cc
group by   
datefromparts(year(cc.completed_datetime),month(cc.completed_datetime),day(cc.completed_datetime)) 
) Completions on Completions.[Deal Completion Date]=Day_List.As_of_Date

left join

(
SELECT 
datefromparts(year(c_cre.revision_eff_date),month(c_cre.revision_eff_date),day(c_cre.revision_eff_date)) [Deal Creation Date]
,count(c_cre.contract_id) [Number of Created Deals]
from uv_contract c_cre
where revision_nbr=1
group by   
datefromparts(year(c_cre.revision_eff_date),month(c_cre.revision_eff_date),day(c_cre.revision_eff_date))
) Creations on Creations.[Deal Creation Date]=Day_List.As_of_Date

order by As_of_Date



SELECT 
--As_of_Date [Day]
left(As_of_Date,7) [Month]
,sum(isnull([Number of Created Deals],0)) [Number of Created Deals]
,sum(isnull([Number of Revisions],0)) [Number of Revisions]
,sum(isnull([number of completions],0)) [Number of Completions]
,sum(isnull([number of activations],0)) [Number of Activations]

from (

SELECT CAST(DATEADD(day, value, '2024-02-01') AS DATE) AS As_of_Date
FROM GENERATE_SERIES(0, DATEDIFF(day, '2024-02-01', datefromparts(year(getdate()),month(getdate()),day(getdate()))))

) Day_List 

left join 

(
SELECT 
datefromparts(year(c_rev.revision_eff_date),month(c_rev.revision_eff_date),day(c_rev.revision_eff_date)) [Deal Revision Creation Date]
,count(c_rev.contract_id) [Number of Revisions]
from uv_contract c_rev
where revision_nbr>1
group by   
datefromparts(year(c_rev.revision_eff_date),month(c_rev.revision_eff_date),day(c_rev.revision_eff_date))
) Revisions on Revisions.[Deal Revision Creation Date]=Day_List.As_of_Date

left join 
(
SELECT 
datefromparts(year(c.approved_datetime),month(c.approved_datetime),day(c.approved_datetime)) [Deal Revision Approved Date]
,count(c.contract_id) [number of activations]
from uv_contract c
group by   
datefromparts(year(c.approved_datetime),month(c.approved_datetime),day(c.approved_datetime)) 
) Approvals on Approvals.[Deal Revision Approved Date]=Day_List.As_of_Date

left join 
(
SELECT 
datefromparts(year(cc.completed_datetime),month(cc.completed_datetime),day(cc.completed_datetime)) [Deal Completion Date]
,count(cc.contract_id) [number of completions]
from uv_contract cc
group by   
datefromparts(year(cc.completed_datetime),month(cc.completed_datetime),day(cc.completed_datetime)) 
) Completions on Completions.[Deal Completion Date]=Day_List.As_of_Date

left join

(
SELECT 
datefromparts(year(c_cre.revision_eff_date),month(c_cre.revision_eff_date),day(c_cre.revision_eff_date)) [Deal Creation Date]
,count(c_cre.contract_id) [Number of Created Deals]
from uv_contract c_cre
where revision_nbr=1
group by   
datefromparts(year(c_cre.revision_eff_date),month(c_cre.revision_eff_date),day(c_cre.revision_eff_date))
) Creations on Creations.[Deal Creation Date]=Day_List.As_of_Date

group by left(As_of_Date,7)

order by left(As_of_Date,7)
