 SELECT 

  c.contract_id [Deal ID]
  ,c.revision_nbr [Revision Number]
  ,c.contract_id+'-'+cast(c.revision_nbr as varchar) [Contract and Revision]
   ,c.contract_id+'-'+cast(c.revision_nbr +1 as varchar) [Contract and Next Revision]
  ,c.revision_eff_date [Deal Revision Creation Date]
  ,c.approved_datetime [Deal Revision Approved Date]
  ,datediff(d, c.revision_eff_date , c.approved_datetime) [Revision Review and Approval Time (Days)]
  ,c2.[Deal Revision Creation Date] [Deal Next Revision creation Date]
  ,[Latest Revision Date] 
  ,[Latest Deal Activation Date] 
  ,c.contract_status_id
  ,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]


  from uv_contract c 
  join (select contract_id [Deal_ID],max(datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date))) [Latest Revision Date], max(datefromparts(year(approved_datetime),month(approved_datetime),day(approved_datetime))) [Latest Deal Activation Date] from uv_contract group by contract_id) cm on cm.deal_id=c.contract_id  
  
  --where datefromparts(year(c.revision_eff_date),month(c.revision_eff_date),day(c.revision_eff_date))<'2025-02-15'
  left join (select 
  
  contract_id,
  revision_nbr,
  contract_id+'-'+cast(revision_nbr as varchar) [Contract with Revision],
  datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date)) [Deal Revision Creation Date]
  ,approved_datetime [Deal Revision Approved Date]
  
  
    from uv_contract) c2 on c2.[Contract with Revision]=c.contract_id+'-'+cast(c.revision_nbr +1 as varchar)
    --where Deal_ID='5698'

  group BY

    c.contract_id 
  ,c.revision_nbr 
   ,c.contract_id+'-'+cast(c.revision_nbr as varchar)
  ,c.revision_eff_date
  ,c.approved_datetime 
  ,[Latest Revision Date] 
  ,[Latest Deal Activation Date] 
 ,c2.[Deal Revision Creation Date]
,c.contract_status_id


----average approval time and number of revisions per deal

 SELECT 

  c.contract_id [Deal ID]
  ,max(c.revision_nbr) [number of Revisions]
  
  ,avg(datediff(d, c.revision_eff_date , c.approved_datetime)) [Revision Review and Approval Avg Time (Days)]

  ,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]


  from uv_contract c 
  join (select contract_id [Deal_ID],max(datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date))) [Latest Revision Date], max(datefromparts(year(approved_datetime),month(approved_datetime),day(approved_datetime))) [Latest Deal Activation Date] from uv_contract group by contract_id) cm on cm.deal_id=c.contract_id  
  
  --where datefromparts(year(c.revision_eff_date),month(c.revision_eff_date),day(c.revision_eff_date))<'2025-02-15'
  left join (select 
  
  contract_id,
  revision_nbr,
  contract_id+'-'+cast(revision_nbr as varchar) [Contract with Revision],
  datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date)) [Deal Revision Creation Date]
  ,approved_datetime [Deal Revision Approved Date]
  
    from uv_contract) c2 on c2.[Contract with Revision]=c.contract_id+'-'+cast(c.revision_nbr +1 as varchar)
    where  datefromparts(year(revision_eff_date),month(revision_eff_date),day(revision_eff_date))>'2024-03-15' ---escluding what was migrated as the team started approving things a lot later bc of implementation
    --where Deal_ID='5698'

  group BY

    c.contract_id
  order by c.contract_id
