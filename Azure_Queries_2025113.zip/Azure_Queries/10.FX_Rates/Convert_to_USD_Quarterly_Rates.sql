Select [From currency], avg([FX rate]) [FX_Rate_Quarter], [Quarter]

from (
SELECT
      [udkey_17_id] [From currency]
      ,[udkey_18_value] [To currency]
      ,cast([value] as float) [FX rate]
      ,[udf_name]
      ,[seq_nbr]
      ,[sort_order_nbr]
      ,[start_actual_period_id]
      ,[end_actual_period_id]
      ,case when start_actual_period_id<=202312 then '2023_Q4' else left(start_actual_period_id,4)+'_Q'+cast(datepart(q,DATEFROMPARTS(left(start_actual_period_id,4),cast(right(start_actual_period_id,2) as int),1)) as varchar) end [Quarter]
      ,[modified_by_user_name]
      ,[modified_datetime]

  FROM [uv_udkey_17_udf_lookup]) FX_Rates

  where [To currency] = 'USD'

  group by  [From currency], [Quarter]