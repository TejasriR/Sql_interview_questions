select * from uv_udkey_17

SELECT
      from_currency.[udkey_17_id] [From currency]
      ,curr.udkey17_description
      ,[udkey_18_value] [To currency]
      ,[value] [FX rate]
      ,[udf_name]
      ,[seq_nbr]
      ,[sort_order_nbr]
      ,[start_actual_period_id]
      ,[end_actual_period_id]

  FROM [uv_udkey_17_udf_lookup] from_currency
  join uv_udkey_17 curr on curr.udkey_17_id=from_currency.udkey_17_id
  where [udkey_18_value]='USD'