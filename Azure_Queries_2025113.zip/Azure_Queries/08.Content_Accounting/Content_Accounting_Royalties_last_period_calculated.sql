 With Calculations AS (

 select 
 --calc.contract_id+'_'+[udkey_15_value] +'_'+period_id [Asset_ID_Period]
 --,calc.contract_id+'_'+[udkey_15_value] [Asset_ID]
 period_id [Period]
 ,calc.contract_id [Deal ID]
 ,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
 ,'ACTUAL_STATEMENT' [Calculation Type]
 ,[udkey_15_value] [Recoupment Group]
 ,data_is_approved_flag [Calcs are Approved?]
 
 ,format(sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Gross Receipts] 
 ,format(sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Net Receipts]
 ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
 ,format(sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD_Royalties]
 ,format(sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Minimum Guarantee - Escalation' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Minimum Guarantee]
 ,format(sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Expenses] --Miscellaneous Costs - Paid
 ,format(sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [P&A_Costs]
 ,format(sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Previously Paid]
 ,format(case when sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)<0 then 0 else sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end) end,'C','en-US') [Royalties Due]
 ,case when (sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee - Escalation' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end))<0 then 'Unrecouped' else 'Recouped' end [Recoupment_Flag]

 from [uv_deal_calc_result] calc 
 --join (select [contract_id],max(period_id) [Last Period to have a statement] from uv_statement group by contract_id) cx on cx.contract_id=calc.contract_id

 Where calculation_name='C_MAIN_PARTICIP_STANDALONE_STATEMENT'
 --and period_id=[Last Period to have a statement]

 group by 
 -- calc.contract_id+'_'+[udkey_15_value] +'_'+period_id
 --,calc.contract_id+'_'+[udkey_15_value]
 period_id
 ,calc.contract_id
 ,data_is_approved_flag
 ,udkey_15_value 

HAVING 
sum(case when [udkey_2_value]='Gross Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Net Receipts - Stmt' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='CURRENT' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Production Costs - Stmt' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='P&A Costs - Paid - Stmt' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties Due - Stmt' AND udkey_3_value='Current' then amount else 0 end) <>0
 ),


 Metadata as (select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,ms.Master_Status [Deal Management Status]
,[Last Period to have a statement]
,[contract_currency] [Contract Currency]
,an.[Agreement Number] [Property Code]




from uv_contract c


join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_currency], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('ContractCurrency')) cc on cc.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid

JOIN
 (select [contract_id] [Deal ID],max(period_id) [Last Period to have a statement] from uv_statement group by contract_id) lastest on lastest.[Deal ID]=c.contract_id




where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'

group BY
c.contract_id 
,c.contract_description
,ms.Master_Status
,[Last Period to have a statement]
,cc.[contract_currency]
,an.[Agreement Number])


SELECT 
 Calculations.[Deal ID]+'_'+[Recoupment Group]+'_'+[Period] [Asset_ID_Period]
 ,Calculations.[Deal ID]+'_'+[Recoupment Group] [Asset_ID]
 ,[Period]
 ,[Last Period to have a statement]
 ,Calculations.[Deal ID]
 ,[Contract Name]
 ,[Property Code]
 ,[Contract Currency]
 ,[Report Generation Date] 
 ,[Calculation Type] 
 ,[Recoupment Group]
 ,[Calcs are Approved?]
 ,[Royalties - Current]
 ,[LTD_Royalties]
 ,[Minimum Guarantee]
 ,[Expenses]
 ,[P&A_Costs]
 ,[Previously Paid]
 ,[Royalties Due]
 ,[Recoupment_Flag]

 FROM Calculations
Join Metadata ON Calculations.[Deal ID] = Metadata.[Contract ID]

--WHERE calculations.[period]=Metadata.[Last Period to have a statement]
   
order by 
 calculations.[period] desc
,Calculations.[Deal ID] asc