 SELECT 
  --adj.adjustment_sid
  --adj_det.adjustment_sid
  --,adj.item_sid [contract_sid]
  c.contract_id+'_'+udkey_15_descr [Asset_ID]
  ,c.contract_id [Deal ID]
  ,udkey_15_descr [Recoupment Group]
  ,[Agreement Number]
  ,c.revision_nbr
  ,c.revision_eff_date [Deal Revision Creation Date]
  ,c.approved_datetime [Deal Revision Approved Date]
  ,adj.created_datetime [MG Created Date]
  ,adj.posted_datetime [MG Posted Date]
  ,max(adj_det.modified_datetime) [MG Last Updated]
  ,usr_created.formatted_name [MG Created By]
  ,usr_posted.formatted_name [MG Posted By]
  ,c.contract_status_id [Deal Revision Status] 
  ,sum(adj_det.amount) [Contract Value (MG)]
  ,adj_det.comment [Notes]
  ,adj_det.alt_user_comment [Additional Notes]
  

  FROM x_adjustment_hdr adj 
  join uv_contract c on adj.item_sid=c.contract_sid
  join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid
  join uv_adjustment_contract_dtl adj_det on adj.adjustment_sid=adj_det.adjustment_sid
  left join (select adjustment_sid from [uv_contract_posted_period] group by adjustment_sid ) cp on adj_det.adjustment_sid=cp.adjustment_sid
  join x_adjustment_hdr xa on xa.adjustment_sid=adj_det.adjustment_sid
  join x_user usr_created on usr_created.user_sid=adj.created_by_user_sid
  join x_user usr_posted on usr_posted.user_sid=adj.posted_by_user_sid
  --where c.contract_status_id<>'PRIORREVISION'
  where adj_det.udkey_2_id='Minimum Guarantee'
  and xa.status_sid<>11
     --and c.contract_id in ('11138')
  group by 
    --adj.adjustment_sid
--adj_det.adjustment_sid
--,adj.item_sid
c.contract_id+'_'+udkey_15_descr
  ,c.contract_id
  ,[Agreement Number]
  ,c.contract_status_id
  ,udkey_15_descr
  ,c.revision_nbr
,c.revision_eff_date
,c.approved_datetime
  ,adj_det.comment 
  ,adj_det.alt_user_comment
  ,adj.created_datetime
    ,adj.posted_datetime
  ,usr_created.formatted_name
  ,usr_posted.formatted_name
order by c.contract_id asc