 WITH Calculations AS (
  
 select 
 calc.contract_id+'_'+[udkey_15_value] +'_'+period_id [Asset_ID_Period]
 ,calc.contract_id+'_'+period_id [Deal_ID_Period]
 ,calc.contract_id+'_'+[udkey_15_value] [Asset_ID]
 ,period_id [Period]
 ,calc.contract_id [Deal ID]
 ,datefromparts(year(getdate()),month(getdate()),day(getdate())) [Report Generation Date]
 ,'ACCRUAL' [Calculation Type]
 ,[udkey_15_value] [Recoupment Group]
 ,data_is_approved_flag [Calcs are Approved?]
 
 --,format(sum(case when [udkey_2_value]='Gross Receipts' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Gross Receipts] 
 --,format(sum(case when [udkey_2_value]='Net Receipts' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Net Receipts]
 ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='CURRENT' then amount else 0 end),'C','en-US') [Royalties - Current]
 ,format(sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [LTD_Royalties]
 ,format(sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Minimum Guarantee]
 ,format(sum(case when [udkey_2_value]='Production Costs' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [Expenses] --Miscellaneous Costs - Paid
 ,format(sum(case when [udkey_2_value]='P&A Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end),'C','en-US') [P&A_Costs]
 ,format(sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Previously Paid]
 ,format(sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end),'C','en-US') [Royalties Due]
 ,case when (sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Production Costs' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='P&A Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end))<0 then 'Unrecouped' else 'Recouped' end [Recoupment_Flag]

 from [uv_deal_calc_result] calc 

 Where calculation_name='C_MAIN_PARTICIP_STANDALONE_ACCRUAL'

 group by 
  calc.contract_id+'_'+[udkey_15_value] +'_'+period_id
 ,calc.contract_id+'_'+[udkey_15_value]
 ,calc.contract_id+'_'+period_id
 ,period_id
 ,calc.contract_id
 ,data_is_approved_flag
 ,udkey_15_value 

HAVING 
sum(case when [udkey_2_value]='Gross Receipts' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Net Receipts' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='CURRENT' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Historical Royalties due' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Minimum Guarantee' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Production Costs' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Miscellaneous Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='P&A Costs - Paid' AND udkey_3_value='ITD' then amount else 0 end)
+sum(case when [udkey_2_value]='Historical Payment due' AND udkey_3_value='ITD' then amount else 0 end)+sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='ITD' then amount else 0 end)-sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end)
+sum(case when [udkey_2_value]='Royalties Due' AND udkey_3_value='Current' then amount else 0 end) <>0
 ),

 Latest_Period AS 
    (
    SELECT      
       
        [contract_id] [Deal ID],

        max([period_id]) AS [Last Period to have an accrual]

    FROM [uv_deal_calc_msg]
    where [contract_id] not like '%Revenue%'
    and [status_description] in ('Complete','Approved')
    and [deal_description]='Accrual'
    group by contract_id
 ),

Metadata as (select 

c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,ms.Master_Status [Deal Management Status]
,[contract_currency] [Contract Currency]
,an.[Agreement Number] [Property Code]




from uv_contract c


join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_currency], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('ContractCurrency')) cc on cc.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'

group BY
c.contract_id 
,c.contract_description
,ms.Master_Status
,cc.[contract_currency]
,an.[Agreement Number]),
 

 Accruals AS (SELECT 
    [Contract ID]+'_'+[Quarter] [Contract_ID_Quarter],
    [Contract ID],
    [Contract Name],
    --[Calculation Status],
    [Quarter],
    ISNULL([Accrual], 0) AS [Has_Accrual_Calc],
    ISNULL([Statement], 0) AS [Has_Actuals_Statement_Calc],
    case when ISNULL([Statement], 0)=1 then 'Report Actuals/Statement' else 'Report Accruals' end [What_to_Report]
FROM (
    SELECT      
        [contract_sid] AS [Contract SID],
        [contract_id] AS [Contract ID],
        [contract_description] AS [Contract Name],
        [period_id] AS [Quarter],
        --[status_description] AS [Calculation Status],
        [deal_description] AS [Calculation Type]
    FROM [cru_master].[dbo].[uv_deal_calc_msg]
    where [contract_id] not like '%Revenue%'
    and [status_description] in ('Complete','Approved')
    --and contract_id='10705'
) AS SourceTable
PIVOT (
    COUNT([contract sid])
    FOR [Calculation Type] IN ([Accrual], [Statement])
) AS PivotTable

where (case when ISNULL([Statement], 0)=1 then 'Report Actuals/Statement' else 'Report Accruals' end)='Report Accruals')

 SELECT 
 [Asset_ID_Period]
 ,[Asset_ID]
 ,[Period]
 ,[Last Period to have an accrual]
 ,Calculations.[Deal ID]
 ,Metadata.[Contract Name]
 ,Metadata.[Property Code]
 ,Metadata.[Contract Currency]
 ,[Report Generation Date] 
 ,[Calculation Type] 
 ,[Recoupment Group]
 ,[Calcs are Approved?]
 ,[Royalties - Current]
 ,[LTD_Royalties]
 ,[Minimum Guarantee]
 ,[Expenses]
 ,[P&A_Costs]
 ,[Previously Paid]
 ,[Royalties Due]
 ,[Recoupment_Flag]


 FROM Calculations
JOIN Latest_Period ON Calculations.[Deal ID] = Latest_Period.[Deal ID]
JOIN Accruals ON Calculations.[Deal_ID_Period]=Accruals.[Contract_ID_Quarter]
JOIN Metadata ON Calculations.[Deal ID]=Metadata.[Contract ID]

--WHERE calculations.[period]=Latest_Period.[last period to have an accrual]
   
order by 
 calculations.[period] desc
,Calculations.[Deal ID] asc