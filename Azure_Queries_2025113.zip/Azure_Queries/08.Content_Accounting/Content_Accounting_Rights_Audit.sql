select 
a.contract_id [Deal ID],
b.contract_description [Deal Name],
b.revision_nbr [Deal Revision Number],
b.revision_eff_date [Revision Date],
contract_status_id [Contract Status],
min([start_actual_period_id]) [Rights start Date],
max([end_actual_period_id]) [Rights End date],
max(a.modified_datetime) [Rights Last Updated]
from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
--where contract_status_id<>'PRIORREVISION'
--where b.contract_id='5712'
group by a.contract_id,contract_status_id,b.contract_description,b.revision_nbr,b.revision_eff_date 
order by a.contract_id,b.revision_nbr