select 
--c.[contract_sid]
c.contract_id [Contract ID]
,c.contract_description [Contract Name]
,ISNULL(entity.[Legal Entity],'') [Legal Entity]
,string_agg(licensee.company_name,'|') [Licensee]
,string_agg(licensor.company_name,'|') [Licensor]
,pd.Property_Description
,c.contract_status_id [Contract Status]
,ms.[master_status] [Deal Management Status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') [Deal Start Date]
,ISNULL(ce.contract_end_date,'') [Deal End Date]
,[Scope start Date]
,[Scope End date]
,ISNULL(datediff(year,cs.contract_start_date,ce.contract_end_date ),0) [Contract Term (Years)]
,ISNULL(datediff(day,cs.contract_start_date,ce.contract_end_date )/30,0) [Contract Term (Months)]
,ISNULL(format(cv.[contract value],'C','en-US'),0) [Contract_Value (MG)]
,deal_catalog_counts.Total_Episodes
,deal_catalog_counts.Total_Movies
,deal_catalog_counts.Total_OVAs
,DATEFROMPARTS(YEAR(cv.[Last Updated]),MONTH(cv.[Last Updated]),DAY(cv.[Last Updated])) [MG Last Updated]
,DATEFROMPARTS(YEAR([Rights Last Updated]),MONTH([Rights Last Updated]),DAY([Rights Last Updated])) [Rights Last Updated]
,isnull([Last Period to have a statement],'No Calculations/Statements') [Last Period to have a statement in Alliant]
,case when isnull([Last Period to have a statement],'No Calculations/Statements')<>'No Calculations/Statements' then 'No Calculations/Statements' else isnull([rl_balance].[period_id],'No Calculations/Statements') end [Last Period to have a statement in Rightsline]


from uv_contract c

left join (select [contract_id],max(period_id) [Last Period to have a statement] from uv_statement group by contract_id) last_period on c.contract_id=last_period.contract_id ---get last period in alliant

left join (  SELECT 
  c.contract_id
  ,period_id
  ,[Agreement Number]
  
  FROM x_adjustment_hdr adj 
  join uv_contract c on adj.item_sid=c.contract_sid
  join uv_adjustment_contract_dtl adj_det on adj.adjustment_sid=adj_det.adjustment_sid
  left join (select adjustment_sid from [uv_contract_posted_period] group by adjustment_sid ) cp on adj_det.adjustment_sid=cp.adjustment_sid
  join x_adjustment_hdr xa on xa.adjustment_sid=adj_det.adjustment_sid
   
  join (SELECT 
      contract_sid,[contract_id], [udf_name],status_id, [udf_value] [Agreement Number]
      from [uv_contract_udf] where udf_name = 'Agreement_integer' group by contract_sid,[contract_id],status_id, [udf_name], [udf_value] ) an on an.contract_sid=c.contract_sid

  where c.contract_status_id<>'PRIORREVISION'
  and adj_det.udkey_2_id='Historical Royalties Due'
  and xa.status_sid<>11
  group by 
  c.contract_id
  ,[Agreement Number]
  ,period_id) rl_balance on c.contract_id=rl_balance.contract_id

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Property_Description], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('property_description')) pd on pd.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Legal Entity], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('corporate_entity_appears_as')) entity on entity.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Master_Status], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('masterstatus')) ms on ms.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [Agreement Number], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('Agreement_Integer')) an on an.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_start_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_start')) cs on cs.contract_sid=c.contract_sid

join (Select
      [contract_sid],[contract_id], [udf_name], [udf_value_id] [contract_end_date], [status_id] [Deal_Status]
      from [uv_contract_udf]  
      where [udf_name] in ('contract_term_end')) ce on ce.contract_sid=c.contract_sid

---licensor

left join (select cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Licensor' )and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr) licensor on licensor.contract_sid=c.contract_sid

---licensee

left join (select cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr from v_contract_participant cpar join uv_contact uv on cpar.contact_sid=uv.contact_sid join uv_contract uvc on uvc.contract_sid=cpar.contract_sid 
where (contact_type_descr='Corporate Entity' or contact_type_descr='Licensee') and uvc.contract_status_id<>'PRIORREVISION' group by cpar.contract_sid, cpar.contact_sid, company_name,contact_type_descr ) licensee on licensee.contract_sid=c.contract_sid

---rights last updated date

left join (select 
a.contract_id [Deal ID], max(a.modified_datetime) [Rights Last Updated]
from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
group by a.contract_id) rights on rights.[Deal ID]=c.contract_id

---Scope

left join (select 
a.contract_id [Deal ID],


min(case when [start_actual_period_id]='Inception' then '201001' else [start_actual_period_id] end) [Scope start Date],
max(case when [end_actual_period_id]='Inception' then '201001' else [end_actual_period_id] end ) [Scope End date]

from
uv_contract_rights a
join uv_contract b
on a.contract_sid = b.contract_sid
where contract_status_id<>'PRIORREVISION'
--and b.contract_id='3802'
group by a.contract_id) scope on c.contract_id=scope.[Deal ID]


----contract value 

left join (  
  SELECT 
  --adj.adjustment_sid
  adj.item_sid [contract_sid]
  ,c.contract_id
  ,sum(adj_det.amount) [Contract Value]
  ,max(adj_det.modified_datetime) [Last Updated]

  FROM x_adjustment_hdr adj 
  join uv_contract c on adj.item_sid=c.contract_sid
  join uv_adjustment_contract_dtl adj_det on adj.adjustment_sid=adj_det.adjustment_sid
  left join (select adjustment_sid from [uv_contract_posted_period] group by adjustment_sid ) cp on adj_det.adjustment_sid=cp.adjustment_sid
  join x_adjustment_hdr xa on xa.adjustment_sid=adj_det.adjustment_sid
  where c.contract_status_id<>'PRIORREVISION'
  and adj_det.udkey_2_id='Minimum Guarantee'
  and xa.status_sid<>11
     --and c.contract_id in ('10003','10002','40')
  group by 
    --adj.adjustment_sid
    adj.item_sid
  ,c.contract_id
) cv on cv.contract_sid=c.contract_sid


left join

( select query.[contract sid]
,sum(case when (query.[catalog template]='season' or query.[catalog template]='episode') then query.[number of episodes] else 0 end) [Total_Episodes]
,sum(case when (query.[catalog template]='Movie') then query.[number of episodes] else 0 end) [Total_Movies]
,sum(case when (query.[catalog template]='OVA') then query.[number of episodes] else 0 end) [Total_OVAs]

from (
SELECT [Contract SID], [Contract ID], [Catalog ID], [Catalog Name], [Catalog Template], [number of episodes] from

(---- deal with rights at catalog level

SELECT contract_sid [Contract SID]
,contract_id [Contract ID]
,udkey_1_value [Catalog ID]
,udkey_1_descr [Catalog Name]
,template.template [Catalog Template]
,(case when template.template<>'Season' then 1 else count(distinct h.[child catalog]) end) [number of episodes]
  FROM [uv_contract_rights] udk1
  left join (select udkey_1_sid, udkey_1_id, udf_value [Template] from [uv_udkey_1_udf] where udf_name='entity_template') template on template.udkey_1_id=udk1.udkey_1_value
  
  left join (select udkey_1_sid [child catalog],hierarchy_level_nbr, parent_udkey_1_sid from c_udkey_1_hierarchy) h on h.parent_udkey_1_sid=udk1.udkey_1_sid
  where udkey_1_value is not null
  --and contract_id='10'
  group by contract_sid,contract_id, udkey_1_value,udkey_1_descr,template.template) catalog_level
  --where catalog_level.[Contract ID]='7592'

Union SELECT [Contract SID], [Contract ID], [Catalog ID], [Catalog Name], [Catalog Template], [number of episodes] from 

(---- deal with rights at catalog list level

SELECT udk1.contract_sid [Contract SID]
,udk1.contract_id [Contract ID]
,udkl1.dtl_udkey1_id [Catalog ID]
,udkl1.dtl_udkey1_description [Catalog Name]
,template.template [Catalog Template]
,(case when template.template<>'Season' then 1 else count(distinct h.[child catalog]) end) [number of episodes]
  FROM [uv_contract_rights] udk1 
  join [uv_udkey_1_lists] udkl1 on udkl1.udkey_1_group_sid=udk1.udkey_1_group_sid
  
  left join (select udkey_1_sid, udkey_1_id, udf_value [Template] from [uv_udkey_1_udf] where udf_name='entity_template') template on template.udkey_1_id=udkl1.dtl_udkey1_id

  left join (select udkey_1_sid [child catalog],hierarchy_level_nbr, parent_udkey_1_sid from c_udkey_1_hierarchy) h on h.parent_udkey_1_sid=udkl1.dtl_udkey_1_sid
   

  where udk1.udkey_1_group_sid is not null
  --and contract_id='10'
  group by udk1.contract_sid,udk1.contract_id, udk1.udkey_1_group_sid,udkl1.dtl_udkey1_id ,udkl1.dtl_udkey1_description,template.template
   ) Catalog_List_Level) query
   group by query.[contract sid]) deal_catalog_counts on deal_catalog_counts.[contract sid]=c.contract_sid


where c.contract_status_id<>'PRIORREVISION' and c.contract_status_id<>'MODEL'
and an.[Agreement Number] not like '%-%'
and an.[Agreement Number] not like 'TEST'
and an.[Agreement Number] not like '%DUPLICATE%'
and c.contract_description not like '%duplicate%'
and c.contract_description not like '%do not use%'
and c.contract_id not like '%do not use%'
--and c.contract_id='9811'
group BY
--c.[contract_sid]
c.contract_id
,c.contract_description
,ISNULL(entity.[Legal Entity],'')
--,licensee.company_name 
--,licensor.company_name 
,pd.Property_Description
,c.contract_status_id
,ms.[master_status]
,an.[Agreement Number]
,ISNULL(cs.contract_start_date,'') 
,ISNULL(ce.contract_end_date,'') 
,[Scope start Date]
,[Scope End date]
,ISNULL(datediff(year,cs.contract_start_date,ce.contract_end_date ),0)
,ISNULL(datediff(day,cs.contract_start_date,ce.contract_end_date )/30,0)
,ISNULL(format(cv.[contract value],'C','en-US'),0)
,deal_catalog_counts.Total_Episodes
,deal_catalog_counts.Total_Movies
,deal_catalog_counts.Total_OVAs
,DATEFROMPARTS(YEAR(cv.[Last Updated]),MONTH(cv.[Last Updated]),DAY(cv.[Last Updated]))
,DATEFROMPARTS(YEAR([Rights Last Updated]),MONTH([Rights Last Updated]),DAY([Rights Last Updated])) 
,isnull([Last Period to have a statement],'No Calculations/Statements')
,case when isnull([Last Period to have a statement],'No Calculations/Statements')<>'No Calculations/Statements' then 'No Calculations/Statements' else isnull([rl_balance].[period_id],'No Calculations/Statements') end



